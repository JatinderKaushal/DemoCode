//
//  PatientsHomeViewModel.swift
//  Doctors
//
//  Created by Jatinder on 03/04/24.
//

/*
 Add - NSLocationAlwaysAndWhenInUseUsageDescription
 Add - NSLocationWhenInUseUsageDescription

 Turn on - Capabilities -> Background modes -> Location updates
 */

import CoreLocation
import UIKit

class LocationManager: NSObject, CLLocationManagerDelegate {
    static let shared = LocationManager()
    var didChangeLocationAuthorization : ((CLLocation)-> Void)?
    var didUpdateAddress : ((String)-> Void)?
    private let manager = CLLocationManager()
    var authorizationStatus: CLAuthorizationStatus = .notDetermined
    private override init() { }
  
    func checkLocationService() {
        authorizationStatus = manager.authorizationStatus
        switch authorizationStatus {
        case .notDetermined:
            manager.delegate = self
            manager.desiredAccuracy = kCLLocationAccuracyBest
            manager.requestAlwaysAuthorization()
            manager.startUpdatingLocation()
            break
        case .denied, .restricted:
            DispatchQueue.main.async {
                self.locationPermissionPopup()
            }
            break
        case .authorizedWhenInUse, .authorizedAlways:
            manager.delegate = self
            manager.desiredAccuracy = kCLLocationAccuracyBest
            manager.startUpdatingLocation()
            break
        @unknown default:
            break
        }
    }
    
    func locationPermissionPopup() {
        self.presentAlertWithTitle(title:"Location Permission Required", message: "Please enable location permissions in settings.", options:  ["Settings","Cancel"]) { str in
            if str == "Settings" {
                //Redirect to Settings app
                UIApplication.shared.open(URL(string:UIApplication.openSettingsURLString)!)
            }
        }
    }
    
    // MARK: - Location Manager delegates
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let currentLocation: CLLocation = locations.first else { return }
        reverseGeocoding(location: currentLocation)
        didChangeLocationAuthorization?(currentLocation)
        manager.stopUpdatingLocation()
    }
    
    func reverseGeocoding(location:CLLocation) {
        CLGeocoder().reverseGeocodeLocation(location) { placemark, error in
            if let error = error as? CLError {
                print("CLError:", error)
                return
            } else if let placemark = placemark?.first {
                // you should always update your UI in the main thread
                DispatchQueue.main.async {
                    //  update UI here
                   /* print("name:", placemark.name ?? "unknown")
                    print("address1:", placemark.thoroughfare ?? "unknown")
                    print("address2:", placemark.subThoroughfare ?? "unknown")
                    print("neighborhood:", placemark.subLocality ?? "unknown")
                    print("city:", placemark.locality ?? "unknown")
                    print("state:", placemark.administrativeArea ?? "unknown")
                    print("subAdministrativeArea:", placemark.subAdministrativeArea ?? "unknown")
                    print("zip code:", placemark.postalCode ?? "unknown")
                    print("country:", placemark.country ?? "unknown", terminator: "\n\n")
                    print("isoCountryCode:", placemark.isoCountryCode ?? "unknown")
                    print("region identifier:", placemark.region?.identifier ?? "unknown")
                    print("timezone:", placemark.timeZone ?? "unknown", terminator:"\n\n")*/
                    
                    self.didUpdateAddress?("\(placemark.subAdministrativeArea ?? ""), \(placemark.administrativeArea ?? ""), \(placemark.country ?? "") ")
                    
                }
            }
        }
    }
    
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        checkLocationService()
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        manager.stopUpdatingLocation()
    }
    
    func presentAlertWithTitle(title: String = "", message: String, options: [String], completion: @escaping (String) -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        for (index, option) in options.enumerated() {
            alertController.addAction(UIAlertAction.init(title: option, style: .default, handler: { (action) in
                completion(options[index])
            }))
        }
        guard let topVC = UIApplication.topViewController() else { return  }
        topVC.present(alertController, animated: true, completion: nil)
    }
}
