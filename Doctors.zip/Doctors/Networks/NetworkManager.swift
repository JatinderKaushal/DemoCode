//
//  NetworkManager.swift
//  Doctors
//
//  Created by Aksa on 12/03/24.
//

import Foundation
import Moya

typealias successCallBack = (Any?) -> Void
typealias failureCallBack = (Error) -> Void

enum Service {
    
    case getPatientList(search: String?, status: [Int], page: Int)
    case getPatientDetails(id: Int)
    case getAPPointmentDetails(id: Int)
    case uploadPrescription(appointmentId: String, prescriptions: Data, fileName: String)
    case getPatientsHistory(search: String?, status: [Int], page: Int)
    case getUpcomingAppointments(search: String?, status: [Int], page: Int)
    //Patient module Api's http://qualhon.net:3033/api/v1/home-screen-data?lat=30.7499&lng=76.6411
    case getPatientHomeData(lat: String, long: String)
    case getNearbyDoctors(lat: String?, lng: String?, page: Int?, search: String?, distance: String?, categoryId: Int?)
    case getDoctorDetails(id: Int,lat: String, long: String)
    case  bookAppointment(model: BookAppointmentModel)
    case getReports
    case getPrescriptions
    case getTimeSlots(id: Int,date: Int64)
    case cancelAppointment(id: Int,reason: String)
    case registerPatient(ProfileRequestModel)
    case getPatientProfile
}

extension Service: TargetType {
    var baseURL: URL { return URL(string: "http://qualhon.net:3033/")!}
    
    var path: String {
        
        switch self {
        case .getPatientList:
            return "api/v1/patients"
        case .getAPPointmentDetails(let id):
            return "api/v1/appointments/\(id)"
        case .getPatientDetails(let id):
            return "api/v1/patients/\(id)"
        case .uploadPrescription:
            return "api/v1/prescriptions"
        case .getPatientsHistory:
            return "api/v1/appointments/recent-appointments"
            
        case .getPatientHomeData:
            return "api/v1/home-screen-data"
            
        case .getUpcomingAppointments:
            return "api/v1/appointments/upcoming-appointments"
        case .getNearbyDoctors:
            return "api/v1/doctors/nearby-doctors"
        case .getDoctorDetails(let id, _, _):
            return "api/v1/doctors/\(id)"
        case .bookAppointment:
            return "api/v1/appointments"
        case .getReports:
            return "api/v1/reports"
            
        case .getPrescriptions:
            return "api/v1/prescriptions"
        case .getTimeSlots(let id, _):
            return "api/v1/doctors/\(id)/time-slots"
        case .cancelAppointment(let id, _):
            return "api/v1/appointments/\(id)/cancel-appointment"
        case .registerPatient:
            return "api/v1/auth/patient/register"
        case .getPatientProfile:
            return "api/v1/auth/patient/profile"
        }
    }
    
    var method: Moya.Method {
        switch self {
            
        case .getPatientList,
                .getAPPointmentDetails,
                .getPatientDetails,
                .getPatientsHistory,
            
                .getPatientHomeData,
                .getUpcomingAppointments,
                .getNearbyDoctors,
                .getDoctorDetails,
                .getReports,
                .getPrescriptions,
                .getTimeSlots,
                .getPatientProfile:
            return .get
        case.uploadPrescription,
                .bookAppointment,
                .registerPatient:
            return .post
        case .cancelAppointment:
            return .put
        }
    }
    
    var task: Task {
        switch self {
        case .getPatientList(let search, let status, let page):
            var parameters: [String: Any] = [:]
            if let search = search {
                parameters["search"] = search
            }
            if !status.isEmpty {
                parameters["status"] = status.map { String($0) }.joined(separator: ",")
            }
            parameters["perPage"] = 10 // Assuming perPage value is fixed
            parameters["page"] = page
            return .requestParameters(parameters: parameters, encoding: URLEncoding.default)
            
        case .getPatientHomeData(let lat, let long):
            var parameters: [String: Any] = [:]
            parameters["lat"] = lat
            parameters["lng"] = long
            return .requestParameters(parameters: parameters, encoding: URLEncoding.queryString)
            
        case .getAPPointmentDetails, .getPatientDetails, .getReports, .getPrescriptions, .getPatientProfile:
            return .requestPlain
        case .getPatientsHistory(let search, let status, let page):
            var parameters: [String: Any] = [:]
            if let search = search {
                parameters["search"] = search
            }
            if !status.isEmpty {
                parameters["status"] = status.map { String($0) }.joined(separator: ",")
            }
            parameters["perPage"] = 10 // Assuming perPage value is fixed
            parameters["page"] = page
            return .requestParameters(parameters: parameters, encoding: URLEncoding.default)
            
        case .uploadPrescription(let id, let image, let name):
            
            let appointmentId = id.data(using: String.Encoding.utf8) ?? Data()
            
            let imageMultipartFormData = MultipartFormData(provider: .data(image), name: "prescriptions", fileName: "\(name).pdf", mimeType: "image/jpeg")
            let prescriptionIdMultipartFormData = MultipartFormData(provider: .data(appointmentId), name: "appointmentId")
            
            return .uploadMultipart([imageMultipartFormData, prescriptionIdMultipartFormData])
        case .getUpcomingAppointments(let search, let status, let page):
            var parameters: [String: Any] = [:]
            if let search = search {
                parameters["search"] = search
            }
            if !status.isEmpty {
                parameters["status"] = status.map { String($0) }.joined(separator: ",")
            }
            parameters["perPage"] = 10 // Assuming perPage value is fixed
            parameters["page"] = page
            return .requestParameters(parameters: parameters, encoding: URLEncoding.default)
        case .getNearbyDoctors(let lat, let lng, let page, let search, let distance, let categoryId):
            var parameters: [String: Any] = [:]
            
            if let lat = lat {
                parameters["lat"] = lat
            }
            if let lng = lng {
                parameters["lng"] = lng
            }
            if let search = search {
                parameters["search"] = search
            }
            if let distance = distance {
                parameters["distance"] = distance
            }
            if let categoryId = categoryId {
                parameters["categoryId"] = categoryId
            }
            parameters["perPage"] = 10 // Assuming perPage value is fixed
            parameters["page"] = page
            
            return .requestParameters(parameters: parameters, encoding: URLEncoding.default)
        case .getDoctorDetails(_, let lat, let long):
            var parameters: [String: Any] = [:]
            parameters["lat"] = lat
            parameters["lng"] = long
            return .requestParameters(parameters: parameters, encoding: URLEncoding.queryString)
        case .bookAppointment(let model):
            return .requestParameters(parameters: model.getParamsData, encoding: JSONEncoding.default)
        case .getTimeSlots(_, let date):
            var parameters: [String: Any] = [:]
            parameters["date"] = date
            return .requestParameters(parameters: parameters, encoding: URLEncoding.queryString)
        case .cancelAppointment(_, let reason):
            var parameters: [String: Any] = [:]
            parameters["reason"] = reason
            return .requestParameters(parameters: parameters, encoding: URLEncoding.queryString)
        case .registerPatient(let model):
            return .uploadMultipart(model.getMultipartFormData)
            
        }
    }
    
    var headers: [String: String]? {
        var header = [String:String]()
        
        if let token = DefaultsClass.shared.accessToken, !token.isEmpty {
            header[HeaderKeys.authorization]    = "Bearer \(token)"
        }
        
        header[HeaderKeys.contentType]          = "application/json"
        header[HeaderKeys.deviceIdentifier]     = UIDevice.current.identifierForVendor?.uuidString
        header[HeaderKeys.deviceManufacturer]   = "Apple"
        header[HeaderKeys.platform]             = "ios"
        header[HeaderKeys.deviceModel]          = UIDevice.current.model
        header[HeaderKeys.deviceName]           = UIDevice.current.name
        header[HeaderKeys.os]                   = UIDevice.current.systemVersion
        header[HeaderKeys.versionCode]          = Bundle.main.infoDictionary?["CFBundleVersion"] as? String
        header[HeaderKeys.version]              = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
        
        return header
    }
}

// MARK: - Header Which Is Used In Application Api Hit Time
struct HeaderKeys {
    static let authorization = "Authorization"
    static let contentType = "content-type"
    static let deviceIdentifier = "device-identifier"
    static let deviceManufacturer = "device-manufacturer"
    static let deviceModel = "device-model"
    static let deviceName = "device-name"
    static let os = "system-version"
    static let versionCode = "app-version-code"
    static let version = "app-version"
    static let platform = "platform"
}
// MARK: - Header Which Is Used In Application Api Hit Time
struct imageBaseURl {
    var baseURL: String { return "http://qualhon.net:3031/"}
}
