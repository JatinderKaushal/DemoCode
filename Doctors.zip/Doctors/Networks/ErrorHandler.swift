//
//  ErrorHandler.swift
//  GymMate
//
//  Created by aksa nazir on 28/11/23.
//

import Foundation
import Moya

class ErrorHandler: NSObject {
    
    static let shared = ErrorHandler()
    weak var currentViewController: UIViewController?
    
    func errorResponse(moyaResponse: Response) -> NSError {
        var message = "Unknown error occurred."
        
        if let object = try? JSONSerialization.jsonObject(with: moyaResponse.data, options: .allowFragments) as? [String: Any],
           let errorMessage = self.getErrorMessage(object: object) as? String {
            message = errorMessage
        }
      
        let userInfo = [NSLocalizedDescriptionKey: message]
        let error = NSError(domain: "", code: moyaResponse.statusCode, userInfo: userInfo)
        return error
    }

    func getErrorMessage(object: [String: Any]) -> Any? {
        // Implement your logic to extract the error message from the JSON response here
        // For example:
        return object["message"]
    }

    
    private func getErrorMessage(object: AnyObject) -> AnyObject? {
        if object.isKind(of: NSDictionary.self) {
            return self.getErrorMessage(object: object.allValues.first as AnyObject)
        } else if object.isKind(of: NSArray.self) {
            return self.getErrorMessage(object: (object as! NSArray).firstObject as AnyObject)
        } else if object.isKind(of: NSString.self) {
            return object
        }
        return nil
    }
    
    func handleError(error: Error) {
      //  self.hideHud()
        
        debugPrint(error as Any)
        let err = error as NSError
        if err.code == 401 {
            
            showSnackbar(message: error.localizedDescription, isErrorMessage: true)
        } else {
            showSnackbar(message: error.localizedDescription, isErrorMessage: true)
            if let viewController = currentViewController {
                // Show your view on the current view controller
               // viewController.showMyErrorView()
            }
        }
    }
}
