//
//  RequestModels.swift
//  Doctors
//
//  Created by aksa nazir on 15/03/24.
//

import Foundation
import Moya

struct commonModel: Codable {
    let message: String?
}

struct BookAppointmentModel {
    let doctorId: Int?
    let patientName: String?
    let patientAge: Int?
    let patientGender: Int?
    let syptoms: String?
    let note: String?
    let appointmentDate: Int?

    var getParamsData: [String: Any] {
        let params = [
            "doctorId" : self.doctorId as Any,
            "patientName" : self.patientName as Any,
            "patientAge" : self.patientAge as Any,
            "patientGender" : self.patientGender as Any,
            "syptoms" : self.syptoms as Any,
            "note" : self.note as Any,
            "appointmentDate" : self.appointmentDate as Any
        ] as [String : Any]
        return params as [String : Any]
    }
}


struct ProfileRequestModel {
    var profilePic: UIImage?
    var name: String?
    var gender: Int?

    init(profilePic: UIImage? = nil, name: String? = nil, gender: Int? = nil) {
        self.profilePic = profilePic
        self.name = name
        self.gender = gender
    }

    var getMultipartFormData: [MultipartFormData] {
        var formData: [MultipartFormData] = []

        if let profilePic = self.profilePic, let imageData = profilePic.jpegData(compressionQuality: 0.8) {
            formData.append(MultipartFormData(provider: .data(imageData), name: "image", fileName: "profile_pic.jpg", mimeType: "image/jpeg"))
        }
        if let name = self.name {
            formData.append(MultipartFormData(provider: .data(name.data(using: .utf8) ?? Data()), name: "name"))
        }
        if let gender = self.gender {
            let genderString = String(gender) // Convert Int to String
            formData.append(MultipartFormData(provider: .data(genderString.data(using: .utf8) ?? Data()), name: "gender"))
        }
        
        return formData
    }
}

