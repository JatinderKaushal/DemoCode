//
//  Utilities.swift
//  GymMate
//
//  Created by aksa nazir on 28/11/23.
//

import Foundation
import TTGSnackbar

func showSnackbar(message:String, isErrorMessage : Bool){
    
    let snackbar = TTGSnackbar(message: message, duration: .middle,actionText: "", actionBlock: { (snackbar) in
        print("Click action!")
        snackbar.dismiss()
    })
    snackbar.messageLabel.font = UIFont.init(name: "Montserrat-Regular", size: 14.0)
    snackbar.actionButton.setImage(#imageLiteral(resourceName: "cross_purple"), for: .normal)
    snackbar.animationType = .slideFromTopBackToTop
    if isErrorMessage {
        print("hi")
        snackbar.icon = #imageLiteral(resourceName: "red_error")
    } else {
        print("hip")
        snackbar.icon = #imageLiteral(resourceName: "green_check")
    }
    snackbar.show()
}

extension UIImage {
    func compress(maxKb: Double) -> UIImage? {
        let quality: CGFloat = maxKb / self.sizeAsKb()
        guard let compressedData = self.jpegData(compressionQuality: quality) else { return UIImage()}
        return UIImage(data: compressedData)
    }

    func sizeAsKb() -> Double {
        Double(self.pngData()?.count ?? 0 / 1024)
    }
}
