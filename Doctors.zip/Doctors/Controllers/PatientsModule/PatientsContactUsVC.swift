//
//  PatientsContactUsVC.swift
//  Doctors
//
//  Created by Aksa on 03/04/24.
//

import UIKit

class PatientsContactUsVC: UIViewController {
    
    @IBOutlet weak var txtFldEmail: UITextField!
    @IBOutlet weak var txtViewMessage: UITextView!
    private let viewModel = ContactUsViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func btnSubmit(_ sender: Any) {
        
        guard txtFldEmail.text! != "" else{
            self.showToast(message: "Email Field Can't be Empty!", font: UIFont.systemFont(ofSize: 12))
            return
        }
        guard txtViewMessage.text!.count <= 100 else{
            self.showToast(message: "Please enter your message within the range!", font: UIFont.systemFont(ofSize: 12))
            return
        }
        self.apiContactUs()
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = textField.text else { return true }
        let newLength = text.count + string.count - range.length
        return newLength <= 100
    }
}

//MARK: API Work in View controller
extension PatientsContactUsVC{
    private func apiContactUs(){
        let param : [String: Any] = ["email": self.txtFldEmail.text!, "message": txtViewMessage.text as Any]
        print(param)
        
        self.showSpinner()
        self.viewModel.contactUs(param: param) {[weak self] (status,msg) in
            self?.hideSpinner()
            if status{
                self?.showToast(message: msg)
            } else {
                let vc = PatientsHomeVC.instantiatePatient()
                self?.txtFldEmail.text  = nil
                self?.txtViewMessage.text = nil
                Constants.selectedDoctorMenu.uid = 0
                Constants.selectedDoctorMenu = Constants.DoctorMenu[0]
                self?.navigationController?.push(viewController: vc)
                self?.showToast(message: msg, font: UIFont.systemFont(ofSize: 12))
            }
        }
    }
}

