//
//  PatientsProfileVC.swift
//  Doctors
//
//  Created by Aksa on 03/04/24.
//

import UIKit
import DropDown

class PatientsProfileVC: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldNumber: UITextField!
    @IBOutlet weak var txtFldGender: UITextField!
    @IBOutlet weak var btnEditProfile: UIButton!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var textViewGender: UIView!
    
    private let imagePicker = UIImagePickerController()
    private let dropDown = DropDown()
    private let viewModel = PatientSignUpVM()
    private var selectedGender = Int() {
        didSet{
            let strGender = (Constants.GenderList.filter({$0.value == selectedGender})).first?.name
            self.txtFldGender.text = strGender ?? ""
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.callGetProfileAPI()
        self.btnSubmit.layer.cornerRadius = 12
        self.imgView.layer.cornerRadius = 12
        txtFldGender.delegate = self
        let strGender = (Constants.GenderList.filter({$0.value == selectedGender})).first?.name
        self.txtFldGender.text = strGender ?? ""
        dropDown.anchorView = textViewGender
    }
    
    @IBAction func didTapSelectGender(_ sender: UITextField) {
        self.view.endEditing(true)
        dropDown.dataSource = Constants.GenderList.map { $0.name }
        dropDown.show()
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            selectedGender = index + 1
            print(selectedGender)
            txtFldGender.text = item
        }
    }

    @IBAction func btnSubmitAction(_ sender: Any) {
        updatePatient()
    }
    
    func getData() {
        if let obj = viewModel.patientData {
            self.imgView.kf.setImage(with: URL(string: viewModel.getPic()), placeholder: Constants.DoctorPlaceholderImage, options: nil, completionHandler: nil)
            self.txtFldName.text = obj.name
            self.txtFldNumber.text = obj.phone
            self.selectedGender = obj.gender ?? 3
        }
    }
    
    private func callGetProfileAPI() {
        do {
            self.showSpinner()
            self.viewModel.getMyProfile(success: { _ in
                self.hideSpinner()
                self.getData()
            }, failure: { error in
                self.hideSpinner()
                ErrorHandler.shared.handleError(error: error)
            })
        }
    }
}

extension PatientsProfileVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.editedImage] as? UIImage else{
            return
        }
        self.imgView.image = image
        self.dismiss(animated: true, completion: nil)
    }
        
        @IBAction func btnTapImage(_ sender: Any) {
            self.showActionSheet(control: ["Camera","Gallery"]) { title in
                if title == "Camera"{
                    guard UIImagePickerController.isSourceTypeAvailable(.camera) else {return}
                    self.imagePicker.sourceType = .camera
                }else{
                    self.imagePicker.sourceType = .photoLibrary
                }
                self.imagePicker.delegate = self
                self.imagePicker.isEditing = true
                self.imagePicker.allowsEditing = true
                self.present(self.imagePicker, animated: true, completion: nil)
            }
        }
    
        func updatePatient() {
                self.view.endEditing(true)
                let requestModel = ProfileRequestModel(profilePic: self.imgView.image,
                                                         name: self.txtFldName.text,
                                                         gender: self.selectedGender )
                     
                do {
                    self.showSpinner()
                    self.viewModel.registerPatient(requestModel: requestModel) { _ in
                        self.hideSpinner()
                      
                        let storyboard = UIStoryboard(name: "PatientsModule", bundle: nil)
                        guard let vc = storyboard.instantiateViewController(withIdentifier: "PatientsHomeVC") as? PatientsHomeVC else {
                            return
                        }
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                failure: { error in
                    ErrorHandler.shared.handleError(error: error)
                    self.hideSpinner()
                }
                }
            }
            
    }
