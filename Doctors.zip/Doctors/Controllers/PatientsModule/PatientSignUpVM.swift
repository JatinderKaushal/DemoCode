//
//  PatientSignUpVM.swift
//  Doctors
//
//  Created by Aksa on 26/03/24.
//

import Foundation
import Moya

class PatientSignUpVM: NSObject {
    var patientData: PatientProfileData?
    func registerPatient(requestModel: ProfileRequestModel,
               success: @escaping successCallBack,
               failure: @escaping failureCallBack) {

        let provider = MoyaProvider<Service>()
        provider.request(.registerPatient(requestModel)) { result in
            switch result {
            case let .success(moyaResponse):
                do {
                    if let data = try self.handleRepsonse(type: RegisterPatient.self, moyaResponse: moyaResponse) {
                        DefaultsClass.shared.name = data.response?.name ?? ""
                        DefaultsClass.shared.profilePic = data.response?.image ?? ""
                        DefaultsClass.shared.id = (data.response?.id!)!
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
    
    internal func getPic()->String{
        return Api.imageUrl(endpoint: patientData?.image ?? "")
    }
    
    func getMyProfile(success: @escaping successCallBack,
                      failure: @escaping failureCallBack) {
        let provider = MoyaProvider<Service>()
        provider.request(.getPatientProfile) { result in
            switch result {
            case let .success(moyaResponse):
                do {
                    if let data = try self.handleRepsonse(type: PatientProfile.self, moyaResponse: moyaResponse) {
                        self.patientData = data.response
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
}
