//
//  BookAppointmentVC.swift
//  Doctors
//
//  Created by Aksa on 01/04/24.
//

import UIKit
import CoreLocation
import DropDown

class BookAppointmentVC: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var imgViewProfile: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgViewType: UIImageView!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var imgViewDistance: UIImageView!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var btnCalender: UIButton!
    @IBOutlet weak var daysCollectionView: UICollectionView!
    @IBOutlet weak var hoursCollectionView: UICollectionView!
    @IBOutlet weak var btnExtension: UIButton!
    @IBOutlet weak var txtFldPatientName: UITextField!
    @IBOutlet weak var txtFldAge: UITextField!
    @IBOutlet weak var txtFldGender: UITextField!
    @IBOutlet weak var txtViewSymptoms: UITextView!
    @IBOutlet weak var txtViewNotes: UITextView!
    @IBOutlet weak var btnBookAppointment: UIButton!
    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
    var location: CLLocation?
    var viewModel : PatientsHomeViewModel?
    var docId: Int?
    var workingHours: [NearbyDocWorkingHours] = []
    var selectedDate: Date?
    var selectedTime: Date?
    let datePicker = UIDatePicker()
    var selectedDayIndex = 0
    var timeSlots: [Int64] = []
    var isselectedCell: Bool?
    private let dropDown = DropDown()
    private var selectedGender = Int() {
        didSet {
            let strGender = (Constants.GenderList.filter({$0.value == selectedGender})).first?.name
            self.txtFldGender.text = strGender ?? ""
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        dropDown.anchorView = txtFldGender
        self.renderData()
        self.hoursCollectionView.reloadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        self.getDocDetails(id: docId ?? 0, location: location)
        getTimeSlots(date: selectedDate?.currentTimeMillis())
        self.renderData()
    }
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnBookAction(_ sender: Any) {
        self.bookAppointmentAPI()
    }
    
    @IBAction func btnArrowAction(_ sender: Any) {
        if self.heightConstraint.constant == 100 {
            var height = self.hoursCollectionView.collectionViewLayout.collectionViewContentSize.height
            self.heightConstraint.constant = height
            self.view.layoutIfNeeded()
        } else {
            self.heightConstraint.constant = 100
        }
    }
        @IBAction func didTapSelectGender(_ sender: UITextField) {
            self.view.endEditing(true) // Dismiss keyboard if it's open
            dropDown.dataSource = Constants.GenderList.map { $0.name } // Set DropDown data source
            dropDown.show() // Show the DropDown
            dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
                selectedGender = index + 1
                print(selectedGender)
                txtFldGender.text = item // Update text field with selected item
            }
        }

    @IBAction func btnCalenderAction(_ sender: Any) {
        datePicker.minimumDate = Date()
        datePicker.preferredDatePickerStyle = .inline
        datePicker.datePickerMode = .date
        datePicker.frame = CGRect(x: 0, y: view.frame.height - 400, width: view.frame.width, height: 400)
        datePicker.backgroundColor = .white
        view.addSubview(datePicker)
        
        let okButton = UIButton(type: .system)
        okButton.setTitle("OK", for: .normal)
        okButton.frame = CGRect(x: view.frame.width - 100, y: view.frame.height - 70, width: 100, height: 40)
        okButton.addTarget(self, action: #selector(okButtonTapped), for: .touchUpInside)
        view.addSubview(okButton)
        
        let cancelButton = UIButton(type: .system)
        cancelButton.setTitle("Cancel", for: .normal)
        cancelButton.frame = CGRect(x: 0, y: view.frame.height - 70, width: 100, height: 40)
        cancelButton.addTarget(self, action: #selector(cancelButtonTapped), for: .touchUpInside)
        view.addSubview(cancelButton)
    }
    
    @objc func okButtonTapped() {
        let selectedDate = datePicker.date
        print("Selected date: \(selectedDate)")
        self.selectedDate = selectedDate
        self.getTimeSlots(date: selectedDate.currentTimeMillis())
        removeDatePicker()
    }
    
    @objc func cancelButtonTapped() {
        removeDatePicker()
    }
    
    func removeDatePicker() {
        datePicker.removeFromSuperview()
        for subview in view.subviews {
            if subview is UIButton {
                subview.removeFromSuperview()
            }
        }
    }
    
    func renderData() {
        txtFldPatientName.delegate = self
        txtFldAge.delegate = self
        txtFldGender.delegate = self
        self.txtFldPatientName.styleTextField()
        self.txtFldAge.styleTextField()
        self.txtFldGender.styleTextField()
            if let obj = viewModel?.docDetails?.response {
                self.lblName.text = obj.name
                self.lblType.text = obj.specialization?.first?.category
                self.lblDistance.text =  "\(round(obj.distance ?? 0.0)) KM"
                self.workingHours = (obj.workingHours)!
                if let imgUrl = URL(string: Api.imageUrl(endpoint: obj.image ?? "")) {
                    imgViewProfile.kf.setImage(with: imgUrl, placeholder: UIImage(named: "doc"), options: nil, completionHandler: nil)
                    imgViewProfile.contentMode = .scaleAspectFill
                }
            }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == txtFldAge {
            guard let text = textField.text else { return true }
            let newLength = text.count + string.count - range.length
            let allowedCharacterSet = CharacterSet(charactersIn: "0123456789").inverted
            guard string.rangeOfCharacter(from: allowedCharacterSet) == nil else {
                return false
            }
            let maxIntegerLength = 2
            if newLength > maxIntegerLength {
                return false
            }
        }
        return true
    }
}

extension BookAppointmentVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.daysCollectionView {
            return viewModel?.docDetails?.response?.workingHours?.filter { $0.isOpen == 1 }.count ?? 0
        }
        return viewModel?.timeSlots.count ?? 0
        
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.daysCollectionView {
            guard let cell = self.daysCollectionView.dequeueReusableCell(withReuseIdentifier: "DaysCollectionViewCell", for: indexPath) as? DaysCollectionViewCell else {
                return UICollectionViewCell()
            }
            cell.backgroundColor = .clear
            let workingDays = viewModel?.docDetails?.response?.workingHours?.filter { $0.isOpen == 1 } ?? []
            
            if indexPath.row < workingDays.count {
                let day = workingDays[indexPath.row]
                cell.lblDayName.text = day.dayShortName
                let today = Date()
                let todayWeekday = Calendar.current.component(.weekday, from: today)
                let daysToAdd = (day.day! - todayWeekday + 8) % 7
                let dateForDay = Calendar.current.date(byAdding: .day, value: daysToAdd, to: today)
                if let dateForDay = dateForDay {
                    cell.lblDayNumber.text = "\(Calendar.current.component(.day, from: dateForDay))"
                } else {
                    cell.lblDayNumber.text = ""
                }
            } else {
                cell.lblDayName.text = ""
                cell.lblDayNumber.text = ""
            }
            return cell
            
        } else {
            guard let cell = self.hoursCollectionView.dequeueReusableCell(withReuseIdentifier: "HoursCollectionViewCell", for: indexPath) as? HoursCollectionViewCell else {
                return UICollectionViewCell()
            }
            
          
            let timeslotValue = viewModel?.timeSlots[indexPath.row].timeslot ?? 0
            let timeString = convertTimeslotToTimeString(Int64(timeslotValue))
            cell.lblTime.text = timeString
            cell.backgroundColor = .clear
            cell.lblTime.backgroundColor = .clear
            return cell
        }
    }
    
    func convertTimeslotToTimeString(_ timeslot: Int64) -> String {
        let date = Date(timeIntervalSince1970: TimeInterval(timeslot) / 1000)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        return dateFormatter.string(from: date)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.daysCollectionView {
            selectedDayIndex = indexPath.row
            
            if let cell = self.daysCollectionView.cellForItem(at: indexPath) as? DaysCollectionViewCell {
                if let dayNumberText = cell.lblDayNumber.text, let dayNumber = Int(dayNumberText) {
                    let today = Date()
                    let daysToAdd = dayNumber - Calendar.current.component(.day, from: today)
                    cell.backgroundColor = AppColors.selectedButton
                    self.selectedDate = Calendar.current.date(byAdding: .day, value: daysToAdd, to: today)
                }
            }
            
            self.hoursCollectionView.reloadData()
        }
        else {
            if let cell = self.hoursCollectionView.cellForItem(at: indexPath) as? HoursCollectionViewCell {
                if let timeslotValue = self.viewModel?.timeSlots[indexPath.row].timeslot {
                    self.isselectedCell = true
                    cell.lblTime.backgroundColor = AppColors.selectedButton
                    self.selectedTime = Date(timeIntervalSince1970: TimeInterval(timeslotValue) / 1000)
                }
            }
        }
    }
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        if collectionView == self.daysCollectionView {
            
            if let cell = self.daysCollectionView.cellForItem(at: indexPath) as? DaysCollectionViewCell {
                    cell.backgroundColor = .clear
                }
        }else {
            if let cell = self.hoursCollectionView.cellForItem(at: indexPath) as? HoursCollectionViewCell {
                    cell.lblTime.backgroundColor = .clear
                }
            }
        }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let collectionWidth = collectionView.bounds.width
        switch collectionView {
        case hoursCollectionView:
            return CGSize(width: (collectionWidth/4), height: 50)
            
        case daysCollectionView:
            return CGSize(width: (collectionWidth/7)-2, height: 70)
            
        default:
            break
        }
        return CGSize(width: collectionWidth, height: 120)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func formatTimeFromTimestamp(_ timestamp: TimeInterval) -> String {
        let date = Date(timeIntervalSince1970: timestamp / 1000) // Convert milliseconds to seconds
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        return dateFormatter.string(from: date)
    }

    private func bookAppointmentAPI() {
        
        self.view.endEditing(true)
        guard let selectedDate = selectedDate, let selectedTime = selectedTime else {
            return
        }
        
        let calendar = Calendar.current
        var combinedDateComponents = calendar.dateComponents([.year, .month, .day], from: selectedDate)
        let timeComponents = calendar.dateComponents([.hour, .minute], from: selectedTime)
        combinedDateComponents.hour = timeComponents.hour
        combinedDateComponents.minute = timeComponents.minute
        let combinedDate = calendar.date(from: combinedDateComponents)!
        let appointmentTimestamp = combinedDate.timeIntervalSince1970 * 1000
        let requestModel = BookAppointmentModel(doctorId: self.docId,
                                                patientName: self.txtFldPatientName.text,
                                                patientAge: Int(self.txtFldAge.text ?? "0"),
                                                patientGender: selectedGender,
                                                syptoms:  self.txtViewSymptoms.text,
                                                note:  self.txtViewNotes.text,
                                                appointmentDate: Int(appointmentTimestamp))
        self.viewModel?.bookAppointment(requestModel: requestModel) { _ in
            let storyboard = UIStoryboard(name: "PatientsModule", bundle: nil)
            guard let vc = storyboard.instantiateViewController(withIdentifier: "AppointmentBookedVC") as? AppointmentBookedVC else {
                return
            }
            vc.model = requestModel
            vc.viewModel = self.viewModel
            self.navigationController?.pushViewController(vc, animated: true)
        } failure: { error in
            ErrorHandler.shared.handleError(error: error)
        }
    }
}

extension BookAppointmentVC: LocationServiceDelegate {
    func tracingLocation(currentLocation: CLLocation) {
        print("::: Location Permission: \(currentLocation)")
        self.location = currentLocation
        self.getDocDetails(id: docId ?? 0, location: currentLocation)
    }
    
    func tracingLocationDidFailWithError(error: Error) {
        
    }
    
    func tracingAddress(address: String) {
    }
    
    func getDocDetails(id: Int, location: CLLocation?) {
        self.showSpinner()
        self.viewModel?.getDocDetails(id: docId ?? 0, lat: location?.coordinate.latitude.toString() ?? "", long: location?.coordinate.longitude.toString() ?? "", success: { _ in
            self.hideSpinner()
            self.daysCollectionView.reloadData()
            self.hoursCollectionView.reloadData()
        }, failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        })
    }
    
    func getTimeSlots(date: Int64?) {
        self.showSpinner()
        self.viewModel?.getTimeSlots(id: docId ?? 0, date: date ?? 0, success: { _ in
            self.hideSpinner()
            self.hoursCollectionView.reloadData()
        }, failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
            self.hideSpinner()
        })
    }
}


class DaysCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var lblDayName: UILabel!
    @IBOutlet weak var lblDayNumber: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Set corner radius
        viewBackground.layer.cornerRadius = 12
        // Ensure that the corners are properly rounded
        viewBackground.layer.masksToBounds = true
        viewBackground.layer.borderWidth = 1
        viewBackground.layer.borderColor = UIColor.systemGray3.cgColor
    }
}

class HoursCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var lblTime: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Set corner radius
        viewBackground.layer.cornerRadius = 12
        // Ensure that the corners are properly rounded
        viewBackground.layer.masksToBounds = true
        viewBackground.layer.borderWidth = 1
        viewBackground.layer.borderColor = UIColor.systemGray3.cgColor
    }
}
