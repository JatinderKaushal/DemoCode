//
//  PatientsHomeVC.swift
//  Doctors
//
//  Created by aksa nazir on 15/03/24.
//

import UIKit
import Kingfisher
import CoreLocation

class PatientsHomeVC: UIViewController {
    
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBOutlet weak var txtFldLocation: UITextField!
    @IBOutlet weak var btnCurrentLocation: UIButton!
    @IBOutlet weak var bookedCollectionView: UICollectionView!
    @IBOutlet weak var categoryCollectionView: UICollectionView!
    @IBOutlet weak var btnNearby: UIButton!
    @IBOutlet weak var nearbyCollectionView: UICollectionView!
    var viewModel = PatientsHomeViewModel()
    @IBOutlet weak var categoryCollectionViewHeight: NSLayoutConstraint!
    var loc = CLLocation()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Register collection view cells
        bookedCollectionView.register(UINib(nibName: "BookedCollectionView", bundle: nil), forCellWithReuseIdentifier: "BookedCollectionView")
        categoryCollectionView.register(UINib(nibName: "CategoryCollectionView", bundle: nil), forCellWithReuseIdentifier: "CategoryCollectionView")
        nearbyCollectionView.register(UINib(nibName: "NearbyCollectionView", bundle: nil), forCellWithReuseIdentifier: "NearbyCollectionView")
        LocationService.sharedInstance.delegate = self
        LocationService.sharedInstance.realTimeLocation = false
        LocationService.sharedInstance.startUpdatingLocation()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let height = categoryCollectionView.collectionViewLayout.collectionViewContentSize.height
        categoryCollectionViewHeight.constant = height
        self.view.layoutIfNeeded()
    }
    
    
    @IBAction func btnNearbyAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "PatientsModule", bundle: nil)
        guard let vc = storyboard.instantiateViewController(withIdentifier: "DoctorListVC") as? DoctorListVC else {return}
        vc.location = loc
        vc.cameFromNearby = true
        vc.viewModel = self.viewModel
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}

// MARK: - UICollectionViewDataSource
extension PatientsHomeVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch collectionView {
        case bookedCollectionView:
            
            return viewModel.patientHomeData?.response?.recentAppointments?.count ?? 0
        case categoryCollectionView:
            return viewModel.patientHomeData?.response?.categories?.count ?? 0
        case nearbyCollectionView:
            return viewModel.patientHomeData?.response?.nearbyDoctors?.count ?? 0
        default:
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // Dequeue and configure cell based on collection view
        guard let response = viewModel.patientHomeData?.response else { return UICollectionViewCell() }
        switch collectionView {
        case bookedCollectionView:
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BookedCollectionView", for: indexPath) as? BookedCollectionView else {
                return UICollectionViewCell()
            }
            
            cell.lblName.text = response.recentAppointments?[indexPath.row].docName ?? ""
            cell.lblType.text = response.recentAppointments?[indexPath.row].doctorType ?? ""
            cell.lblDate.text = (response.recentAppointments?[indexPath.row].appointmentDate ?? 0).convertToDateString(format: .dd_MMM_yyyy_EEEE) ?? ""
            cell.lblDistance.text = "\((response.recentAppointments?[indexPath.row].distance ?? 0.0).rounded()) KM"
            cell.imgView.layer.cornerRadius = 25
            cell.viewBackground.layer.cornerRadius = 12
            
            if let imgUrl = URL(string: Api.imageUrl(endpoint: response.recentAppointments?[indexPath.row].docImage ?? "")){
                cell.imgView.kf.setImage(with: imgUrl, placeholder: UIImage(named: "doc"), options: nil, completionHandler: nil)
            }
            return cell
        case categoryCollectionView:
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCollectionView", for: indexPath) as? CategoryCollectionView else {
                return UICollectionViewCell()
            }
            cell.viewBackground.layer.cornerRadius = cell.viewBackground.frame.size.width/1.8
            cell.imgView.layer.cornerRadius = cell.imgView.frame.size.width/1.8
            if let imgUrl = URL(string: Api.imageUrl(endpoint: response.categories?[indexPath.row].image ?? "")){
                cell.imgView.kf.setImage(with: imgUrl, placeholder: nil, options: nil, completionHandler: nil)
            }
            cell.lblType.text = response.categories?[indexPath.row].category ?? ""
            return cell
        case nearbyCollectionView:
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NearbyCollectionView", for: indexPath) as? NearbyCollectionView else {
                return UICollectionViewCell()
            }
            cell.viewBackground.layer.cornerRadius = 12
            cell.imgView.layer.cornerRadius = 10
            if let imgUrl = URL(string: Api.imageUrl(endpoint: response.nearbyDoctors?[indexPath.row].image ?? "")){
                cell.imgView.kf.setImage(with: imgUrl, placeholder: UIImage(named: "doc"), options: nil, completionHandler: nil)
            }
            cell.lblName.text = response.nearbyDoctors?[indexPath.row].name ?? ""
            cell.lblType.text = response.nearbyDoctors?[indexPath.row].category ?? ""
            cell.lblDistance.text = "\(response.nearbyDoctors?[indexPath.row].distance ?? 0) KM"
            return cell
        default:
            fatalError("Unexpected collection view")
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "PatientsModule", bundle: nil)
        switch collectionView {
        case bookedCollectionView:
            guard let vc = storyboard.instantiateViewController(withIdentifier: "BookAppointmentVC") as? BookAppointmentVC else {
                return
            }
            vc.location = self.loc
            vc.viewModel = self.viewModel
            vc.docId = viewModel.patientHomeData?.response?.recentAppointments?[indexPath.row].doctorId
            self.navigationController?.pushViewController(vc, animated: true)
        case categoryCollectionView:
            guard let vc = storyboard.instantiateViewController(withIdentifier: "DoctorListVC") as? DoctorListVC else {
                return
            }
            vc.cameFromNearby = false
            vc.viewModel = self.viewModel
            vc.categoryId = viewModel.patientHomeData?.response?.categories?[indexPath.row].id
            self.navigationController?.pushViewController(vc, animated: true)
        case nearbyCollectionView:
            guard let vc = storyboard.instantiateViewController(withIdentifier: "DoctorDetailVC") as? DoctorDetailVC else {
                return
            }
            vc.viewModel = self.viewModel
            vc.docId = viewModel.patientHomeData?.response?.nearbyDoctors?[indexPath.row].id
            vc.location = self.loc
            self.navigationController?.pushViewController(vc, animated: true)
            
        default:
            return
        }
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let collectionWidth = collectionView.bounds.width
        switch collectionView {
        case bookedCollectionView:
            return CGSize(width: collectionWidth, height: 150)
            
        case categoryCollectionView:
            return CGSize(width: (collectionWidth/3)-7, height: 140)
            
        case nearbyCollectionView:
            return CGSize(width: collectionWidth, height: 100)
            
        default:
            break
        }
        return CGSize(width: collectionWidth, height: 120)
    }
}

// MARK: -  API calls
extension PatientsHomeVC {
    func getPatientHomeData(location:CLLocation) {
        self.showSpinner()
        self.viewModel.getPatientHomeData(lat: "\(location.coordinate.latitude)", long: "\(location.coordinate.longitude)", success: { _ in
            self.hideSpinner()
            self.bookedCollectionView.reloadData()
            self.categoryCollectionView.reloadData()
            self.nearbyCollectionView.reloadData()
        }, failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        })
    }
    
    func getNearbyDoctors(location:CLLocation?,
                          search: String?,
                          distance: String?,
                          categoryId: Int?) {
        self.showSpinner()
        self.viewModel.getNearbyDoctors(lat: "\(location?.coordinate.latitude)",
                                        lng: "\(location?.coordinate.longitude)",
                                        search: search,
                                        distance: distance,
                                        categoryId: categoryId,
                                        success: { _ in
            self.hideSpinner()
            
        }, failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        })
    }
}

extension PatientsHomeVC: LocationServiceDelegate {
    func tracingLocation(currentLocation: CLLocation) {
            print("::: Location Permission: \(currentLocation)")
            self.loc = currentLocation
            self.getPatientHomeData(location:currentLocation)

        }
        
        func tracingLocationDidFailWithError(error: Error) {
            
        }
        
        func tracingAddress(address: String) {
            self.txtFldLocation.text = address
        }
}
