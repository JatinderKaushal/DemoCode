//
//  NearbyCollectionView.swift
//  Doctors
//
//  Created by Aksa on 01/04/24.
//

import UIKit

class NearbyCollectionView: UICollectionViewCell {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    
}
