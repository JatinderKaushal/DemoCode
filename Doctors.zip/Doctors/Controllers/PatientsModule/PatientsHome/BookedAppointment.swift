//
//  BookedAppointment.swift
//  Doctors
//
//  Created by Aksa on 17/04/24.
//

import Foundation
struct BookedAppointment : Codable {
    let appointmentId : Int?
    let message : String?

    enum CodingKeys: String, CodingKey {

        case appointmentId = "appointmentId"
        case message = "message"
       
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        appointmentId = try values.decodeIfPresent(Int.self, forKey: .appointmentId)
        message = try values.decodeIfPresent(String.self, forKey: .message)
    }

}
