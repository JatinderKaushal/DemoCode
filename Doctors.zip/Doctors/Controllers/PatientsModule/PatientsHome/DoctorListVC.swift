//
//  DoctorListVC.swift
//  Doctors
//
//  Created by Aksa on 01/04/24.
//

import UIKit
import CoreLocation

class DoctorListVC: UIViewController {
    
    @IBOutlet weak var txtFldsearchBar: UITextField!
    @IBOutlet weak var btnClear: UIButton!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var lbltitle: UILabel!
    
    var viewModel: PatientsHomeViewModel?
    var location: CLLocation?
    var refreshControl = UIRefreshControl()
    var cameFromNearby = false
    var categoryId: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtFldsearchBar.delegate = self
        self.refreshControl.addTarget(self, action: #selector(refreshData(_:)), for: .valueChanged)
        self.tblView.refreshControl = refreshControl
        if cameFromNearby {
            viewModel?.currentPage = 1
            viewModel?.nearByDoctors.removeAll()
            self.getNearbyDoctors(search: nil,distance: nil,categoryId: nil)
        } else {
            viewModel?.currentPage = 1
            viewModel?.nearByDoctors.removeAll()
            self.getNearbyDoctors(search: nil,distance: nil,categoryId: categoryId)
        }
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc private func refreshData(_ sender: Any) {
        // Perform your data fetching here
        self.viewModel?.currentPage = 1
        self.txtFldsearchBar.delegate = self
        self.viewModel?.nearByDoctors.removeAll()
        if self.cameFromNearby {
            self.getNearbyDoctors(search: nil, distance: nil,categoryId: nil)
            self.endRefreshing()
        } else {
            self.getNearbyDoctors(search: nil,distance: nil,categoryId: categoryId)
            self.endRefreshing()
        }
    }
    
    func endRefreshing() {
        DispatchQueue.main.async { [weak self] in
            self?.refreshControl.endRefreshing()
        }
    }
    
    @IBAction func clearAction(_ sender: Any) {
        self.viewModel?.currentPage = 1
        self.btnClear.isHidden = true
        self.txtFldsearchBar.text = nil
        self.viewModel?.nearByDoctors.removeAll()
        if cameFromNearby {
            self.getNearbyDoctors(search: nil, distance: nil,categoryId: nil)
        } else {
            self.getNearbyDoctors(search: nil,distance: nil,categoryId: categoryId)
        }
    }
}

extension DoctorListVC: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField.text!.count >= 3 {
            // Call your API
            self.btnClear.isHidden = false
            viewModel?.nearByDoctors.removeAll()
            viewModel?.currentPage = 1
            if cameFromNearby {
                self.getNearbyDoctors(search: textField.text!, distance: nil,categoryId: nil)
            } else {
                self.getNearbyDoctors(search: textField.text!,distance: nil,categoryId: categoryId)
            }
        } else {
            self.btnClear.isHidden = true
        }
        self.btnClear.isHidden = false
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.btnClear.isHidden = false
    }
}

extension DoctorListVC : UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.viewModel?.nearByDoctors.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "DoctorListCell") as? DoctorListCell else {
            return UITableViewCell()
        }
        if let obj = viewModel?.nearByDoctors[indexPath.row] {
            cell.fetchData(image: obj.image,
                           imageType: obj.categoryImage,
                           name: obj.name,
                           type: obj.category,
                           distance: obj.distance)
            let capturedIndexPath = indexPath
            cell.btnCall.addTarget(self, action: #selector(callButtonTapped(_:)), for: .touchUpInside)
            cell.btnCall.tag = capturedIndexPath.row
        }
        return cell
    }
    
    // Action method for the btnCall button
    @objc func callButtonTapped(_ sender: UIButton) {
        let rowIndex = sender.tag
        guard let phoneNumber = viewModel?.nearByDoctors[rowIndex].phone else {
            return
        }
        if let phoneURL = URL(string: "tel://\(phoneNumber)"), UIApplication.shared.canOpenURL(phoneURL) {
            UIApplication.shared.open(phoneURL, options: [:], completionHandler: nil)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "PatientsModule", bundle: nil)
        guard let vc = storyboard.instantiateViewController(withIdentifier: "DoctorDetailVC") as? DoctorDetailVC else {
            return
        }
        vc.viewModel = self.viewModel
        vc.docId = viewModel?.nearByDoctors[indexPath.row].id
        vc.location = self.location
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if let viewModel = self.viewModel {
            if cameFromNearby {
                if indexPath.row == ( self.viewModel?.nearByDoctors.count ?? 0) - 1, self.viewModel?.currentPage ?? 1 < viewModel.totalPages {
                    viewModel.currentPage += 1
                    
                    self.getNearbyDoctors(search: nil, distance: nil,categoryId: nil)
                }
            } else {
                if indexPath.row == ( self.viewModel?.nearByDoctors.count ?? 0) - 1, self.viewModel?.currentPage ?? 1 < viewModel.totalPages {
                    viewModel.currentPage += 1
                    self.getNearbyDoctors(search: nil,distance: nil,categoryId: categoryId)
                }
            }
        }
    }
    
    func getNearbyDoctors(search: String?,
                          distance: String?,
                          categoryId: Int?) {
        self.showSpinner()
        let lat = self.location?.coordinate.latitude ?? nil
        let lng = self.location?.coordinate.longitude ?? nil
        self.viewModel?.getNearbyDoctors(lat: "\(lat)",
                                         lng: "\(lng)",
                                         search: search,
                                         distance: distance,
                                         categoryId: categoryId,
                                         success: { _ in
            self.hideSpinner()
            if self.cameFromNearby {
                self.lbltitle.text = "Nearby Doctors"
            } else {
                self.lbltitle.text = "Categories"
            }
            self.tblView.reloadData()
        }, failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        })
    }
}


class DoctorListCell: UITableViewCell {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var imgViewType: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var btnCall: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.viewBackground.layer.cornerRadius = 12
    }
    
    func fetchData(image: String?, imageType: String?, name: String?, type: String?, distance: Double?) {
        self.imgView.kf.setImage(with: URL(string:Api.MainUrl+(image ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
        self.imgViewType.kf.setImage(with: URL(string:Api.MainUrl+(imageType ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
        self.lblName.text = name ?? ""
        self.lblType.text = type ?? ""
        self.lblDistance.text = "\(distance ?? 1)"
    }
}
