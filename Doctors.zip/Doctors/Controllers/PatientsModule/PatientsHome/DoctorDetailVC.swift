//
//  DoctorDetailVC.swift
//  Doctors
//
//  Created by Aksa on 01/04/24.
//

import UIKit
import CoreLocation

class DoctorDetailVC: UIViewController {

    @IBOutlet weak var imgViewProfile: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgViewType: UIImageView!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var imgViewDistance: UIImageView!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var viewPersonalInfo: UIView!
    @IBOutlet weak var lblPersonalInfo: UILabel!
    @IBOutlet weak var viewAvailability: UIView!
    @IBOutlet weak var btnAvailability: UIButton!
    @IBOutlet weak var viewAddress: UIView!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var btnBookAppointment: UIButton!
    
    var viewModel: PatientsHomeViewModel?
    var docId: Int?
    var location: CLLocation?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.imgViewProfile.layer.cornerRadius = 18
        self.btnBookAppointment.layer.cornerRadius = 12
        self.viewPersonalInfo.layer.cornerRadius = 12
        self.viewAvailability.layer.cornerRadius = 12
        self.viewAddress.layer.cornerRadius = 12
        self.getDocDetails(id: docId ?? 0, location: location ?? nil)
    }

    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnAvailabilityAction(_ sender: Any) {
        var storyboard = UIStoryboard(name: "PatientsModule", bundle: nil)
        guard let vc = storyboard.instantiateViewController(identifier: "CheckAvailablity") as? CheckAvailablity else {
            return
        }
        vc.workingHours = (viewModel?.docDetails?.response?.workingHours!)!
        self.present(vc, animated: true)
    }
    
    @IBAction func btnbookAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "PatientsModule", bundle: nil)
        guard let vc = storyboard.instantiateViewController(withIdentifier: "BookAppointmentVC") as? BookAppointmentVC else {
            return
        }
        vc.viewModel = self.viewModel
        vc.docId = self.viewModel?.docDetails?.response?.id ?? 0
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func renderData() {
        if let obj = self.viewModel?.docDetails {
            self.imgViewProfile.kf.setImage(with: URL(string:Api.MainUrl+(obj.response?.image ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
            self.imgViewType.kf.setImage(with: URL(string:Api.MainUrl+(obj.response?.specialization?[0].image ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
            self.lblName.text = obj.response?.name
            self.lblType.text = obj.response?.specialization?[0].category
            self.lblDistance.text = obj.response?.distance?.toString()
            self.lblPersonalInfo.text = obj.response?.personalInfo
            self.lblAddress.text = obj.response?.address
        }
    }
    
    func getDocDetails(id: Int, location: CLLocation?) {
        self.showSpinner()
        self.viewModel?.getDocDetails(id: id, lat: location?.coordinate.latitude.toString() ?? "", long: location?.coordinate.longitude.toString() ?? "", success: { _ in
            self.hideSpinner()
            self.renderData()
        }, failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        })
    }
}
