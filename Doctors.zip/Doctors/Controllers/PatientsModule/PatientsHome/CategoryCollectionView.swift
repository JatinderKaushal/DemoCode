//
//  CategoryCollectionView.swift
//  Doctors
//
//  Created by Aksa on 01/04/24.
//

import UIKit

class CategoryCollectionView: UICollectionViewCell {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblType: UILabel!
    
}
