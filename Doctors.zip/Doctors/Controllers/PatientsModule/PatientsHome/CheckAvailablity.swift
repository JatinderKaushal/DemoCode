//
//  CheckAvailablity.swift
//  Doctors
//
//  Created by aksa nazir on 09/04/24.
//

import Foundation
import UIKit

class CheckAvailablity: UIViewController {
    
    var workingHours: [NearbyDocWorkingHours] = [] // Assuming this variable holds your working hours data
    
    @IBOutlet weak var viewAvailability: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        parseAndPresentWorkingHours()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.view.backgroundColor = .clear
    }
    
    @IBAction func btnCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func parseAndPresentWorkingHours() {
        var yOffset: CGFloat = 45 // Initial y offset to position the first label
            let labelHeight: CGFloat = 30 // Height of each label
            let margin: CGFloat = 10 // Margin between labels
            
        for dayData in workingHours {
            let dayName = dayData.dayName
            let startTimeStamp = Double(dayData.startTime ?? Int(0.0))
            let endTimeStamp = Double(dayData.endTime ?? Int(0.0))
            
            let startTime = formatTimeFromTimestamp(startTimeStamp)
            let endTime = formatTimeFromTimestamp(endTimeStamp)
            
            let formattedDay = "\(dayName ?? " ") (\(startTime) - \(endTime))"
            print(formattedDay) 
            let label = UILabel(frame: CGRect(x: 20, y: yOffset, width: viewAvailability.frame.width - 40, height: labelHeight))
                   label.text = formattedDay
                   label.textAlignment = .left
                   self.viewAvailability.addSubview(label)
                   
                   yOffset += labelHeight + margin
        }
    }

    
    func formatTimeFromTimestamp(_ timestamp: TimeInterval) -> String {
        let date = Date(timeIntervalSince1970: timestamp / 1000) // Convert milliseconds to seconds
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        return dateFormatter.string(from: date)
    }
}
