//
//  PatientsHomeModel.swift
//  Doctors
//
//  Created by Jatinder on 03/04/24.
//

import Foundation
struct PatientsHomeModel : Codable {
    let message : String?
    let response : DoctorDetailsData?
    
    enum CodingKeys: String, CodingKey {
        
        case message = "message"
        case response = "response"
    }
}

struct DoctorDetailsData : Codable {
    let recentAppointments : [RecentAppointments]?
    let categories : [Categories]?
    let nearbyDoctors : [NearbyDoctors]?

    enum CodingKeys: String, CodingKey {
        case recentAppointments = "recentAppointments"
        case categories = "categories"
        case nearbyDoctors = "nearbyDoctors"
    }
}

struct RecentAppointments : Codable {
    let id : Int?
    let appointPatientName : String?
    let note : String?
    let syptoms : String?
    let appointmentDate : Int?
    let doctorId : Int?
    let docName : String?
    let docImage : String?
    let docPhone : String?
    let appointment_status : Int?
    let distance : Double?
    let patientId : Int?
    let patientAge : Int?
    let patientGender : Int?
    let patientName : String?
    let patientImage : String?
    let patientPhone : String?
    let appointmentDateStr : String?
    let doctorType : String?
    let specialization : [DocSpecialization]?
    enum CodingKeys: String, CodingKey {
        case id = "id"
        case appointPatientName = "appointPatientName"
        case note = "note"
        case syptoms = "syptoms"
        case appointmentDate = "appointmentDate"
        case doctorId = "doctorId"
        case docName = "docName"
        case docImage = "docImage"
        case docPhone = "docPhone"
        case appointment_status = "appointment_status"
        case distance = "distance"
        case patientId = "patientId"
        case patientAge = "patientAge"
        case patientGender = "patientGender"
        case patientName = "patientName"
        case patientImage = "patientImage"
        case patientPhone = "patientPhone"
        case appointmentDateStr = "appointmentDateStr"
        case doctorType = "doctorType"
        case specialization = "specialization"
        
    }
}

struct Categories : Codable {
    let id : Int?
    let category : String?
    let image : String?

    enum CodingKeys: String, CodingKey {
        case id = "id"
        case category = "category"
        case image = "image"
    }
}

struct NearbyDoctors : Codable {
    let id : Int?
    let name : String?
    let image : String?
    let address : String?
    let status : Int?
    let email : String?
    let personalInfo : String?
    let phone : String?
    let category : String?
    let categoryImage : String?
    let dsID : Int?
    let specialStatus : Int?
    let distance : Int?
    let specialization : [DoctorSpecialize]?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case name = "name"
        case image = "image"
        case address = "address"
        case status = "status"
        case email = "email"
        case personalInfo = "personalInfo"
        case phone = "phone"
        case category = "category"
        case categoryImage = "categoryImage"
        case dsID = "dsID"
        case specialStatus = "specialStatus"
        case distance = "distance"
        case specialization = "specialization"
    }
    
}

struct DoctorSpecialize : Codable {
    let dsID : Int?
    let id : Int?
    let category : String?
    let image : String?

    enum CodingKeys: String, CodingKey {

        case dsID = "dsID"
        case id = "id"
        case category = "category"
        case image = "image"
    }

}
    // Nearby doctors API

