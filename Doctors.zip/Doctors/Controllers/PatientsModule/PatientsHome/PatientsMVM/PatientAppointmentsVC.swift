//
//  PatientAppointmentsVC.swift
//  Doctors
//
//  Created by Aksa on 03/04/24.
//

import UIKit

class PatientAppointmentsVC: UIViewController, FiltersDelegate {

    @IBOutlet weak var txtFldSearch: UITextField!
    @IBOutlet weak var btnClear: UIButton!
    @IBOutlet weak var btnfilter: UIButton!
    @IBOutlet weak var tblView: UITableView!
    
    private var arrFilters = [Int]()
    var viewModel = PatientAppointmentsVM()
    var isLoading = false
    var refreshControl = UIRefreshControl()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblView.delegate = self
        self.tblView.dataSource = self
        self.txtFldSearch.delegate = self
        self.refreshControl.addTarget(self, action: #selector(refreshData(_:)), for: .valueChanged)
        self.tblView.refreshControl = refreshControl
        self.getUpcomingAppointments(search: "", status: [])
    }
    internal func selectedFilters(arr:[Int]){
        for uid in arr{
            if !self.arrFilters.contains(uid){
                self.arrFilters.append(uid)
            }
        }
    }
    
    @objc private func refreshData(_ sender: Any) {
        // Perform your data fetching here
        viewModel.currentPage = 1
        viewModel.upcomingAppointmnets.removeAll()
        getUpcomingAppointments(search: txtFldSearch.text ?? "", status: [])
        endRefreshing()
    }
    func endRefreshing() {
        DispatchQueue.main.async { [weak self] in
            self?.refreshControl.endRefreshing()
        }
    }
    
    func didApplyFilters(arr: [Int]) {
            selectedFilters(arr: arr)
        self.arrFilters.removeAll()
        self.arrFilters = arr
        viewModel.upcomingAppointmnets.removeAll()
        getUpcomingAppointments(search: "", status: arr) // Call API here
        }
    
    @IBAction func filterAction(_ sender: Any) {
        self.view.endEditing(true)
        let vc = FiltersVC.instantiateMain()
        vc.isFromAppointment = true
        vc.arrSelectedFilters = arrFilters
        vc.delegate = self // Set delegate
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }

    @IBAction func clearAction(_ sender: Any) {
        
        self.btnClear.isHidden = true
        self.txtFldSearch.text = nil
        viewModel.upcomingAppointmnets.removeAll()
        self.getUpcomingAppointments(search: "", status: [])

    }
}

extension PatientAppointmentsVC: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField.text!.count >= 3 {
            // Call your API
            self.btnClear.isHidden = false
            viewModel.upcomingAppointmnets.removeAll()
            getUpcomingAppointments(search: textField.text!, status: [])
        } else {
            self.btnClear.isHidden = true
        }
        self.btnClear.isHidden = false
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.btnClear.isHidden = false
       }
}

extension PatientAppointmentsVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.upcomingAppointmnets.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tblView.dequeueReusableCell(withIdentifier: "PatientAppointmentsCell") as? PatientAppointmentsCell else {
            return UITableViewCell()
        }
        let obj = viewModel.upcomingAppointmnets[indexPath.row]
        if let urlImg = URL(string: viewModel.getPicHistory(index: indexPath.row)){
            cell.imgViewProfile.layer.cornerRadius = 12
            cell.imgViewProfile.kf.setImage(with: urlImg, placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
        }
        if let specialisation = obj.specialization, !specialisation.isEmpty {
            cell.imgViewType.kf.setImage(with: URL(string:Api.MainUrl+(specialisation[0].image ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
            
            cell.lblType.text =  specialisation[0].category
            
        }else {
            cell.lblType.text = "N/A"
        }
   
            cell.lblDocName.text = obj.docName
            cell.lblDistance.text = obj.distance?.toString()
       
           
            cell.lblDate.text = viewModel.getAppointmentDate(index: indexPath.row)
            cell.lblDay.text = viewModel.getAppointmentDay(index: indexPath.row)
            cell.lblStatus.text = viewModel.getAppointmentStatus(index: indexPath.row)
            cell.viewStatus.backgroundColor = viewModel.getAppointmentStatusColor(index: indexPath.row)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let appointmentID = self.viewModel.upcomingAppointmnets[indexPath.row].id
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientAppointmentDetailsVC") as? PatientAppointmentDetailsVC else { return }
        vc.id = appointmentID
        vc.viewModel = self.viewModel
      //  vc.objDoctorAppointment = self.objDoctorAppointment
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        166.0
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == (self.viewModel.upcomingAppointmnets.count) - 1, self.viewModel.currentPage < viewModel.totalPages {
            viewModel.currentPage += 1
                self.getUpcomingAppointments(search: "", status: [])
        }
        }
}

// MARK: - Details of Appointment API Call
extension PatientAppointmentsVC {
  
    func getUpcomingAppointments(search: String, status: [Int]) {
        guard !isLoading else {
                      return
                  }
                  isLoading = true
        self.showSpinner()
        self.viewModel.getUpcomingAppointments(search: search, status: status) { _ in
            self.hideSpinner()
            self.isLoading = false
           self.tblView.reloadData()
            self.tblView.tableFooterView?.isHidden = false
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        }
    }
}


class PatientAppointmentsCell: UITableViewCell {
    @IBOutlet weak var imgViewProfile: UIImageView!
    @IBOutlet weak var lblDocName: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var imgViewType: UIImageView!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDay: UILabel!
    @IBOutlet weak var viewStatus: UIView!
    @IBOutlet weak var lblStatus: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.viewStatus.layer.cornerRadius = 15
    }
}
