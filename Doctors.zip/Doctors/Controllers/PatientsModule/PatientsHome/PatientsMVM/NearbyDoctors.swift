/* 
Copyright (c) 2024 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct GetNearbyDoctors : Codable {
	let message : String?
	let response : [NearbyDoctorsResponse]?
	let pageNo : Int?
	let totalPages : Int?
	let totalCount : Int?

	enum CodingKeys: String, CodingKey {

		case message = "message"
		case response = "response"
		case pageNo = "pageNo"
		case totalPages = "totalPages"
		case totalCount = "totalCount"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		message = try values.decodeIfPresent(String.self, forKey: .message)
		response = try values.decodeIfPresent([NearbyDoctorsResponse].self, forKey: .response)
		pageNo = try values.decodeIfPresent(Int.self, forKey: .pageNo)
		totalPages = try values.decodeIfPresent(Int.self, forKey: .totalPages)
		totalCount = try values.decodeIfPresent(Int.self, forKey: .totalCount)
	}

}

struct NearbyDoctorsResponse : Codable {
    let id : Int?
    let gender : Int?
    let name : String?
    let image : String?
    let address : String?
    let status : Int?
    let email : String?
    let personalInfo : String?
    let phone : String?
    let category : String?
    let categoryImage : String?
    let dsID : Int?
    let specialStatus : Int?
    let lat : Double?
    let lng : Double?
    let distance : Double?
    let specialization : [PatientSpecialization]?
    let workingHours : [NearbyDocWorkingHours]?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case gender = "gender"
        case name = "name"
        case image = "image"
        case address = "address"
        case status = "status"
        case email = "email"
        case personalInfo = "personalInfo"
        case phone = "phone"
        case category = "category"
        case categoryImage = "categoryImage"
        case dsID = "dsID"
        case specialStatus = "specialStatus"
        case lat = "lat"
        case lng = "lng"
        case distance = "distance"
        case specialization = "specialization"
        case workingHours = "workingHours"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        gender = try values.decodeIfPresent(Int.self, forKey: .gender)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        image = try values.decodeIfPresent(String.self, forKey: .image)
        address = try values.decodeIfPresent(String.self, forKey: .address)
        status = try values.decodeIfPresent(Int.self, forKey: .status)
        email = try values.decodeIfPresent(String.self, forKey: .email)
        personalInfo = try values.decodeIfPresent(String.self, forKey: .personalInfo)
        phone = try values.decodeIfPresent(String.self, forKey: .phone)
        category = try values.decodeIfPresent(String.self, forKey: .category)
        categoryImage = try values.decodeIfPresent(String.self, forKey: .categoryImage)
        dsID = try values.decodeIfPresent(Int.self, forKey: .dsID)
        specialStatus = try values.decodeIfPresent(Int.self, forKey: .specialStatus)
        lat = try values.decodeIfPresent(Double.self, forKey: .lat)
        lng = try values.decodeIfPresent(Double.self, forKey: .lng)
        distance = try values.decodeIfPresent(Double.self, forKey: .distance)
        specialization = try values.decodeIfPresent([PatientSpecialization].self, forKey: .specialization)
        workingHours = try values.decodeIfPresent([NearbyDocWorkingHours].self, forKey: .workingHours)
    }

}
struct NearbyDocWorkingHours : Codable {
    let day : Int?
    let isOpen : Int?
    let startTime : Int?
    let endTime : Int?
    let breakStartTime : Int?
    let breakEndTime : Int?
    let dayName : String?
    let dayShortName : String?

    enum CodingKeys: String, CodingKey {

        case day = "day"
        case isOpen = "isOpen"
        case startTime = "startTime"
        case endTime = "endTime"
        case breakStartTime = "breakStartTime"
        case breakEndTime = "breakEndTime"
        case dayName = "dayName"
        case dayShortName = "dayShortName"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        day = try values.decodeIfPresent(Int.self, forKey: .day)
        isOpen = try values.decodeIfPresent(Int.self, forKey: .isOpen)
        startTime = try values.decodeIfPresent(Int.self, forKey: .startTime)
        endTime = try values.decodeIfPresent(Int.self, forKey: .endTime)
        breakStartTime = try values.decodeIfPresent(Int.self, forKey: .breakStartTime)
        breakEndTime = try values.decodeIfPresent(Int.self, forKey: .breakEndTime)
        dayName = try values.decodeIfPresent(String.self, forKey: .dayName)
        dayShortName = try values.decodeIfPresent(String.self, forKey: .dayShortName)
    }

}
