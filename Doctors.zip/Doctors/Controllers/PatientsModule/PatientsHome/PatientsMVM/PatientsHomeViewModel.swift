//
//  PatientsHomeViewModel.swift
//  Doctors
//
//  Created by Jatinder on 03/04/24.
//

import Foundation
import Moya

class PatientsHomeViewModel: NSObject {
    
    var patientHomeData : PatientsHomeModel?
    var nearByDoctors: [NearbyDoctorsResponse] = []
    var docDetails: PatientsDocDetails?
    var currentPage = 1
    var totalPages = 1
    var timeSlots: [TimeSlotsResponse] = []
    var bookedAppointment: BookedAppointment?
    var patientHistory: [PatientResponse] = []
    var appointmentDetails : AppointmentDetailsResponse?
    
    func getPatientHomeData(lat: String, long: String,
                            success: @escaping successCallBack,
                            failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.getPatientHomeData(lat: lat, long: long)) { result in
            switch result {
            case let .success(moyaResponse):
                do {
                    if let data = try self.handleRepsonse(type: PatientsHomeModel.self, moyaResponse: moyaResponse) {
                        if data.message == "Unauthenticated" {
                            AlertManager.shared.showAlert(message: data.message ?? "Unauthenticated", actionTitles: ["ok"]) { _, _ in
                                let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
                                DefaultsClass.shared.isAlreadyIn = false
                                sceneDelegate.setRootViewController(viewController: SelectRoleViewController.instantiateMain())
                                failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                            }
                        } else {
                            self.patientHomeData = data
                            success(nil)

                        }
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
    
    func getNearbyDoctors(lat: String?,
                          lng: String?,
                          search: String?,
                          distance: String?,
                          categoryId:  Int?,
                          success: @escaping successCallBack,
                          failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.getNearbyDoctors(lat: lat, lng: lng, page: currentPage, search: search, distance: distance, categoryId: categoryId)) { result in
            switch result {
            case let .success(moyaResponse):
                
                do {
                    if let data = try self.handleRepsonse(type: GetNearbyDoctors.self, moyaResponse: moyaResponse) {
                        if let responseModel = data.response {
                            self.nearByDoctors.append(contentsOf: responseModel)
                        }
                        if let currentPage = data.pageNo, let totalPages = data.totalPages {
                            self.currentPage = currentPage
                            self.totalPages = totalPages
                        }
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
    
    func getDocDetails(id: Int, lat: String, long: String,
                       success: @escaping successCallBack,
                       failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.getDoctorDetails(id: id, lat: lat, long: long)) { result in
            switch result {
            case let .success(moyaResponse):
                
                do {
                    if let data = try self.handleRepsonse(type: PatientsDocDetails.self, moyaResponse: moyaResponse) {
                        self.docDetails = data
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
    
    func bookAppointment(requestModel: BookAppointmentModel,
                         success: @escaping successCallBack,
                         failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.bookAppointment(model: requestModel)) { result in
            switch result {
                
            case let .success(moyaResponse):
                do {
                    if let data = try self.handleRepsonse(type: BookedAppointment.self, moyaResponse: moyaResponse) {
                        self.bookedAppointment = data
                        success(nil)
                    } else {
                        let errorResponse = ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse)
                        failure(errorResponse)
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
    func getTimeSlots(id: Int, date: Int64,
                       success: @escaping successCallBack,
                       failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.getTimeSlots(id: id, date: date)) { result in
            switch result {
            case let .success(moyaResponse):
                
                do {
                    if let data = try self.handleRepsonse(type: GetTimeSlots.self, moyaResponse: moyaResponse) {
                        if let responseModel = data.response {
                            self.timeSlots.removeAll()
                            self.timeSlots.append(contentsOf: responseModel)
                        }
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
    
    func cancelAppointment(id: Int, reason: String,
                       success: @escaping successCallBack,
                       failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.cancelAppointment(id: id, reason: reason)) { result in
            switch result {
            case let .success(moyaResponse):
                
                do {
                    if let data = try self.handleRepsonse(type: commonModel.self, moyaResponse: moyaResponse) {
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
   

      
        func getPatientHistory(search: String?,
                            status: [Int],
                            success: @escaping successCallBack,
                            failure: @escaping failureCallBack) {
            
            let provider = MoyaProvider<Service>()
            provider.request(.getPatientsHistory(search: search, status: status, page: currentPage)) { result in
                switch result {
                case let .success(moyaResponse):
                    
                    do {
                        if let data = try self.handleRepsonse(type: GetPatientHistory.self, moyaResponse: moyaResponse) {
                           // self.patientHistory = data.response
                            if let responseModel = data.response {
                                self.patientHistory.append(contentsOf: responseModel)
                            }
                            if let currentPage = data.pageNo, let totalPages = data.totalPages {
                                self.currentPage = currentPage
                                self.totalPages = totalPages
                            }
                            success(nil)
                        } else {
                            failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                        }
                    } catch let error {
                        failure(error)
                    }
                    break
                case let .failure(error):
                    failure(error)
                    break
                }
            }
        }
        
        func getAppointmentDetails(id: Int,
                                   success: @escaping successCallBack,
                                   failure: @escaping failureCallBack) {
            
            let provider = MoyaProvider<Service>()
            provider.request(.getAPPointmentDetails(id: id)) { result in
                switch result {
                case let .success(moyaResponse):
                    
                    do {
                        if let data = try self.handleRepsonse(type: GetAppointmentDetails.self, moyaResponse: moyaResponse) {
                            self.appointmentDetails = data.response
                            success(nil)
                        } else {
                            failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                        }
                    } catch let error {
                        failure(error)
                    }
                    break
                case let .failure(error):
                    failure(error)
                    break
                }
            }
        }
        func getPicHistory(index:Int)->String{
            return Api.imageUrl(endpoint: patientHistory[index].docImage ?? "")
        }
        
        func getPicType(index:Int)->String{
            if let imageStr = patientHistory[index].specialization, !imageStr.isEmpty{
                return Api.imageUrl(endpoint: patientHistory[index].specialization?[0].image ?? "")
            }
            return ""
        }
        
        func getAppointmentDate(index:Int)->String{
            return (patientHistory[index].appointmentDate ?? 0)?.convertToDateString(format: .dd_MMM_yyyy) ?? ""
        }
        
        func getAppointmentDay(index:Int)->String{
            return (patientHistory[index].appointmentDate ?? 0)?.convertToDateString(format: .eeee) ?? ""
        }
         func getAppointmentStatus(index:Int)->String{
            return  Constants.EnumAppointmentStatus(rawValue: patientHistory[index].appointment_status ?? 0)?.str ?? "Add this to Constant file"
        }
         func getAppointmentStatusColor(index:Int)->UIColor?{
            return  Constants.EnumAppointmentStatus(rawValue: patientHistory[index].appointment_status ?? 0)?.clr
        }

        }

