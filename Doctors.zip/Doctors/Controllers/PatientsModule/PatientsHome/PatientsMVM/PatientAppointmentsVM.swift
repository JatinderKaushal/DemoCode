//
//  PatientAppointmentsVM.swift
//  Doctors
//
//  Created by aksa nazir on 05/04/24.
//

import Foundation
import Moya

class PatientAppointmentsVM: NSObject {
    var currentPage = 1
    var totalPages = 1
    var upcomingAppointmnets: [PatientResponse] = []
    var appointmentDetails : AppointmentDetailsResponse?
    func getUpcomingAppointments(search: String?,
                        status: [Int],
                        success: @escaping successCallBack,
                        failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.getUpcomingAppointments(search: search, status: status, page: currentPage)) { result in
            switch result {
            case let .success(moyaResponse):
                
                do {
                    if let data = try self.handleRepsonse(type: GetPatientHistory.self, moyaResponse: moyaResponse) {
                       // self.patientHistory = data.response
                        if data.message == "Unauthenticated" {
                            AlertManager.shared.showAlert(message: data.message ?? "Unauthenticated", actionTitles: ["ok"]) { _, _ in
                                                      let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
                                                      DefaultsClass.shared.isAlreadyIn = false
                                                      sceneDelegate.setRootViewController(viewController: SelectRoleViewController.instantiateMain())
                                                      failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                                                  }
                                              
                        }
                        if let responseModel = data.response {
                            self.upcomingAppointmnets.append(contentsOf: responseModel)
                        }
                        if let currentPage = data.pageNo, let totalPages = data.totalPages {
                            self.currentPage = currentPage
                            self.totalPages = totalPages
                        }
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
    func getPicHistory(index:Int)->String{
        return Api.imageUrl(endpoint: upcomingAppointmnets[index].docImage ?? "")
    }
    func getPicType(index:Int)->String{
        return Api.imageUrl(endpoint: upcomingAppointmnets[index].patientImage ?? "")
    }
    func getAppointmentDate(index:Int)->String{
        return (upcomingAppointmnets[index].appointmentDate ?? 0)?.convertToDateString(format: .dd_MMM_yyyy) ?? ""
    }
    func getAppointmentDay(index:Int)->String{
        return (upcomingAppointmnets[index].appointmentDate ?? 0)?.convertToDateString(format: .eeee) ?? ""
    }
     func getAppointmentStatus(index:Int)->String{
        return  Constants.EnumAppointmentStatus(rawValue: upcomingAppointmnets[index].appointment_status ?? 0)?.str ?? "Add this to Constant file"
    }
     func getAppointmentStatusColor(index:Int)->UIColor?{
        return  Constants.EnumAppointmentStatus(rawValue: upcomingAppointmnets[index].appointment_status ?? 0)?.clr
    }
    func getAppointmentDetails(id: Int,
                               success: @escaping successCallBack,
                               failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.getAPPointmentDetails(id: id)) { result in
            switch result {
            case let .success(moyaResponse):
                
                do {
                    if let data = try self.handleRepsonse(type: GetAppointmentDetails.self, moyaResponse: moyaResponse) {
                        self.appointmentDetails = data.response
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
    func uploadPrecription(appointmentId: Int, image:Data, success: @escaping successCallBack,
                           failure: @escaping failureCallBack) {
        let provider = MoyaProvider<Service>()
        provider.request(.uploadPrescription(appointmentId: "\(appointmentId)", prescriptions: image, fileName: "\(Int(NSDate().timeIntervalSince1970))")) { result in
            switch result {
            case .success(let response):
                do {
                    
                    if let data = try self.handleRepsonse(type: commonModel.self, moyaResponse: response) {
                        
                        if data.message == "Success"{
                            success(nil)
                        }else if data.message == "Unauthenticated" {
                            AlertManager.shared.showAlert(message: data.message ?? "Unauthenticated", actionTitles: ["ok"]) { _, _ in
                                let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
                                DefaultsClass.shared.isAlreadyIn = false
                                sceneDelegate.setRootViewController(viewController: SelectRoleViewController.instantiateMain())
                                
                                failure(ErrorHandler.shared.errorResponse(moyaResponse: response))
                            }
                            
                        }
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: response))
                    }
                } catch let error {
                    failure(error)// This code will run because the statusCode is 500
                }
                
            case .failure(let error):
                failure(error)
            }
        }
    }
}
