//
//  PatientAppointmentDetailsVC.swift
//  Doctors
//
//  Created by aksa nazir on 05/04/24.
//


import UIKit
import Kingfisher
import VisionKit
class PatientAppointmentDetailsVC: UIViewController, VNDocumentCameraViewControllerDelegate {
    
    @IBOutlet weak var imgView: ImageCustom!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgViewType: UIImageView!
    
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDay: UILabel!
    @IBOutlet weak var btnUpload: UIButton!
    @IBOutlet weak var clcView: UICollectionView!{
        didSet{
            clcView.delegate = self
            clcView.dataSource = self
        }
        
    }
    
    @IBOutlet weak var collectionViewPrecriptions: UICollectionView!
    
    var id: Int?
    var viewModel: PatientAppointmentsVM?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getAppointmentDetails(id: self.id ?? 0)
    }
    

    
    override func viewWillAppear(_ animated: Bool) {
        self.getAppointmentDetails(id: self.id ?? 0)
    }
    
    func renderData() {
        let obj = viewModel?.appointmentDetails
        self.imgView.kf.setImage(with: URL(string:Api.MainUrl+(obj?.docImage ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
        if let specialisation = obj?.specialization, !specialisation.isEmpty {
            self.imgViewType.kf.setImage(with: URL(string:Api.MainUrl+(obj?.specialization?[0].image ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
            self.lblType.text = obj?.specialization?[0].category
        }
        self.lblName.text = obj?.docName ?? ""
        self.lblDistance.text = obj?.distance
        self.lblDate.text = viewModel?.appointmentDetails?.appointmentDate?.convertToDateString(format: .dd_MMM_yyyy) ?? ""
        self.lblDay.text = viewModel?.appointmentDetails?.appointmentDate?.convertToDateString(format: .eeee) ?? ""
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    
    @IBAction func btnUploadPrecription(_ sender: Any) {
        if self.viewModel?.appointmentDetails?.status != 1 {
            btnUpload.isUserInteractionEnabled = false
        } else {
            displayScanningController()
        }
    }
    func displayScanningController() {
            guard VNDocumentCameraViewController.isSupported else { return }
            let controller = VNDocumentCameraViewController()
            controller.delegate = self
            present(controller, animated: true)
        }
}

extension PatientAppointmentDetailsVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.clcView {
            viewModel?.appointmentDetails?.prescription?.count ?? 0
        } else {
            viewModel?.appointmentDetails?.prescription?.count ?? 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.clcView {
            let cell = clcView.dequeueReusableCell(withReuseIdentifier: "PatientAppointmentDetailsClcCell", for: indexPath) as! PatientAppointmentDetailsClcCell
            cell.imgView.kf.setImage(with: URL(string: Api.MainUrl+(viewModel?.appointmentDetails?.prescription?[indexPath.item].prescription ?? "")), placeholder: nil, options: nil, completionHandler: nil)
            return cell
        } else {
            let cell = collectionViewPrecriptions.dequeueReusableCell(withReuseIdentifier: "PatientAPrecriptionClcCell", for: indexPath) as! PatientAPrecriptionClcCell
            cell.imgView.kf.setImage(with: URL(string: Api.MainUrl+(viewModel?.appointmentDetails?.prescription?[indexPath.item].prescription ?? "")), placeholder: nil, options: nil, completionHandler: nil)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == clcView {
            return CGSize(width: clcView.frame.width/4.5, height: clcView.frame.width/5.0)
        } else {
            return CGSize(width: 90 , height: 90)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let galleryVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ImageGalleryViewController") as! ImageGalleryViewController
        if let images = viewModel?.appointmentDetails?.prescription, images.count != 0 {
            galleryVC.images.removeAll()
            galleryVC.currentIndex = 0
            galleryVC.images = images
            galleryVC.currentIndex = indexPath.item
        }
        present(galleryVC, animated: true, completion: nil)
    }
        
}
extension PatientAppointmentDetailsVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else {
            // Add the picked image to the array
            return
        }
        picker.dismiss(animated: true) {
            
            let popUpVC = PrecriptionImageConfrimation()
            popUpVC.precriptionImage = image
            popUpVC.callBack = { tag in
                if (tag) {
//                    self.uploadPrecriptions(image: image)
                }
            }
            if let topVc = UIApplication.topViewController() {
                topVc.presentfromBottomToTop(vc: popUpVC)
            }
        }
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
// MARK: - API Calls
extension PatientAppointmentDetailsVC {
    
    private func uploadPrecriptions(image: Data) {
        guard let appointmentId = viewModel?.appointmentDetails?.id else {
            return
        }
        //  let images: [UIImage] = self.images
        //guard let finalimage = image.compress(maxKb: 300) else { return }
        // Call the uploadPrecription function
        viewModel?.uploadPrecription(appointmentId: appointmentId, image: image) { _ in
            self.getAppointmentDetails(id: self.id ?? 0)
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
            
        }
    }
    
    func getAppointmentDetails(id: Int) {
        
        self.viewModel?.getAppointmentDetails(id: id) { _ in
            self.renderData()
            self.collectionViewPrecriptions.reloadData()
            self.clcView.reloadData()
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        }
    }
    
}


class PatientAppointmentDetailsClcCell:UICollectionViewCell{
    
    @IBOutlet weak var imgView: UIImageView!
}

class PatientAPrecriptionClcCell:UICollectionViewCell{
    
    @IBOutlet weak var imgView: UIImageView!
}
