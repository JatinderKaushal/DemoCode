//
//  AppointmentBookedVC.swift
//  Doctors
//
//  Created by Aksa on 02/04/24.
//

import UIKit

class AppointmentBookedVC: UIViewController {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgViewProfile: UIImageView!
    @IBOutlet weak var imgViewType: UIImageView!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var lblCalender: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblPatientName: UILabel!
    @IBOutlet weak var lblAge: UILabel!
    @IBOutlet weak var lblSymptoms: UILabel!
    @IBOutlet weak var lblNotes: UILabel!
    @IBOutlet weak var btnGotit: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    
    var model :BookAppointmentModel?
    var viewModel : PatientsHomeViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.renderData()
    }
    
    private func renderData() {
        if let imgUrl = URL(string: Api.imageUrl(endpoint: viewModel?.docDetails?.response?.image ?? "")) {
            imgViewProfile.kf.setImage(with: imgUrl, placeholder: UIImage(named: "doc"), options: nil, completionHandler: nil)
            imgViewProfile.contentMode = .scaleAspectFill
        }
        if let imgUrl = URL(string: Api.imageUrl(endpoint: viewModel?.docDetails?.response?.specialization?.first?.image ?? "")) {
            imgViewType.kf.setImage(with: imgUrl, placeholder: UIImage(named: "doc"), options: nil, completionHandler: nil)
            imgViewType.contentMode = .scaleAspectFill
        }
        self.lblName.text = viewModel?.docDetails?.response?.name
        self.lblType.text = viewModel?.docDetails?.response?.specialization?.first?.category
        self.lblDistance.text = viewModel?.docDetails?.response?.distance?.toString()
        let timeString = convertTimeslotToTimeString(Int64(model?.appointmentDate ?? 0), format: "h:mm a")
        let dateString = convertTimeslotToTimeString(Int64(model?.appointmentDate ?? 0), format: "dd-MM-yyyy")
        self.lblTime.text = timeString
        self.lblCalender.text = dateString
        self.lblPatientName.text = model?.patientName
        self.lblAge.text = model?.patientAge?.toString()
        self.lblSymptoms.text = model?.syptoms
        self.lblNotes.text = model?.note
    }
    
    func convertTimeslotToTimeString(_ timeslot: Int64, format: String) -> String {
        let date = Date(timeIntervalSince1970: TimeInterval(timeslot) / 1000)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: date)
    }
    
    @IBAction func btnGotitAction(_ sender: Any) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func btnCancelAction(_ sender: Any) {
        AlertManager.shared.showInputAlert(title: "Please enter cancellation reason", placeholder: "Type here", saveActionTitle: "Ok", saveAction: { message in
            if let message = message {
                self.cancelAppointment(reason: message)
            } else {
                print("User cancelled")
            }
        }, cancelAction: nil)
    }
    
    func cancelAppointment(reason: String) {
        self.showSpinner()
        self.viewModel?.cancelAppointment(id: viewModel?.bookedAppointment?.appointmentId ?? 0, reason: reason, success: { _ in
            self.hideSpinner()
            let storyboard = UIStoryboard(name: "PatientsModule", bundle: nil)
            guard let vc = storyboard.instantiateViewController(withIdentifier: "PatientsHomeVC") as? PatientsHomeVC else {
                return
            }
            self.navigationController?.push(viewController: vc)
        }, failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
            self.hideSpinner()
        })
    }
}
