//
//  BookedCollectionView.swift
//  Doctors
//
//  Created by Aksa on 29/03/24.
//

import UIKit

class BookedCollectionView: UICollectionViewCell {
    
    @IBOutlet weak var viewBackground: UIView!
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var btnReschedule: UIButton!
    
    
}
