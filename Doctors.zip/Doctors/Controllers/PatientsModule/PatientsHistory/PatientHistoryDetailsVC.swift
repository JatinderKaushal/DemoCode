//
//  PatientHistoryDetailsVC.swift
//  Doctors
//
//  Created by aksa nazir on 05/04/24.
//


import UIKit
import Kingfisher
class PatientHistoryDetailsVC: UIViewController {
    
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var imgView: ImageCustom!
    @IBOutlet weak var imgViewType: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDay: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lbllStatus: UILabel!
    @IBOutlet weak var btnReschedule: UIButton!
    @IBOutlet weak var viewStatus: UIView!
    var index: Int?
    var id: Int?
    var viewModel: PatientsHomeViewModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getAppointmentDetails(id: self.id ?? 0)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        self.getAppointmentDetails(id: self.id ?? 0)
    }
    func renderData() {
        let obj = self.viewModel?.appointmentDetails
        self.imgView.kf.setImage(with: URL(string:Api.MainUrl+(obj?.docImage ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
        if let specialisation = obj?.specialization, !specialisation.isEmpty {
            self.imgViewType.kf.setImage(with: URL(string:Api.MainUrl+(specialisation[0].image ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
            self.lblType.text = specialisation[0].category ?? ""
        }
        self.lblName.text = obj?.docName
        self.lblDate.text = obj?.appointmentDate?.convertToDateString(format: .dd_MMM_yyyy)
        self.lblDay.text = obj?.appointmentDate?.convertToDateString(format: .eeee)
       
        self.lblDistance.text = obj?.distance
        let status = Constants.EnumAppointmentStatus(rawValue: obj?.status ?? 0)?.str
        self.lblStatus.text = status
        self.lbllStatus.text = status
        self.viewStatus.layer.cornerRadius = 15
        self.btnReschedule.layer.cornerRadius = 12
    }
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func btnRescheduleAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "PatientsModule", bundle: nil)
        guard let vc = storyboard.instantiateViewController(withIdentifier: "BookAppointmentVC") as? BookAppointmentVC else {
            return
        }
        vc.viewModel = self.viewModel
        vc.docId = self.viewModel?.appointmentDetails?.doctorId
        self.navigationController?.pushViewController(vc, animated: true)
    }
}



// MARK: - API Calls
extension PatientHistoryDetailsVC {
    
    func getAppointmentDetails(id: Int) {
        
        self.viewModel?.getAppointmentDetails(id: id) { _ in
            self.renderData()
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        }
    }
    
}
