//
//  PatientHistoryVC.swift
//  Doctors
//
//  Created by Aksa on 02/04/24.
//

import UIKit

class PatientHistoryVC: UIViewController, FiltersDelegate {
    @IBOutlet weak var btnClear: UIButton!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var btnFilter: UIButton!
    @IBOutlet weak var tblView: UITableView!
    
    private var arrFilters = [Int]()
    var viewModel = PatientsHomeViewModel()
    var isLoading = false
    var refreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblView.delegate = self
        self.tblView.dataSource = self
        self.txtSearch.delegate = self
        self.refreshControl.addTarget(self, action: #selector(refreshData(_:)), for: .valueChanged)
        self.tblView.refreshControl = refreshControl
        self.getPatientHistory(search: "", status: [])
      
    }
    
    internal func selectedFilters(arr:[Int]){
        for uid in arr{
            if !self.arrFilters.contains(uid){
                self.arrFilters.append(uid)
            }
        }
    }
    
    @objc private func refreshData(_ sender: Any) {
        // Perform your data fetching here
        viewModel.currentPage = 1
        viewModel.patientHistory.removeAll()
        getPatientHistory(search: txtSearch.text ?? "", status: [])
        endRefreshing()
    }

    func endRefreshing() {
        DispatchQueue.main.async { [weak self] in
            self?.refreshControl.endRefreshing()
        }
    }
    
    func didApplyFilters(arr: [Int]) {
            selectedFilters(arr: arr)
        self.arrFilters.removeAll()
        self.arrFilters = arr
        viewModel.patientHistory.removeAll()
        getPatientHistory(search: "", status: arr) // Call API here
        }
    
    @IBAction func filterAction(_ sender: Any) {
        self.view.endEditing(true)
        let vc = FiltersVC.instantiateMain()
        vc.isFromAppointment = false
        vc.arrSelectedFilters = arrFilters
        vc.delegate = self // Set delegate
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }

    @IBAction func clearAction(_ sender: Any) {
        
        self.btnClear.isHidden = true
        self.txtSearch.text = nil
        viewModel.patientHistory.removeAll()
        self.getPatientHistory(search: "", status: [])

    }
}

extension PatientHistoryVC: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField.text!.count >= 3 {
            // Call your API
            self.btnClear.isHidden = false
            viewModel.patientHistory.removeAll()
            getPatientHistory(search: textField.text!, status: [])
        } else {
            self.btnClear.isHidden = true
        }
        self.btnClear.isHidden = false
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.btnClear.isHidden = false
       }
}

extension PatientHistoryVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.patientHistory.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tblView.dequeueReusableCell(withIdentifier: "PatientHistoryCell") as? PatientHistoryCell else {
            return UITableViewCell()
        }
        let obj = viewModel.patientHistory[indexPath.row]
        if let urlImg = URL(string: viewModel.getPicHistory(index: indexPath.row)){
            cell.imgViewProfile.layer.cornerRadius = 12
            cell.imgViewProfile.kf.setImage(with: urlImg, placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
        }
        if let specialisation = obj.specialization, !specialisation.isEmpty {
            cell.lblType.text =  specialisation[0].category
            cell.imgViewType.kf.setImage(with: URL(string:Api.MainUrl+(specialisation[0].image ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
        
        } else {
            cell.lblType.text = "N/A"
        }
           
  
            cell.lblDocName.text = obj.docName
            cell.lblDistance.text = obj.distance?.toString()
       
            cell.lblDate.text = viewModel.getAppointmentDate(index: indexPath.row)
            cell.lblDay.text = viewModel.getAppointmentDay(index: indexPath.row)
            cell.lblStatus.text = viewModel.getAppointmentStatus(index: indexPath.row)
            cell.viewStatus.backgroundColor = viewModel.getAppointmentStatusColor(index: indexPath.row)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let appointmentID = self.viewModel.patientHistory[indexPath.row].id
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "PatientHistoryDetailsVC") as? PatientHistoryDetailsVC else { return }
        vc.id = appointmentID
        vc.viewModel = self.viewModel
      //  vc.objDoctorAppointment = self.objDoctorAppointment
        self.navigationController?.pushViewController(vc, animated: true)
    }
  
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        166.0
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == (self.viewModel.patientHistory.count) - 1, self.viewModel.currentPage < viewModel.totalPages {
            print("index",indexPath.row)
            print("count",viewModel.patientHistory.count)
            viewModel.currentPage += 1
                self.getPatientHistory(search: "", status: [])
        }
        }
}

// MARK: - Details of Appointment API Call
extension PatientHistoryVC {
  
    func getPatientHistory(search: String, status: [Int]) {
        guard !isLoading else {
                      return
                  }
                  isLoading = true
        self.showSpinner()
        self.viewModel.getPatientHistory(search: search, status: status) { _ in
            self.hideSpinner()
            self.isLoading = false
           self.tblView.reloadData()
            self.tblView.tableFooterView?.isHidden = false
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        }
    }
}

class PatientHistoryCell: UITableViewCell {
    @IBOutlet weak var imgViewProfile: UIImageView!
    @IBOutlet weak var lblDocName: UILabel!
    @IBOutlet weak var lblDistance: UILabel!
    @IBOutlet weak var imgViewType: UIImageView!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDay: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var viewStatus: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.viewStatus.layer.cornerRadius = 15
    }
}



