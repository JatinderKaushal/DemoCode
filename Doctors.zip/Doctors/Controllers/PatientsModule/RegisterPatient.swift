/* 
Copyright (c) 2024 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct RegisterPatient : Codable {
	let message : String?
	let response : RegisterResponse?

	enum CodingKeys: String, CodingKey {

		case message = "message"
		case response = "response"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		message = try values.decodeIfPresent(String.self, forKey: .message)
		response = try values.decodeIfPresent(RegisterResponse.self, forKey: .response)
	}

}
struct RegisterResponse : Codable {
    let id : Int?
    let name : String?
    let image : String?
    let status : Int?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case name = "name"
        case image = "image"
        case status = "status"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        image = try values.decodeIfPresent(String.self, forKey: .image)
        status = try values.decodeIfPresent(Int.self, forKey: .status)
    }

}
import Foundation
struct PatientProfile : Codable {
    let message : String?
    let response : PatientProfileData?

    enum CodingKeys: String, CodingKey {

        case message = "message"
        case response = "response"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        response = try values.decodeIfPresent(PatientProfileData.self, forKey: .response)
    }

}
import Foundation
struct PatientProfileData : Codable {
    let id : Int?
    let name : String?
    let gender : Int?
    let image : String?
    let phone : String?
    let email : String?
    let address : String?
    let personalInfo : String?
    let lat : String?
    let lng : String?
    let otp : String?
    let deviceToken : String?
    let status : Int?
    let isLogin : Int?
    let lastLoginAt : String?
    let createdAt : String?
    let updatedAt : String?
    let alreadyRegistered : Bool?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case name = "name"
        case gender = "gender"
        case image = "image"
        case phone = "phone"
        case email = "email"
        case address = "address"
        case personalInfo = "personalInfo"
        case lat = "lat"
        case lng = "lng"
        case otp = "otp"
        case deviceToken = "deviceToken"
        case status = "status"
        case isLogin = "isLogin"
        case lastLoginAt = "lastLoginAt"
        case createdAt = "createdAt"
        case updatedAt = "updatedAt"
        case alreadyRegistered = "alreadyRegistered"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        name = try values.decodeIfPresent(String.self, forKey: .name)
        gender = try values.decodeIfPresent(Int.self, forKey: .gender)
        image = try values.decodeIfPresent(String.self, forKey: .image)
        phone = try values.decodeIfPresent(String.self, forKey: .phone)
        email = try values.decodeIfPresent(String.self, forKey: .email)
        address = try values.decodeIfPresent(String.self, forKey: .address)
        personalInfo = try values.decodeIfPresent(String.self, forKey: .personalInfo)
        lat = try values.decodeIfPresent(String.self, forKey: .lat)
        lng = try values.decodeIfPresent(String.self, forKey: .lng)
        otp = try values.decodeIfPresent(String.self, forKey: .otp)
        deviceToken = try values.decodeIfPresent(String.self, forKey: .deviceToken)
        status = try values.decodeIfPresent(Int.self, forKey: .status)
        isLogin = try values.decodeIfPresent(Int.self, forKey: .isLogin)
        lastLoginAt = try values.decodeIfPresent(String.self, forKey: .lastLoginAt)
        createdAt = try values.decodeIfPresent(String.self, forKey: .createdAt)
        updatedAt = try values.decodeIfPresent(String.self, forKey: .updatedAt)
        alreadyRegistered = try values.decodeIfPresent(Bool.self, forKey: .alreadyRegistered)
    }

}
