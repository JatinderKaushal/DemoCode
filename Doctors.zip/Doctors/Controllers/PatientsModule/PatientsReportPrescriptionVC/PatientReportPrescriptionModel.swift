//
//  PatientReportPrescriptionModel.swift
//  Doctors
//
//  Created by Jatinder on 05/04/24.
//

import Foundation

struct PatientReportPrescriptionModel : Codable {
    let message : String?
    let response : [PatientResult]?
    
    enum CodingKeys: String, CodingKey {
        case message = "message"
        case response = "response"
    }
}

struct PatientResult : Codable {
    let folderName : Int?
    let month : Int?
    let year : Int?
    let reports : [PrescriptionRes]?
    
    enum CodingKeys: String, CodingKey {
        case folderName = "folderName"
        case month = "month"
        case year = "year"
        case reports = "reports"
    }
}

struct PrescriptionRes : Codable {
    let id : Int?
    let prescription : String?
    let report : String?
    let createdAt : Int?

    enum CodingKeys: String, CodingKey {
        case id = "id"
        case prescription = "prescription"
        case report = "report"
        case createdAt = "createdAt"
    }
}

