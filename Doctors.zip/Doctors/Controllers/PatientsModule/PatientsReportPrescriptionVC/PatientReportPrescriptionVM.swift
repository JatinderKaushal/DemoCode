//
//  PatientReportPrescriptionVM.swift
//  Doctors
//
//  Created by Jatinder on 05/04/24.
//

import Foundation
import Moya

class PatientReportPrescriptionVM: NSObject {
    var patientResult: PatientReportPrescriptionModel?
    func getPatientReportPrescription(isReport: Bool,
                        success: @escaping successCallBack,
                        failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(isReport == true ? .getReports : .getPrescriptions) { result in
            switch result {
            case let .success(moyaResponse):
                
                do {
                    if let data = try self.handleRepsonse(type: PatientReportPrescriptionModel.self, moyaResponse: moyaResponse) {
                        self.patientResult = data

                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
}
