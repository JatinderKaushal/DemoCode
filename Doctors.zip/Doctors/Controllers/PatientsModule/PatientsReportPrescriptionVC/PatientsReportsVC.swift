//
//  PatientsReportsVC.swift
//  Doctors
//
//  Created by Aksa on 03/04/24.
//

import UIKit

class PatientsReportsVC: UIViewController {
    var viewModel = PatientReportPrescriptionVM()
    var isReport = false
    @IBOutlet weak var lblNavigation: UILabel!
    @IBOutlet weak var clcview: UICollectionView!{
        didSet {
            self.clcview.delegate = self
            self.clcview.dataSource = self
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        lblNavigation.text = isReport == true ? "Reports" : "Prescriptions"
        getPatientList()
    }

    func getPatientList() {
        self.showSpinner()
        self.viewModel.getPatientReportPrescription(isReport:isReport) { _ in
            self.hideSpinner()
            self.clcview.reloadData()
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        }
    }

}

//MARK: - CollectionView Delegate, CollectionView DataSource
extension PatientsReportsVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.viewModel.patientResult?.response?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.clcview.dequeueReusableCell(withReuseIdentifier: "prescriptionReportCell", for: indexPath) as! prescriptionReportCell
        guard let obj = self.viewModel.patientResult?.response?[indexPath.row] else { return UICollectionViewCell() }
        cell.lbldate.text = obj.folderName?.convertToDateString(format: .dd_MMM_yyyy) ?? ""
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let obj = self.viewModel.patientResult?.response?[indexPath.row] else { return }
        let vc = ReportPrescriptionDetailVC.instantiatePatient()
        vc.userData = obj
        self.navigationController?.pushViewController(vc, animated: false)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let collectionWidth = collectionView.bounds.width
        return CGSize(width: (collectionWidth/3)-5, height: 70)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
}

class prescriptionReportCell: UICollectionViewCell {
    
    @IBOutlet weak var lbldate: UILabel!
}
