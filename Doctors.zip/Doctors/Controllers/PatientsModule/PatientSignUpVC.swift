//
//  PatientSignUpVC.swift
//  Doctors
//
//  Created by Aksa on 21/03/24.
//

import UIKit
import DropDown

class PatientSignUpVC: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var imgViewProfile: UIImageView!
    @IBOutlet weak var btnEditProfile: UIButton!
    @IBOutlet weak var txtFldName: UITextField!
    @IBOutlet weak var txtFldNumber: UITextField!
    @IBOutlet weak var txtFldGender: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var textViewGender: UIView!
    
    private let imagePicker = UIImagePickerController()
    private let dropDown = DropDown()
    private var selectedGender = Int()
    private let viewModel = PatientSignUpVM()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupUI()
        dropDown.anchorView = textViewGender  
        textViewGender.layer.cornerRadius = 8
        self.imgViewProfile.layer.cornerRadius = 12
    }
    
    private var selecteGender = Int() {
        didSet{
            let strGender = (Constants.GenderList.filter({$0.value == selecteGender})).first?.name
            self.txtFldGender.text = strGender ?? ""
        }
    }

    func setupUI() {
        txtFldGender.delegate = self
        let strGender = (Constants.GenderList.filter({$0.value == selecteGender})).first?.name
        self.txtFldGender.text = strGender ?? ""
        self.txtFldNumber.text = DefaultsClass.shared.phoneNumber
        self.btnSubmit.layer.cornerRadius = 12
        
    }
    
    @IBAction func didTapSelectGender(_ sender: UITextField) {
        self.view.endEditing(true) // Dismiss keyboard if it's open
        dropDown.dataSource = Constants.GenderList.map { $0.name } // Set DropDown data source
        dropDown.show() // Show the DropDown
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            selectedGender = index + 1
            print(selectedGender)
            txtFldGender.text = item // Update text field with selected item
        }
    }

    @IBAction func btnSubmitAction(_ sender: Any) {
        self.registerPatient()
    }
}
    extension PatientSignUpVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            self.dismiss(animated: true, completion: nil)
        }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            guard let image = info[.editedImage] as? UIImage else{
                return
            }
            self.imgViewProfile.image = image
            self.dismiss(animated: true, completion: nil)
        }

}
// MARK: - ImagePicker Functions
extension PatientSignUpVC {
    
    @IBAction func btnTapImage(_ sender: Any) {
        self.showActionSheet(control: ["Camera","Gallery"]) { title in
            if title == "Camera"{
                guard UIImagePickerController.isSourceTypeAvailable(.camera) else {return}
                self.imagePicker.sourceType = .camera
            }else{
                self.imagePicker.sourceType = .photoLibrary
            }
            self.imagePicker.delegate = self
            self.imagePicker.isEditing = true
            self.imagePicker.allowsEditing = true
            self.present(self.imagePicker, animated: true, completion: nil)
        }
    }
    func registerPatient() {
            self.view.endEditing(true)
            let requestModel = ProfileRequestModel(profilePic: self.imgViewProfile.image,
                                                     name: self.txtFldName.text,
                                                     gender: self.selectedGender )
                 
            do {
                self.showSpinner()
                self.viewModel.registerPatient(requestModel: requestModel) { _ in
                    self.hideSpinner()
                  
                    let storyboard = UIStoryboard(name: "PatientsModule", bundle: nil)
                    guard let vc = storyboard.instantiateViewController(withIdentifier: "PatientsHomeVC") as? PatientsHomeVC else {
                        return
                    }
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            failure: { error in
                ErrorHandler.shared.handleError(error: error)
                self.hideSpinner()
            }
            }
        }
        
}
