//
//  PatientsPrecriptionVC.swift
//  Doctors
//
//  Created by Aksa on 03/04/24.
//

import UIKit

class PatientsPrecriptionVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


    }
    
