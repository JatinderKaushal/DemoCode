//
//  ReportPrescriptionDetailVC.swift
//  Doctors
//
//  Created by Jatinder on 08/04/24.
//

import UIKit
import Kingfisher

class ReportPrescriptionDetailVC: UIViewController {
    @IBOutlet weak var clcview: UICollectionView! {
        didSet {
            self.clcview.delegate = self
            self.clcview.dataSource = self
        }
    }
    var userData : PatientResult?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let layout = clcview.collectionViewLayout as? UICollectionViewFlowLayout // casting is required because UICollectionViewLayout doesn't offer header pin. Its feature of UICollectionViewFlowLayout
        layout?.sectionHeadersPinToVisibleBounds = true
    }
    
    @IBAction func btnBackAct(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

//MARK: - CollectionView Delegate, CollectionView DataSource
extension ReportPrescriptionDetailVC:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return userData?.reports?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.clcview.dequeueReusableCell(withReuseIdentifier: "prescriptionReportDetailCell", for: indexPath) as! prescriptionReportDetailCell
        if let urlImg = URL(string: getPicType(index: indexPath.row)) {
            cell.thumbnailImageView.kf.setImage(with: urlImg, placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
            cell.thumbnailImageView.contentMode = .scaleAspectFit
        }
        return cell
    }
    
    func getPicType(index:Int)->String {
        return Api.imageUrl(endpoint: userData?.reports?[index].prescription ?? "")
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        viewForSupplementaryElementOfKind kind: String,
                        at indexPath: IndexPath) -> UICollectionReusableView {
        guard let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "headerView", for: indexPath) as? headerView else { return UICollectionReusableView() }
        headerView.lblDate.text = self.userData?.folderName?.convertToDateString(format: .dd_MMM_yyyy) ?? ""
        return headerView
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.bounds.width/3)-10, height: 150)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
}

class headerView: UICollectionReusableView {
    
    @IBOutlet weak var lblDate: UILabel!
}

class prescriptionReportDetailCell: UICollectionViewCell {
    
    @IBOutlet weak var thumbnailImageView: UIImageView!
}
