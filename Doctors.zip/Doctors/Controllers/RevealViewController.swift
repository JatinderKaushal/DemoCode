//
//  RevealViewController.swift
//  Water Waze
//
//  Created 

import UIKit

class RevealViewController: UIViewController {
    
    @IBOutlet weak var sideMenuContainerView: UIView!{didSet{self.sideMenuContainerView.alpha = 0}}
    @IBOutlet weak var viewControllerContainer: UIView!
    @IBOutlet weak var viewControllerTop: NSLayoutConstraint!
    @IBOutlet weak var viewControllerLeading: NSLayoutConstraint!
    @IBOutlet weak var ViewControllerTrailing: NSLayoutConstraint!
    @IBOutlet weak var viewControllerBottom: NSLayoutConstraint!
    
    let nav = UINavigationController()
    var selectedMenuIndex: Int = 0
    
    static var shared: RevealViewController? {
        return (UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController as? UINavigationController)?.viewControllers.last as? RevealViewController
    }
    
    lazy var menuHiderView: UIView = {
        let vw = UIView()
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(toggle))
        let leftSwipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(toggle))
        leftSwipeGesture.direction = UISwipeGestureRecognizer.Direction.left
        vw.frame = viewControllerContainer.frame
        tapGesture.delegate = self as? UIGestureRecognizerDelegate
        leftSwipeGesture.delegate = self as? UIGestureRecognizerDelegate
        vw.backgroundColor = .clear
        vw.alpha = 0
        vw.addGestureRecognizer(tapGesture)
        vw.addGestureRecognizer(leftSwipeGesture)
        
        return vw
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addChild(nav)
        self.nav.didMove(toParent: self)
        self.viewControllerContainer.addSubview(nav.view)
        self.nav.view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            self.nav.view.leadingAnchor.constraint(equalTo: self.viewControllerContainer.leadingAnchor),
            self.nav.view.trailingAnchor.constraint(equalTo: self.viewControllerContainer.trailingAnchor),
            self.nav.view.topAnchor.constraint(equalTo: self.viewControllerContainer.topAnchor),
            self.nav.view.bottomAnchor.constraint(equalTo: self.viewControllerContainer.bottomAnchor)
            ])
        self.viewControllerContainer.addSubview(menuHiderView)
        
        self.nav.viewControllers = [getViewController(id: Constants.DoctorMenu.first!.uid)!]
       
        DefaultsClass.shared.isAlreadyIn = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.nav.viewControllers = [getViewController(id: Constants.DoctorMenu.first!.uid)!]
    }
    
    @objc func toggle() {

        if self.viewControllerLeading.constant == 0 { // side menu will show inside code func
            let screenHalfWidth = Constants.screenWidth / 1.5
            self.viewControllerLeading.constant =  screenHalfWidth
            self.viewControllerTop.constant = 0
            self.ViewControllerTrailing.constant = -screenHalfWidth
            self.viewControllerBottom .constant =  0
            self.menuHiderView.alpha = 1
            self.sideMenuContainerView.alpha = 1
        }else {
            self.ViewControllerTrailing.constant = 0
            self.viewControllerBottom .constant = 0
            self.viewControllerLeading.constant = 0
            self.viewControllerTop.constant = 0
                        
            self.menuHiderView.alpha = 0
            DispatchQueue.main.asyncAfter(deadline: .now()+0.5) {
                self.sideMenuContainerView.alpha = 0
            }
        }
        self.menuHiderView.frame = CGRect(x: 0, y: 0, width: self.viewControllerContainer.frame.width, height: self.viewControllerContainer.frame.height)
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
            self.menuHiderView.backgroundColor = self.viewControllerLeading.constant != 0 ? UIColor.black.withAlphaComponent(0.2) : UIColor.clear
        }
    }
    
    func NavigationRootController(_ selectedRoot:Int){
        self.toggle()
        self.selectedMenuIndex = selectedRoot
        if let vc = self.getViewController(id: Constants.DoctorMenu[selectedRoot].uid) {
            nav.viewControllers = [vc]
            return
        }
        
        // Logout button was clicked
        DefaultsClass.shared.removeAll()
        Constants.selectedDoctorMenu = Constants.DoctorMenu.first!
        self.navigationController?.popToRoot()
    }
    
    private func getViewController(id:Int)->UIViewController?{
        switch id {
        case 0:
            if DefaultsClass.shared.role == "2" {
                return DocAppointmentsVC.instantiateMain() 
            }
            else {
                return PatientsHomeVC.instantiatePatient()
            }
        case 1:
            return PatientListViewController.instantiateMain()
        case 2:
            return HistoryListViewController.instantiateMain()
        case 3:
            return NotificationViewController.instantiateMain()
        case 4:
            return DoctorRegistrationViewController.instantiateMain()
        case 5:
            return ContactUsViewController.instantiateMain()
        default:
            return nil
        }
    }
}
