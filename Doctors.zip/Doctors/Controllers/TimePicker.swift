//
//  TimePicker.swift
//  Doctors
//
//  Created by iOS on 17/05/22.
//

import UIKit
import Foundation

class TimePicker: UIViewController {

    @IBOutlet weak var closeTimePicker: UIButton!
    @IBOutlet weak var timePicker: UIDatePicker!
    let dateFormatter = DateFormatter()
    var delegate: returnDataProtocol?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func closeBtnTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func submitBtnTapped(_ sender: UIButton) {
     //   vc.modalPresentationStyle = .fullScreen
      //  self.present(vc, animated: true)
    //    dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = "hh:mm a"
        let timeStamp = dateFormatter.string(from: timePicker.date)
        delegate?.returnStringData(myData: timeStamp)
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

protocol returnDataProtocol {
    func returnStringData(myData: String)
 }
