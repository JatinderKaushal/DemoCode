//
//  ContactUsViewModel.swift
//  Doctors
//
//  Created by Aksa on 12/03/24.
//

import Foundation
import Foundation

struct ContactUsModel: Codable {
    let message, response: String?
}

class ContactUsViewModel {
  internal func contactUs(param:[String:Any],completion:@escaping(Bool,String)->()){
       HitApi.shared.sendRequest(endPoint: Api.contactUs, parameters: param) { (result:Result<ContactUsModel,Error>) in
           switch result{
           case .success(let model):
               if model.message == "Success"{
            
                   completion(true, model.message ?? Constants.defaultServerMessage)
               }else{
                   completion(false, model.message ?? Constants.defaultServerMessage)
               }
               break;
               
           case.failure(let error):
               completion(false,  error.localizedDescription)
               break;
           }
       }
   }
}
