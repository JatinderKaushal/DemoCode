//
//  NotificationViewController.swift
//  Doctors
//
//  Created by Mandeep Singh on 17/06/22.
//

import UIKit

class NotificationViewController: UIViewController {
    @IBOutlet weak var tblView: UITableView!{
        didSet{
            tblView.delegate = self
            tblView.dataSource = self
        }}
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}

extension NotificationViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblView.dequeueReusableCell(withIdentifier: "cellid") as! NotificationTblCell
        /* if let urlImg = URL(string: objDoctorAppointment.getPic(index: indexPath.row)){
         cell.imgUser.kf.setImage(with: urlImg, placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
         }
         cell.lblName.text = objDoctorAppointment.getTitle(index: indexPath.row)
         cell.lblDate.text = objDoctorAppointment.getAppointmentDate(index: indexPath.row)
         cell.lblStatus.text = objDoctorAppointment.getAppointmentStatus(index: indexPath.row)
         cell.lblStatus.textColor = objDoctorAppointment.getAppointmentStatusColor(index: indexPath.row)
         cell.lblSymptoms.text = objDoctorAppointment.getSymtoms(index: indexPath.row)*/
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}



class NotificationTblCell:UITableViewCell{
}
