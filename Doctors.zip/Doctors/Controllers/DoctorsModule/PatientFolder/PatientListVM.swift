////
////  PatientListVM.swift
////  Doctors
////
////  Created by Aksa on 12/03/24.
////
//
//import Foundation
//import Moya
//
//class PatientListVM: NSObject {
//    
//    var patientList : [UserList]?
//    var userDetails: UserDetailsData?
//    func getPatientList(search: String?,
//                        status: [Int],
//                        success: @escaping successCallBack,
//                        failure: @escaping failureCallBack) {
//        
//        let provider = MoyaProvider<Service>()
//        provider.request(.getPatientList(search: search, status: status)) { result in
//            switch result {
//            case let .success(moyaResponse):
//                
//                do {
//                    if let data = try self.handleRepsonse(type: GetUser.self, moyaResponse: moyaResponse) {
//                        self.patientList = data.response
//                        success(nil)
//                    } else {
//                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
//                    }
//                } catch let error {
//                    failure(error)
//                }
//                break
//            case let .failure(error):
//                failure(error)
//                break
//            }
//        }
//    }
//    
//    func getPatientDetails(id: Int,
//                           success: @escaping successCallBack,
//                           failure: @escaping failureCallBack) {
//        
//        let provider = MoyaProvider<Service>()
//        provider.request(.getPatientDetails(id: id)) { result in
//            switch result {
//            case let .success(moyaResponse):
//                
//                do {
//                    if let data = try self.handleRepsonse(type: UserDetails.self, moyaResponse: moyaResponse) {
//                        self.userDetails = data.response
//                        success(nil)
//                    } else {
//                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
//                    }
//                } catch let error {
//                    failure(error)
//                }
//                break
//            case let .failure(error):
//                failure(error)
//                break
//            }
//        }
//    }
//}
//
