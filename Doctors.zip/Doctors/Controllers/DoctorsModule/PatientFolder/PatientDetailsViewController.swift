//
//  PatientDetailsViewController.swift
//  Doctors
//
//  Created by Mandeep Singh on 17/06/22.
//

import UIKit

class PatientDetailsViewController: UIViewController {
    @IBOutlet weak var imgView: ImageCustom!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var lblAge: UILabel!
    @IBOutlet weak var tblView: UITableView!
    
    var patientList :UserDetailsData?
    var viewModel: AppointmentsVM?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.renderData()
        self.tblView.delegate = self
        self.tblView.dataSource = self
    }
    
    @IBAction func btnCall(_ sender: Any) {
        self.callNumber(phoneNumber: self.patientList?.phone ?? "0")
    }
    
    func renderData() {
        if let obj = self.patientList {
            self.lblName.text = obj.name
            self.lblAge.text = obj.email
            self.lblGender.text = obj.gender?.getString()
        }
    }
    
    private func callNumber(phoneNumber: String) {
        guard let phoneCallURL = URL(string: "tel://\(phoneNumber)") else {
            print("Invalid phone number URL")
            return
        }
        let application = UIApplication.shared
        guard application.canOpenURL(phoneCallURL) else {
            print("Cannot open phone call URL")
            return
        }
        application.open(phoneCallURL, options: [:], completionHandler: nil)
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension PatientDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.patientList?.appointment?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tblView.dequeueReusableCell(withIdentifier: "cellid") as? PatientDetailsTblCell else {
            return UITableViewCell()
        }
        if let obj = self.patientList?.appointment?[indexPath.row]{
            cell.renderData(url: obj.patientImage,
                            patientName: obj.appointPatientName,
                            date: obj.appointmentDate?.convertToDateString(format: .dd_MMM_yyyy_EEEE),
                            time: obj.appointmentDate?.convertToDateString(format: .hh_mm_a))
        }
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let appointmentID = self.patientList?.appointment?[indexPath.row].id
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "DocAppointmentsDetailsVC") as? DocAppointmentsDetailsVC else { return }
        vc.id = appointmentID
        vc.viewModel = self.viewModel
        //vc.objDoctorAppointment = self.objDoctorAppointment
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        122.0
    }
}

class PatientDetailsTblCell:UITableViewCell{
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    
    func renderData(url: String?, patientName: String?, date: String?, time: String?) {
        self.lblName.text = patientName
        self.lblDate.text = date
        self.lblTime.text = time
        guard let finalURL = url else {
            return
        }
        let urlString = "http://qualhon.net:3100/\(finalURL)"
        if let url = URL(string: urlString) {
            self.imgProfile.kf.setImage(with: URL(string: urlString), placeholder: Constants.DoctorPlaceholderImage)
        }
    }
}
