/* 
Copyright (c) 2024 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct AppointmentBooked : Codable {
	let id : Int?
	let patientId : Int?
	let doctorId : Int?
	let appointPatientName : String?
    let appointmentDate: Int?
	let note : String?
	let symptom : String?
	let doctor_name : String?
	let phone : String?
	let image : String?
	let patientPhone : String?
	let patientImage : String?
	let specialization : [PatientSpecialization]?
	let prescription : [PatientPrescription]?

	enum CodingKeys: String, CodingKey {

		case id = "id"
		case patientId = "patientId"
		case doctorId = "doctorId"
		case appointPatientName = "appointPatientName"
        case appointmentDate = "appointmentDate"
		case note = "note"
		case symptom = "symptom"
		case doctor_name = "doctor_name"
		case phone = "phone"
		case image = "image"
		case patientPhone = "patientPhone"
		case patientImage = "patientImage"
		case specialization = "specialization"
		case prescription = "prescription"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		id = try values.decodeIfPresent(Int.self, forKey: .id)
		patientId = try values.decodeIfPresent(Int.self, forKey: .patientId)
		doctorId = try values.decodeIfPresent(Int.self, forKey: .doctorId)
		appointPatientName = try values.decodeIfPresent(String.self, forKey: .appointPatientName)
        appointmentDate = try values.decodeIfPresent(Int.self, forKey: .appointmentDate)
		note = try values.decodeIfPresent(String.self, forKey: .note)
		symptom = try values.decodeIfPresent(String.self, forKey: .symptom)
		doctor_name = try values.decodeIfPresent(String.self, forKey: .doctor_name)
		phone = try values.decodeIfPresent(String.self, forKey: .phone)
		image = try values.decodeIfPresent(String.self, forKey: .image)
		patientPhone = try values.decodeIfPresent(String.self, forKey: .patientPhone)
		patientImage = try values.decodeIfPresent(String.self, forKey: .patientImage)
		specialization = try values.decodeIfPresent([PatientSpecialization].self, forKey: .specialization)
		prescription = try values.decodeIfPresent([PatientPrescription].self, forKey: .prescription)
	}

}
