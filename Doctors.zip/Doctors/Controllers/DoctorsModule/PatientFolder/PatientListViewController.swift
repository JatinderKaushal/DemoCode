//
//  PatientListViewController.swift
//  Doctors
//
//  Created by Mandeep Singh on 17/06/22.
//

import UIKit
import Kingfisher

class PatientListViewController: UIViewController {
    
    @IBOutlet weak var btnClear: UIButton!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var tblView: UITableView!
    private var arrFilters = [Int]()
    var viewModel = AppointmentsVM()
    var isLoading = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.txtSearch.delegate = self
        self.tblView.delegate = self
        self.tblView.dataSource = self
        self.getPatientList(search: "", status: [])
    }
    
    override func viewWillAppear(_ animated: Bool) {
       
    }
    
    @IBAction func clearAction(_ sender: Any) {
        
        self.btnClear.isHidden = true
        self.txtSearch.text = nil
        self.getPatientList(search: "", status: [])

    }
   
}

extension PatientListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.viewModel.patientList?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tblView.dequeueReusableCell(withIdentifier: "cellid") as? PatientListTblCell else {
            return UITableViewCell()
        }
        if let obj = self.viewModel.patientList?[indexPath.row] {
            
            cell.renderData(url: obj.image,
                            patientName: obj.name,
                            appointmentDate: obj.appointmentDate?.convertToDateString(format: .dd_MMM_yyyy_EEEE),
                            appointmentTime: obj.appointmentDate?.convertToDateString(format: .hh_mm_a))
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let obj = self.viewModel.patientList?[indexPath.row] {
            self.getPatientDetails(id: obj.patientId! )
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        141.0
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == (self.viewModel.patientList?.count ?? 0) - 1, self.viewModel.currentPage < viewModel.totalPages {
            print("index",indexPath.row)
            print("count",viewModel.patientList?.count)
            viewModel.currentPage += 1
                self.getPatientList(search: "", status: [])
        }
        }
}


// MARK: - Api calls-
extension PatientListViewController:  UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField.text!.count >= 3 {
            // Call your API
            self.btnClear.isHidden = false
            getPatientList(search: textField.text!, status: [])
        } else {
            self.btnClear.isHidden = true
        }
        self.btnClear.isHidden = false
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.btnClear.isHidden = false
       }
    
    func getPatientList(search: String, status: [Int]) {
        guard !isLoading else {
                      return
                  }
                  isLoading = true
        self.showSpinner()
        self.viewModel.getPatientList(search: search, status: status) { _ in
            self.hideSpinner()
            self.isLoading = false
            self.tblView.reloadData()
            self.tblView.tableFooterView?.isHidden = false
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        }
    }
    
    func getPatientDetails(id: Int) {
        self.showSpinner()
        self.viewModel.getPatientDetails(id: id){ _ in
            self.hideSpinner()
            let vc = PatientDetailsViewController.instantiateMain()
            vc.viewModel = self.viewModel
            vc.patientList = self.viewModel.userDetails
            self.navigationController?.push(viewController: vc)
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        }
    }
}

class PatientListTblCell:UITableViewCell {
    
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    
    func renderData(url: String?, patientName: String?, appointmentDate: String?, appointmentTime: String?) {
        self.lblName.text = patientName
        self.lblDate.text = appointmentDate
        self.lblTime.text = appointmentTime
        guard let finalURL = url else {
            return
        }
        let urlString = "http://qualhon.net:3100/\(finalURL)"
        if let url = URL(string: urlString) {
            self.imgUser.kf.setImage(with: URL(string: urlString), placeholder: Constants.DoctorPlaceholderImage)
        }
    }
}
