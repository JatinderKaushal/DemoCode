/* 
Copyright (c) 2024 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct AppointmentDetailsResponse : Codable {
	let id : Int?
	let appointPatientName : String?
	let note : String?
	let syptoms : String?
	let appointmentDate : Int?
	let doctorId : Int?
	let declineReason : String?
	let cancellationReason : String?
	let docName : String?
	let docImage : String?
	let docPhone : String?
	let status : Int?
	let distance : String?
	let patientId : Int?
	let patientAge : Int?
	let patientGender : Int?
	let patientName : String?
	let patientImage : String?
	let patientPhone : String?
	let blockStatus : Int?
	let specialization : [PatientSpecialization]?
	let prescription : [PatientPrescription]?
	let reports : [Reports]?
	let dTokens : [DTokens]?
	let pTokens : [PTokens]?

	enum CodingKeys: String, CodingKey {

		case id = "id"
		case appointPatientName = "appointPatientName"
		case note = "note"
		case syptoms = "syptoms"
		case appointmentDate = "appointmentDate"
		case doctorId = "doctorId"
		case declineReason = "declineReason"
		case cancellationReason = "cancellationReason"
		case docName = "docName"
		case docImage = "docImage"
		case docPhone = "docPhone"
		case status = "status"
		case distance = "distance"
		case patientId = "patientId"
		case patientAge = "patientAge"
		case patientGender = "patientGender"
		case patientName = "patientName"
		case patientImage = "patientImage"
		case patientPhone = "patientPhone"
		case blockStatus = "blockStatus"
		case specialization = "specialization"
		case prescription = "prescription"
		case reports = "reports"
		case dTokens = "dTokens"
		case pTokens = "pTokens"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		id = try values.decodeIfPresent(Int.self, forKey: .id)
		appointPatientName = try values.decodeIfPresent(String.self, forKey: .appointPatientName)
		note = try values.decodeIfPresent(String.self, forKey: .note)
		syptoms = try values.decodeIfPresent(String.self, forKey: .syptoms)
		appointmentDate = try values.decodeIfPresent(Int.self, forKey: .appointmentDate)
		doctorId = try values.decodeIfPresent(Int.self, forKey: .doctorId)
		declineReason = try values.decodeIfPresent(String.self, forKey: .declineReason)
		cancellationReason = try values.decodeIfPresent(String.self, forKey: .cancellationReason)
		docName = try values.decodeIfPresent(String.self, forKey: .docName)
		docImage = try values.decodeIfPresent(String.self, forKey: .docImage)
		docPhone = try values.decodeIfPresent(String.self, forKey: .docPhone)
		status = try values.decodeIfPresent(Int.self, forKey: .status)
		distance = try values.decodeIfPresent(String.self, forKey: .distance)
		patientId = try values.decodeIfPresent(Int.self, forKey: .patientId)
		patientAge = try values.decodeIfPresent(Int.self, forKey: .patientAge)
		patientGender = try values.decodeIfPresent(Int.self, forKey: .patientGender)
		patientName = try values.decodeIfPresent(String.self, forKey: .patientName)
		patientImage = try values.decodeIfPresent(String.self, forKey: .patientImage)
		patientPhone = try values.decodeIfPresent(String.self, forKey: .patientPhone)
		blockStatus = try values.decodeIfPresent(Int.self, forKey: .blockStatus)
		specialization = try values.decodeIfPresent([PatientSpecialization].self, forKey: .specialization)
		prescription = try values.decodeIfPresent([PatientPrescription].self, forKey: .prescription)
		reports = try values.decodeIfPresent([Reports].self, forKey: .reports)
		dTokens = try values.decodeIfPresent([DTokens].self, forKey: .dTokens)
		pTokens = try values.decodeIfPresent([PTokens].self, forKey: .pTokens)
	}

}

struct PatientPrescription: Codable {
    
    let id: Int?
    let prescription: String?
    let status: Int?
    enum CodingKeys: String, CodingKey {
        
        case id = "id"
        case prescription = "prescription"
        case status = "status"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        prescription = try values.decodeIfPresent(String.self, forKey: .prescription)
        status = try values.decodeIfPresent(Int.self, forKey: .status)
    }
}
