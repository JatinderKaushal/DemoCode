//
//  DocAppointmentsDetailsVC.swift
//  Doctors
//
//  Created by Mandeep Singh on 16/06/22.
//

import UIKit
import Kingfisher
import VisionKit
import PDFKit

class DocAppointmentsDetailsVC: UIViewController {
    
    @IBOutlet var VStackViews: [UIView]!
    @IBOutlet weak var imgView: ImageCustom!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var lblAge: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var lblInfo: UILabel!
    @IBOutlet weak var btnUpload: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var btnComplete: UIButton!
    @IBOutlet weak var clcView: UICollectionView!{
        didSet{
            clcView.delegate = self
            clcView.dataSource = self
        }
        
    }
    var scanThumbnail = UIImage()
    var scanData = Data()
    var id: Int?
    var objDoctorAppointment: DoctorAppointmentsVIewModel?
    //var patiantDetailModel : ResponseModel?
    var viewModel:AppointmentsVM?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.btnCancel.layer.cornerRadius = 10
        self.btnComplete.layer.cornerRadius = 10
        self.getAppointmentDetails(id: self.id ?? 0)
    }
    
    override func viewWillLayoutSubviews(){
        for v in VStackViews{
            v.layer.cornerRadius = 10.0
            v.clipsToBounds = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.getAppointmentDetails(id: self.id ?? 0)
        if viewModel?.appointmentDetails?.status == 1 {
            self.btnComplete.isHidden = false
            self.btnCancel.isHidden = false
        }
    }
    func renderData() {
        if viewModel?.appointmentDetails?.status == 1 {
            self.btnComplete.isHidden = false
            self.btnCancel.isHidden = false
        }
        self.imgView.kf.setImage(with: URL(string:Api.MainUrl+(viewModel?.appointmentDetails?.patientImage ?? "")), placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
        
        self.lblName.text = viewModel?.appointmentDetails?.appointPatientName ?? ""
        self.lblGender.text = (Constants.GenderList.filter({$0.value == (viewModel?.appointmentDetails?.patientGender ?? 0)})).first?.name
        self.lblAge.text = (viewModel?.appointmentDetails?.patientAge ?? 0).getString()
        self.lblDate.text = viewModel?.appointmentDetails?.appointmentDate?.convertToDateString(format: .dd_MMM_yyyy_EEEE) ?? ""
        self.lblTime.text = viewModel?.appointmentDetails?.appointmentDate?.convertToDateString(format: .hh_mm_a) ?? ""
        self.lblDescription.text = viewModel?.appointmentDetails?.syptoms ?? ""
        self.lblInfo.text = viewModel?.appointmentDetails?.note ?? ""
    }
    @IBAction func backAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btnCancel(_ sender: Any) {
        AlertManager.shared.showInputAlert(title: "Please write cancellelation reason", placeholder: "Type here", saveActionTitle: "Cancel", saveAction: { message in
            if let message = message {
                print("User entered message: \(message)")
                self.objDoctorAppointment?.acceptAppointment(urlEndPoint: "cancel-appointment", appointmentID: (self.viewModel?.appointmentDetails?.id)!, reason: "jhvjhvh") { success, message in
                    if success {
                        // Handle success
                        print("Appointment canceled successfully")
                    } else {
                        // Handle failure
                        print("Failed to accept appointment: \(message)")
                    }
                }
            } else {
                print("User cancelled")
            }
        }, cancelAction: nil)
        
        
    }
    func displayScanningController() {
            guard VNDocumentCameraViewController.isSupported else { return }
            let controller = VNDocumentCameraViewController()
            controller.delegate = self
            present(controller, animated: true)
        }
    @IBAction func btnComplete(_ sender: Any) {
        AlertManager.shared.showAlert(message: "Are you sure you want to Complete this appointment", actionTitles: ["Yes", "No"]) { index, _ in
            if index == 0 {
                self.objDoctorAppointment?.acceptAppointment(urlEndPoint: "complete-appointment", appointmentID: (self.viewModel?.appointmentDetails?.id)!, reason: "") { success, message in
                    if success {
                        // Handle success
                        self.navigationController?.popViewController(animated: true)
                    } else {
                        // Handle failure
                        print("Failed to accept appointment: \(message)")
                    }
                }
            } else {
                // Dismiss the alert
                AlertManager.shared.dismissAlert()
            }
        }
    }
    
    @IBAction func btnCall(_ sender: Any) {
        callNumber(phoneNumber: self.viewModel?.appointmentDetails?.patientPhone ?? "0")
    }
    
    private func callNumber(phoneNumber: String) {
        guard let phoneCallURL = URL(string: "tel://\(phoneNumber)") else {
            print("Invalid phone number URL")
            return
        }
        
        let application = UIApplication.shared
        guard application.canOpenURL(phoneCallURL) else {
            print("Cannot open phone call URL")
            return
        }
        
        application.open(phoneCallURL, options: [:], completionHandler: nil)
    }
    
    @IBAction func btnUploadPrecription(_ sender: Any) {
        if self.viewModel?.appointmentDetails?.status != 1 {
            btnUpload.isUserInteractionEnabled = false
        } 
        else {
            displayScanningController()
            //            AttachmentHandler.shared.showCamera(vc: self)
//            AttachmentHandler.shared.imagePickedBlock = { (image, name, path) in
//                // self.images.append(image)
//                let popUpVC = PrecriptionImageConfrimation()
//                popUpVC.precriptionImage = image
//                popUpVC.callBack = { tag in
//                    if (tag) {
//                        self.uploadPrecriptions(image: image)
//                    }
//                }
//                guard let topvc = UIApplication.topViewController() else { return }
//                topvc.presentfromBottomToTop(vc: popUpVC)
//            }
            
        }
    }
}

extension DocAppointmentsDetailsVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        viewModel?.appointmentDetails?.prescription?.count ?? 0
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            let cell = clcView.dequeueReusableCell(withReuseIdentifier: "cellid", for: indexPath) as! DoctorAppointmentsDetailsClcCell
            guard let obj = viewModel?.appointmentDetails?.prescription?[indexPath.item].prescription else { return UICollectionViewCell() }
            if obj.contains(".pdf") {
                if let finalUrl =  URL(string: Api.MainUrl + obj) {
                    cell.imgView.image = pdfThumbnail(url: finalUrl, width: cell.imgView.frame.size.width)
                    cell.imgView.contentMode = .scaleAspectFit
                }
            } else {
                cell.imgView.kf.setImage(with: URL(string: Api.MainUrl+obj), placeholder: nil, options: nil, completionHandler: nil)
            }
            return cell
        }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            guard let obj = viewModel?.appointmentDetails?.prescription?[indexPath.item].prescription else { return }
            if obj.contains(".pdf") {
                let PdfViewerVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PdfViewerVC") as! PdfViewerVC
                PdfViewerVC.path = obj
                self.navigationController?.pushViewController(PdfViewerVC, animated: true)
            } else {
                let galleryVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ImageGalleryViewController") as! ImageGalleryViewController
                if let images = viewModel?.appointmentDetails?.prescription, images.count != 0 {
                    galleryVC.images.removeAll()
                    galleryVC.currentIndex = 0
                    galleryVC.images = images
                    galleryVC.currentIndex = indexPath.item
                }
                present(galleryVC, animated: true, completion: nil)
            }
        }

//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//        let cell = clcView.dequeueReusableCell(withReuseIdentifier: "cellid", for: indexPath) as! DoctorAppointmentsDetailsClcCell
//        cell.imgView.kf.setImage(with: URL(string: Api.MainUrl+(viewModel?.appointmentDetails?.prescription?[indexPath.item].prescription ?? "")), placeholder: nil, options: nil, completionHandler: nil)
//        return cell
//    }
//    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: clcView.frame.width/4.5, height: clcView.frame.width/5.0)
    }
    
//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        let galleryVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ImageGalleryViewController") as! ImageGalleryViewController
//        if let images = viewModel?.appointmentDetails?.prescription, images.count != 0 {
//            galleryVC.images.removeAll()
//            galleryVC.currentIndex = 0
//            galleryVC.images = images
//            galleryVC.currentIndex = indexPath.item
//        }
//        present(galleryVC, animated: true, completion: nil)
//    }
    
}
extension DocAppointmentsDetailsVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else {
            // Add the picked image to the array
            return
        }
        picker.dismiss(animated: true) {
            
            let popUpVC = PrecriptionImageConfrimation()
            popUpVC.precriptionImage = image
            popUpVC.callBack = { tag in
                if (tag) {
                    //self.uploadPrecriptions(image: image)
                }
            }
            if let topVc = UIApplication.topViewController() {
                topVc.presentfromBottomToTop(vc: popUpVC)
            }
        }
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
// MARK: - API Calls
extension DocAppointmentsDetailsVC {
    
    private func uploadPrecriptions(image: Data) {
        guard let appointmentId = viewModel?.appointmentDetails?.id else {
            return
        }
        //  let images: [UIImage] = self.images
      //  guard let finalimage = image.compress(maxKb: 300) else { return }
        // Call the uploadPrecription function
        objDoctorAppointment?.uploadPrecription(appointmentId: appointmentId, image: image) { _ in
            print("upload")
            self.getAppointmentDetails(id: self.id ?? 0)
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
            
        }
    }
    
    func getAppointmentDetails(id: Int) {
        
        self.viewModel?.getAppointmentDetails(id: id) { _ in
            self.renderData()
            self.clcView.reloadData()
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
        }
    }
    
}
extension DocAppointmentsDetailsVC: VNDocumentCameraViewControllerDelegate {
    func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) { // save scan
        let pdfURL = generatePDF(from: scan) // Here, you can use pdfURL.path to get the file path
        print("PDF saved at: \(pdfURL.path)")
        guard let data = NSData(contentsOf: pdfURL) else { return }
        scanData = data as Data
        dismiss(animated: true) {
            let popUpVC = PrecriptionImageConfrimation()
            popUpVC.precriptionImage = self.scanThumbnail
            popUpVC.callBack = { tag in
                if (tag) {
                    self.uploadPrecriptions(image: self.scanData)
                }
            }
            if let topVc = UIApplication.topViewController() {
                topVc.presentfromBottomToTop(vc: popUpVC)
            }
        }
    }
    
    func generatePDF(from scan: VNDocumentCameraScan) -> URL {
        let fileManager = FileManager.default
        let pdfURL = fileManager.temporaryDirectory.appendingPathComponent("scannedDocument.pdf")
        let pdfDocument = PDFDocument()
        for pageNumber in 0..<scan.pageCount {
            if let pdfPage = PDFPage(image: scan.imageOfPage(at: pageNumber)) {
                scanThumbnail = scan.imageOfPage(at: pageNumber)
                pdfDocument.insert(pdfPage, at: pdfDocument.pageCount)
            }
        }
        pdfDocument.write(to: pdfURL)
        return pdfURL
    }
    
    func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
        dismiss(animated: true, completion: nil)
    }
    func pdfThumbnail(url: URL, width: CGFloat)-> UIImage? {
            guard let page = PDFDocument(url: url)?.page(at: 0) else {
                return nil
            }
            let pageSize = page.bounds(for: .mediaBox)
            let pdfScale = width / pageSize.width
            // Apply if you're displaying the thumbnail on screen
            let scale = UIScreen.main.scale * pdfScale
            let screenSize = CGSize(width: pageSize.width * scale,
                                    height: pageSize.height * scale)
            return page.thumbnail(of: screenSize, for: .mediaBox)
        }
    
}
class DoctorAppointmentsDetailsClcCell:UICollectionViewCell{
    
    @IBOutlet weak var imgView: UIImageView!
}

