//
//  PrecriptionImageConfrimation.swift
//  Doctors
//
//  Created by Jatinder on 14/03/24.
//

import UIKit

class PrecriptionImageConfrimation: UIViewController {
    @IBOutlet weak var precriptionImageView: ImageCustom!
    var callBack : ((Bool) -> Void)?
    var precriptionImage = UIImage()
    override func viewDidLoad() {
        super.viewDidLoad()
        precriptionImageView.image = precriptionImage
    }


    @IBAction func closeButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: {
            self.callBack!(false)
        })
    }
    
    @IBAction func cancelButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: {
            self.callBack!(false)
        })
    }
    
    @IBAction func uploadButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: {
            self.callBack!(true)
        })
    }
}
