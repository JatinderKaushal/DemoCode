//
//  AppointmentsVM.swift
//  Doctors
//
//  Created by Aksa on 19/03/24.
//

import Foundation
import Moya

class AppointmentsVM: NSObject {
    var currentPage = 1
    var totalPages = 1
    var patientList : [UserList]?
    var userDetails: UserDetailsData?
    var appointmentDetails : AppointmentDetailsResponse?
    func getAppointmentDetails(id: Int,
                               success: @escaping successCallBack,
                               failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.getAPPointmentDetails(id: id)) { result in
            switch result {
            case let .success(moyaResponse):
                
                do {
                    if let data = try self.handleRepsonse(type: GetAppointmentDetails.self, moyaResponse: moyaResponse) {
                        self.appointmentDetails = data.response
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
    
    
    func getPatientList(search: String?,
                        status: [Int],
                        success: @escaping successCallBack,
                        failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.getPatientList(search: search, status: status, page: currentPage)) { result in
            switch result {
            case let .success(moyaResponse):
                
                do {
                    if let data = try self.handleRepsonse(type: GetUser.self, moyaResponse: moyaResponse) {
                        self.patientList = data.response
                        if let currentPage = data.pageNo, let totalPages = data.totalPages {
                            self.currentPage = currentPage
                            self.totalPages = totalPages
                        }
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
    
    func getPatientDetails(id: Int,
                           success: @escaping successCallBack,
                           failure: @escaping failureCallBack) {
        
        let provider = MoyaProvider<Service>()
        provider.request(.getPatientDetails(id: id)) { result in
            switch result {
            case let .success(moyaResponse):
                
                do {
                    if let data = try self.handleRepsonse(type: UserDetails.self, moyaResponse: moyaResponse) {
                        self.userDetails = data.response
                        success(nil)
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: moyaResponse))
                    }
                } catch let error {
                    failure(error)
                }
                break
            case let .failure(error):
                failure(error)
                break
            }
        }
    }
}

