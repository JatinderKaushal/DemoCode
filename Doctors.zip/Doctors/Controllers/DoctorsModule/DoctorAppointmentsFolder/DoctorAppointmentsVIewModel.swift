//
//  DoctorAppointmentsVIewModel.swift
//  Doctors
//
//  Created by Mandeep Singh on 14/06/22.
//

import Foundation
import CoreLocation
import UIKit
import Moya

// MARK: - DoctorAppointmentsModel
struct DoctorAppointmentsModel: Codable {
    let pageNo: Int?
    let totalPages: Int?
    let message: String?
    let response: [ResponseModel]?
}

// MARK: - ResponseModel
struct ResponseModel: Codable {
    let id: Int?
    let appointPatientName: String?
    let note, syptoms: String?
    let appointmentDate: Int?
    let doctorId: Int?
    let docName: String?
    let docImage: String?
    let docPhone: String
    let appointment_status: Int?
    let distance: Double?
    let patientId, patientAge, patientGender: Int?
    let patientName: String?
    let patientImage: String?
    let patientPhone: String
    let specialization: [Specialization]
    var prescription: [Prescription]
    
}

// MARK: - Prescription
struct Prescription: Codable {
    let id: Int?
    let prescription: String?
    let status: Int?
}

// MARK: - Specialization
struct Specialization: Codable {
    let dsID, id: Int?
    let category: String?
    let image: String?
}

struct AcceptAppointment: Codable {
    let message: String?
}

class DoctorAppointmentsVIewModel: NSObject {
    var currentPage = 1
    var totalPages = 1
    var arrAppointments = [ResponseModel]()
    var arrHistory = [ResponseModel]()
    
    internal func GetAppointmentsOrHistory(isAppointment: Bool = true, search: String?, status: [Int], completion: @escaping (Bool, String) -> ()) {
        let url = isAppointment ? Api.doctorAppointments(page: currentPage, search: search, status: status) : Api.getHistory(page: currentPage, search: search, status: status)
        
        print("====================================", url)
        
        HitApi.shared.sendRequest(endPoint: url) { [weak self] (result: Result<DoctorAppointmentsModel, Error>) in
            guard let self = self else { return }
            switch result {
            case .success(let model):
                if model.message == "Success" {
                    if let responseModel = model.response {
                        // Check for existing appointment IDs and append only new appointments
                        if isAppointment {
                            self.arrAppointments.append(contentsOf: responseModel)
                        }
                        else {
                            let filteredResponseModel = model.response?.filter { $0.appointment_status != 0 }
                            self.arrHistory.append(contentsOf: filteredResponseModel!)
                        }
                    }
                    if let currentPage = model.pageNo, let totalPages = model.totalPages {
                        self.currentPage = currentPage
                        self.totalPages = totalPages
                    }
                    completion(true, model.message ?? Constants.defaultServerMessage)
                }  else if model.message == "Unauthenticated" {
                        AlertManager.shared.showAlert(message: model.message ?? "Unauthenticated", actionTitles: ["ok"]) { _, _ in
                            let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
                            DefaultsClass.shared.isAlreadyIn = false
                            sceneDelegate.setRootViewController(viewController: SelectRoleViewController.instantiateMain())
                            
                            completion(false, model.message ?? Constants.defaultServerMessage)
                        }
                        
                } else {
                    showSnackbar(message: "Server error", isErrorMessage: true)
                    completion(true, "")
                }
                
                
            case .failure(let error):
                completion(false, error.localizedDescription)
            }
        }
    }
    // MARK: - All Appointments
    internal func count()->Int{
        return arrAppointments.count
    }
    internal func getId(index:Int)->Int{
        return arrAppointments[index].patientId ?? 0
    }
    internal func getPic(index:Int)->String{
        return Api.imageUrl(endpoint: arrAppointments[index].patientImage ?? "")
    }
    internal func getTitle(index:Int)->String{
        return arrAppointments[index].appointPatientName ?? ""
    }
    internal func getSymtoms(index:Int)->String{
        return "Symptoms: " + (arrAppointments[index].syptoms ?? "")
    }
    internal func getAppointmentDate(index:Int)->String{
        return (arrAppointments[index].appointmentDate ?? 0)?.convertToDateString(format: .dd_MMM_yyyy_hh_mm_a) ?? ""
    }
    internal func getAppointmentStatus(index:Int)->String{
        return  Constants.EnumAppointmentStatus(rawValue: arrAppointments[index].appointment_status ?? 0)?.str ?? "Add this to Constant file"
    }
    internal func getAppointmentStatusColor(index:Int)->UIColor?{
        return  Constants.EnumAppointmentStatus(rawValue: arrAppointments[index].appointment_status ?? 0)?.clr
    }
    internal func selectedArrIndex(index:Int)->ResponseModel?{
        return arrAppointments[index]
    }
    
    //MARK: - History
    internal func countHistory()->Int{
        return arrHistory.count
    }
    internal func getIdHistory(index:Int)->Int{
        return arrHistory[index].patientId ?? 0
    }
    internal func getPicHistory(index:Int)->String{
        return Api.imageUrl(endpoint: arrHistory[index].patientImage ?? "")
    }
    internal func getTitleHistory(index:Int)->String{
        return arrHistory[index].appointPatientName ?? ""
    }
    internal func getSymtomsHistory(index:Int)->String{
        return "Symptoms: " + (arrHistory[index].syptoms ?? "")
    }
    internal func getAppointmentDateHistory(index:Int)->String{
        return (arrHistory[index].appointmentDate ?? 0)?.convertToDateString(format: .dd_MMM_yyyy_hh_mm_a) ?? ""
    }
    internal func getAppointmentStatusHistory(index:Int)->String{
        return  Constants.EnumAppointmentStatus(rawValue: arrHistory[index].appointment_status ?? 0)?.str ?? "Add this to Constant file"
    }
    internal func getAppointmentStatusColorHistory(index:Int)->UIColor?{
        return  Constants.EnumAppointmentStatus(rawValue: arrHistory[index].appointment_status ?? 0)?.clr
    }
    internal func selectedArrIndexHistory(index:Int)->ResponseModel?{
        return arrHistory[index]
    }
}
// MARK: - accept, decline, complete or cancel appointment-
extension DoctorAppointmentsVIewModel {
    func acceptAppointment(urlEndPoint: String, appointmentID: Int, reason: String, completion: @escaping (Bool, String) -> Void) {
        // Create a dictionary for the body parameters
        let bodyParameters: [String: Any] = ["cancellationReason": reason]
        
        // Convert the dictionary to JSON data
        guard let jsonData = try? JSONSerialization.data(withJSONObject: bodyParameters) else {
            completion(false, "Failed to encode body parameters")
            return
        }
        
        let url = "http://qualhon.net:3033/api/v1/appointments/\(appointmentID)/\(urlEndPoint)"
        
        // Call putRequestWithAuthentication with the JSON data as body
        HitApi.shared.putRequestWithAuthentication(api: url, body: jsonData) { (result: Result<AcceptAppointment, Error>) in
            switch result {
            case .success(let model):
                completion(true, model.message ?? Constants.defaultServerMessage)
            case .failure(let error):
                // Handle failure
                completion(false, error.localizedDescription)
            }
        }
    }
    
    func uploadPrecription(appointmentId: Int, image:Data, success: @escaping successCallBack,
                           failure: @escaping failureCallBack) {
        let provider = MoyaProvider<Service>()
        provider.request(.uploadPrescription(appointmentId: "\(appointmentId)", prescriptions: image, fileName: "\(Int(NSDate().timeIntervalSince1970))")) { result in
            switch result {
            case .success(let response):
                do {
                    
                    if let data = try self.handleRepsonse(type: commonModel.self, moyaResponse: response) {
                        
                        if data.message == "Success"{
                            success(nil)
                        }else if data.message == "Unauthenticated" {
                            AlertManager.shared.showAlert(message: data.message ?? "Unauthenticated", actionTitles: ["ok"]) { _, _ in
                                let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
                                DefaultsClass.shared.isAlreadyIn = false
                                sceneDelegate.setRootViewController(viewController: SelectRoleViewController.instantiateMain())
                                
                                failure(ErrorHandler.shared.errorResponse(moyaResponse: response))
                            }
                            
                        }
                    } else {
                        failure(ErrorHandler.shared.errorResponse(moyaResponse: response))
                    }
                } catch let error {
                    failure(error)// This code will run because the statusCode is 500
                }
                
            case .failure(let error):
                failure(error)
            }
        }
    }
}

