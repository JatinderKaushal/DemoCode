//
//  DocAppointmentsVC.swift
//  Doctors
//
//  Created by Mandeep Singh on 14/06/22.
//


import UIKit
import CoreLocation
import Kingfisher
import SideMenu

class DocAppointmentsVC: UIViewController, FiltersDelegate {
    
    @IBOutlet weak var filterview: UIView!
    @IBOutlet weak var btnclear: UIButton!
    @IBOutlet weak var btnFilter: UIButton!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var indicatorTblFooter: UIActivityIndicatorView!
    
    var isLoading = false
    var refreshControl = UIRefreshControl()
    private var arrFilters = [Int]()
    var sideController : SideMenuViewController!
    private let objDoctorAppointment = DoctorAppointmentsVIewModel()
    var viewModel = AppointmentsVM()
    override func viewWillAppear(_ animated: Bool) {
        self.objDoctorAppointment.currentPage = 1
        self.objDoctorAppointment.arrAppointments.removeAll()
        self.getAppointments(search: txtSearch.text, status: [])
        self.filterview.isHidden = true
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.filterview.layer.cornerRadius = 6
        
        SideMenuManager.default.addPanGestureToPresent(toView: navigationController!.navigationBar)
        SideMenuManager.default.addScreenEdgePanGesturesToPresent(toView: view)
        self.tblView.delegate = self
        self.tblView.dataSource = self
        self.refreshControl.addTarget(self, action: #selector(refreshData(_:)), for: .valueChanged)
        self.tblView.refreshControl = self.refreshControl
        self.getAppointments(search: nil, status: [])
    }
    
    @objc private func refreshData(_ sender: Any) {
        // Perform your data fetching here
        self.objDoctorAppointment.currentPage = 1
        self.objDoctorAppointment.arrAppointments.removeAll()
        self.getAppointments(search: txtSearch.text, status: [])
        self.endRefreshing()
    }
    
    func endRefreshing() {
        DispatchQueue.main.async { [weak self] in
            self?.refreshControl.endRefreshing()
        }
    }
    
    internal func selectedFilters(arr:[Int]){
        for uid in arr {
            if !self.arrFilters.contains(uid){
                self.arrFilters.append(uid)
            }
        }
    }
    
    func didApplyFilters(arr: [Int]) {
        selectedFilters(arr: arr)
        self.arrFilters.removeAll()
        self.arrFilters = arr
        self.objDoctorAppointment.arrAppointments.removeAll()
        if self.arrFilters.isEmpty {
            self.filterview.isHidden = true
        } else {
            self.filterview.backgroundColor = .green
            self.filterview.isHidden = false
        }
        self.getAppointments(search: nil, status: arr)
    }
    
    @IBAction func filterAction(_ sender: Any) {
        self.view.endEditing(true)
        let vc = FiltersVC.instantiateMain()
        vc.isFromAppointment = true
        vc.arrSelectedFilters = arrFilters
        vc.delegate = self
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func clearAction(_ sender: Any) {
        self.btnclear.isHidden = true
        self.txtSearch.text = nil
        self.objDoctorAppointment.arrAppointments.removeAll()
        self.getAppointments(search: "", status: [])
    }
}

extension DocAppointmentsVC: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField.text!.count >= 3 {
            // Call your API
            self.btnclear.isHidden = false
            self.objDoctorAppointment.arrAppointments.removeAll()
            self.getAppointments(search: textField.text, status: [])
        } else {
            self.btnclear.isHidden = true
        }
        self.btnclear.isHidden = false
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.btnclear.isHidden = false
    }
    
    private func getAppointments(search: String?, status: [Int]) {
        guard !isLoading else {
            return
        }
        isLoading = true
        self.showSpinner()
        self.objDoctorAppointment.GetAppointmentsOrHistory(isAppointment: true, search: search, status: status){ [weak self] status, msg in
            self?.hideSpinner()
            self?.isLoading = false
            self?.indicatorTblFooter.isHidden = true
            if msg == Constants.defaultPaginationMessage {
                //self?.indicatorTblFooter.stopAnimating()
                self?.hideSpinner()
                self?.tblView.reloadData()
                return
            }
            if status {
                self?.tblView.reloadData()
            } else {
                self?.showToast(message: msg)
                self?.hideSpinner()
            }
        }
    }
}

extension DocAppointmentsVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        self.objDoctorAppointment.count()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tblView.dequeueReusableCell(withIdentifier: "cellid") as? DoctorAppointmentsTblCell else {
            return UITableViewCell()
        }
        cell.imgUser.layer.cornerRadius = 15
        if self.objDoctorAppointment.arrAppointments[indexPath.row].appointment_status == 0 {
            cell.btnAccept.isHidden = false
            cell.btnDecline.isHidden = false
            cell.middelLine.isHidden = false
            cell.lblStatus.isHidden = true
            cell.acceptAction = { [weak self] in
                let appointmentID = self?.objDoctorAppointment.arrAppointments[indexPath.row].id
                AlertManager.shared.showAlert(message: "Are you sure you want to accept this appointment", actionTitles: ["Yes", "No"]) { index, _ in
                    if index == 0 {
                        self?.objDoctorAppointment.acceptAppointment(urlEndPoint: "accept-appointment", appointmentID: appointmentID!, reason: "") { success, message in
                            if success {
                                guard let vc = self?.storyboard?.instantiateViewController(withIdentifier: "DocAppointmentsDetailsVC") as? DocAppointmentsDetailsVC else { return }
                                vc.id = appointmentID
                                vc.viewModel = self?.viewModel
                                vc.objDoctorAppointment = self?.objDoctorAppointment
                                self?.navigationController?.pushViewController(vc, animated: true)
                                print("Appointment accepted successfully")
                            } else {
                                print("Failed to accept appointment: \(message)")
                            }
                        }
                    } else {
                        AlertManager.shared.dismissAlert()
                    }
                }
            }
            cell.declineAction = { [weak self] in
                let appointmentID = self?.objDoctorAppointment.arrAppointments[indexPath.row].id
                AlertManager.shared.showInputAlert(title: "Please enter declination reason", placeholder: "Type here", saveActionTitle: "Decline", saveAction: { message in
                    if let message = message {
                        print("User entered message: \(message)")
                        self?.objDoctorAppointment.acceptAppointment(urlEndPoint: "decline-appointment", appointmentID: appointmentID!, reason: message) { success, message in
                            if success {
                                self?.getAppointments(search: nil, status: [])
                                print("Appointment declinde successfully")
                            } else {
                                print("Failed to decline appointment: \(message)")
                            }
                        }
                    } else {
                        print("User cancelled")
                    }
                }, cancelAction: nil)
            }
        } else {
            cell.btnAccept.isHidden = true
            cell.btnDecline.isHidden = true
            cell.lblStatus.isHidden = false
            cell.middelLine.isHidden = true
        }
        if let urlImg = URL(string: objDoctorAppointment.getPic(index: indexPath.row)){
            cell.imgUser.kf.setImage(with: urlImg, placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
        }
        cell.lblName.text = objDoctorAppointment.getTitle(index: indexPath.row)
        cell.lblDate.text = objDoctorAppointment.getAppointmentDate(index: indexPath.row)
        cell.lblStatus.text = objDoctorAppointment.getAppointmentStatus(index: indexPath.row)
        cell.lblStatus.textColor = objDoctorAppointment.getAppointmentStatusColor(index: indexPath.row)
        cell.lblSymptoms.text = objDoctorAppointment.getSymtoms(index: indexPath.row)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let appointmentID = self.objDoctorAppointment.arrAppointments[indexPath.row].id
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "DocAppointmentsDetailsVC") as? DocAppointmentsDetailsVC else { return }
        vc.id = appointmentID
        vc.viewModel = self.viewModel
        vc.objDoctorAppointment = self.objDoctorAppointment
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        188.0
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if indexPath.row == objDoctorAppointment.arrAppointments.count - 1, objDoctorAppointment.currentPage < objDoctorAppointment.totalPages {
            print("index",indexPath.row)
            print("count",objDoctorAppointment.arrAppointments.count)
            objDoctorAppointment.currentPage += 1
            self.getAppointments(search: nil, status: [])
        }
    }
}

class DoctorAppointmentsTblCell:UITableViewCell {
    
    @IBOutlet weak var btnAccept: UIButton!
    @IBOutlet weak var btnDecline: UIButton!
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var middelLine: UIView!
    @IBOutlet weak var lblSymptoms: UILabel!
    @IBOutlet weak var lblStatus: UILabel!
    
    var acceptAction: (() -> Void)?
    var declineAction: (() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.btnAccept.addTarget(self, action: #selector(acceptButtonTapped(_:)), for: .touchUpInside)
        self.btnDecline.addTarget(self, action: #selector(declineButtonTapped(_:)), for: .touchUpInside)
    }
    
    @IBAction func acceptButtonTapped(_ sender: UIButton) {
        acceptAction?()
    }
    
    @IBAction func declineButtonTapped(_ sender: UIButton) {
        declineAction?()
    }
}
