//
//  FiltersVC.swift
//  Doctors
//
//  Created by Aksa on 22/03/24.
//

import Foundation
import UIKit
protocol FiltersDelegate: AnyObject {
    func didApplyFilters(arr: [Int])
}

class FiltersVC: UIViewController {

    @IBOutlet weak var collectionViewFilters: UICollectionView!
    internal var arrSelectedFilters = [Int]()
    weak var delegate: FiltersDelegate?
    var isFromAppointment = Bool()
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.view.backgroundColor = .clear
    }
    
    @IBAction func btnCancel(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    @IBAction func btnSave(_ sender: Any) {
        if isFromAppointment {
            if let vc = (self.presentingViewController as? UINavigationController)?.viewControllers.last as? DocAppointmentsVC{
                vc.selectedFilters(arr:arrSelectedFilters)
            } else if let vc = ((self.presentingViewController as? UINavigationController)?.viewControllers.last?.children.last as? UINavigationController)?.viewControllers.last as? DocAppointmentsVC{
                vc.selectedFilters(arr:arrSelectedFilters)
            } else {
                print("================hiraricy problem ====================")
            }
        } else {
            if let vc = (self.presentingViewController as? UINavigationController)?.viewControllers.last as? HistoryListViewController{
                vc.selectedFilters(arr:arrSelectedFilters)
            } else if let vc = ((self.presentingViewController as? UINavigationController)?.viewControllers.last?.children.last as? UINavigationController)?.viewControllers.last as? HistoryListViewController{
                vc.selectedFilters(arr:arrSelectedFilters)
            } else {
                print("================hiraricy problem ====================")
            }
        }
        delegate?.didApplyFilters(arr: arrSelectedFilters)
            self.dismiss(animated: true, completion: nil)
    }
}

extension FiltersVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if isFromAppointment {
            return Constants.Filters.count
        }else {
            return Constants.HistoryFilters.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionViewFilters.dequeueReusableCell(withReuseIdentifier: "cellid", for: indexPath) as? SpecializaationClcCell else {
            return UICollectionViewCell()
        }
        if isFromAppointment {
            if arrSelectedFilters.contains(Constants.Filters[indexPath.item].value){
                cell.lblTitle.text = Constants.Filters[indexPath.item].name
                cell.imgSelect.image = UIImage(named: "blank-check-box2")
            } else {
                cell.lblTitle.text = Constants.Filters[indexPath.item].name
                cell.imgSelect.image = UIImage(named: "blank-check-box")
            }
        } else {
            if arrSelectedFilters.contains(Constants.HistoryFilters[indexPath.item].value){
                cell.lblTitle.text = Constants.HistoryFilters[indexPath.item].name
                cell.imgSelect.image = UIImage(named: "blank-check-box2")
            } else {
                cell.lblTitle.text = Constants.HistoryFilters[indexPath.item].name
                cell.imgSelect.image = UIImage(named: "blank-check-box")
            }
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if isFromAppointment {
            let day = Constants.Filters[indexPath.item].value
            if let index = arrSelectedFilters.firstIndex(of:day ){
                self.arrSelectedFilters.remove(at: index)
            } else {
                self.arrSelectedFilters.append(day)
            }
            self.collectionViewFilters.reloadData()
        } else {
            let day = Constants.HistoryFilters[indexPath.item].value
            if let index = arrSelectedFilters.firstIndex(of:day ){
                self.arrSelectedFilters.remove(at: index)
            } else {
                self.arrSelectedFilters.append(day)
            }
            self.collectionViewFilters.reloadData()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if isFromAppointment {
            return CGSize(width: self.collectionViewFilters.frame.width, height: self.collectionViewFilters.frame.height/6)
        } else {
            return CGSize(width: self.collectionViewFilters.frame.width, height: self.collectionViewFilters.frame.height/5)
        }
        
    }
    
}
