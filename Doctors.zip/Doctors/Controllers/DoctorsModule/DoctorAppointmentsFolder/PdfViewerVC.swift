//
//  PdfViewer.swift
//  Doctors
//
//  Created by Aksa on 22/04/24.
//

import UIKit
import PDFKit
class PdfViewerVC: UIViewController {
    @IBOutlet var pdfView: PDFView!
    var path = String()
    override func viewDidLoad() {
        super.viewDidLoad()
        if let finalUrl =  URL(string: Api.MainUrl + path) {
            if let pdfDocument = PDFDocument(url: finalUrl) {
                pdfView.displayMode = .singlePageContinuous
                pdfView.autoScales = true
                pdfView.displayDirection = .vertical
                pdfView.document = pdfDocument
            }
        }
    }
    @IBAction func btnBackAct(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
