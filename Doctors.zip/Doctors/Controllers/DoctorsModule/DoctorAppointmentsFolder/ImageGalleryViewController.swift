//
//  GalleryVC.swift
//  Doctors
//
//  Created by Aksa on 08/03/24.
//

import Foundation
import UIKit

class ImageGalleryViewController: UIViewController {
    var images: [PatientPrescription] = []
    var currentIndex: Int?
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let index = self.currentIndex else {
            return
        }
        if let url = images[index].prescription {
            
            self.imageView.kf.setImage(with: URL(string: Api.MainUrl+(url)), placeholder: nil, options: nil, completionHandler: nil)
            // Add swipe gesture recognizers for left and right swipes
            let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
            swipeRight.direction = .right
            view.addGestureRecognizer(swipeRight)
            let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
            swipeLeft.direction = .left
            view.addGestureRecognizer(swipeLeft)
        }
    }
    
    @IBAction func btnCloseAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func handleSwipe(_ gesture: UISwipeGestureRecognizer) {
        if gesture.direction == .left {
            self.showNextImage()
        } else if gesture.direction == .right {
            self.showPreviousImage()
        }
    }
    
    func showNextImage() {
        self.currentIndex = ((self.currentIndex ?? 0) + 1) % images.count
        self.imageView.kf.setImage(with: URL(string: Api.MainUrl+(images[currentIndex ?? 0].prescription ?? "")), placeholder: nil, options: nil, completionHandler: nil)
    }
    
    func showPreviousImage() {
        self.currentIndex = ( (self.currentIndex ?? 0) - 1 + images.count) % images.count
        self.imageView.kf.setImage(with: URL(string: Api.MainUrl+(images[currentIndex ?? 0].prescription ?? "")), placeholder: nil, options: nil, completionHandler: nil)
    }
}
