//
//  WorkingHours.swift
//  Doctors
//
//  Created by iOS on 04/05/22.
//

import UIKit

class WorkingHours: UIViewController, UITableViewDelegate,  UITableViewDataSource {
    
    var expandRow = Set<Int>()
    var startTime = [String]()
    var endTime = [String]()
    var startBreakTime = [String]()
    var endBreakTime = [String]()
    var startTimeBtnTag = -1
    var endTimeBtnTag = -1
    var startBreakTimeBtnTag = -1
    var endBreakTimeBtnTag = -1
    var days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    var selectedIndex = -1
    
    @IBOutlet weak var tableView: UITableView!

    //    @IBAction func addButtonTapped(_ sender: UIButton) {
    //        expandRow.insert(sender.tag)
    //
    //        self.tableView.reloadData()
    //    }
    //
    //    @IBAction func closeBtnTapped(_ sender: UIButton) {
    //        expandRow.remove(sender.tag)
    //
    //        tableView.reloadData()
    //    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.initStartTimeEndTime()
    }
    
    @IBAction func backBtnTapped(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "WorkingHoursCell", for: indexPath) as? WorkingHoursCell else {
            return UITableViewCell()
        }
        cell.cellText?.text = days[indexPath.row]
        cell.startTimeBtn.tag = indexPath.row
        cell.endTimeBtn.tag = indexPath.row
        cell.startTimeBtn.setTitle(startTime[indexPath.row], for: .normal)
        cell.endTimeBtn.setTitle(endTime[indexPath.row], for: .normal)
        cell.startBreakTimeBtn.tag = indexPath.row
        cell.endBreakTimeBtn.tag = indexPath.row
        cell.startBreakTimeBtn.setTitle(startBreakTime[indexPath.row], for: .normal)
        cell.endBreakTimeBtn.setTitle(endBreakTime[indexPath.row], for: .normal)
        
        if self.selectedIndex == indexPath.row {
            cell.breakBar.isHidden = false
        } else {
            cell.breakBar.isHidden = true
        }
        cell.arrowButtonTapped = { (button:UIButton) -> Void in
            if self.selectedIndex == indexPath.row {
                self.selectedIndex = -1
            } else {
                self.selectedIndex  = indexPath.row
            }
            self.tableView.reloadData()
            //            tableView.beginUpdates()
            //            tableView.reloadRows(at: [indexPath], with:                     UITableView.RowAnimation.automatic)
            //            tableView.endUpdates()
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //  for i in expandRow {
        if (self.selectedIndex == indexPath.row){
            return 90 //Expanded
        } else {
            return 50
        }
    }
    
    @IBAction func startTimeBtnTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "TimePicker") as? TimePicker
        startTimeBtnTag = sender.tag
        endTimeBtnTag = -1
        //vc!.delegate = self
        vc!.modalPresentationStyle = .fullScreen
        self.present(vc!, animated: true)
    }
    
    @IBAction func endTimeBtnTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "TimePicker") as? TimePicker
        endTimeBtnTag = sender.tag
        startTimeBtnTag = -1
       // vc!.delegate = self
        vc!.modalPresentationStyle = .fullScreen
        self.present(vc!, animated: true)
    }
    
    @IBAction func startBreakTimeBtnTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "TimePicker") as? TimePicker
        startBreakTimeBtnTag = sender.tag
        endBreakTimeBtnTag = -1
       // vc!.delegate = self
        vc!.modalPresentationStyle = .fullScreen
        self.present(vc!, animated: true)
    }
    
    @IBAction func endBreakTimeBtnTapped(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "TimePicker") as? TimePicker
        endBreakTimeBtnTag = sender.tag
        startBreakTimeBtnTag = -1
       // vc!.delegate = self
        vc!.modalPresentationStyle = .fullScreen
        self.present(vc!, animated: true)
    }
    
    func returnStringData(myData: String) {
        
        if startTimeBtnTag >= 0 {
            startTime[startTimeBtnTag] = myData
            startTimeBtnTag = -1
        }
        else if endTimeBtnTag >= 0 {
            
            endTime[endTimeBtnTag] = myData
            endTimeBtnTag = -1
        }
        
        else if startBreakTimeBtnTag >= 0{
            startBreakTime[startBreakTimeBtnTag] = myData
            startBreakTimeBtnTag = -1
        }
        else{
            
            endBreakTime[endBreakTimeBtnTag] = myData
            endBreakTimeBtnTag = -1
        }
        tableView.reloadData()
    }

    
    func initStartTimeEndTime() {
        for _ in 0...days.count {
            startTime.append("08:00 AM")
            endTime.append("08:00 PM")
            startBreakTime.append("")
            endBreakTime.append("")
        }
    }
    
}

class WorkingHoursCell: UITableViewCell {
    
    @IBOutlet weak var checkImage: UIImageView!
    @IBOutlet weak var checkBtn: UIButton!
    @IBOutlet weak var cellText: UILabel!
    @IBOutlet weak var addBreakButton: UIButton!
    @IBOutlet weak var closeBreakBarButton: UIButton!
    @IBOutlet weak var breakBar: UIView!
    @IBOutlet weak var startTimeBtn: UIButton!
    @IBOutlet weak var endTimeBtn: UIButton!
    @IBOutlet weak var startBreakTimeBtn: UIButton!
    @IBOutlet weak var endBreakTimeBtn: UIButton!
    
    typealias arrowButtonTappedBlock = (_ button:UIButton) -> Void
    
    let imageEmpty = UIImage(named: "checkEmpty")
    let imageChecked = UIImage(named: "checked")
    var arrowButtonTapped : arrowButtonTappedBlock!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    @IBAction func checkBtnTapped(_ sender: UIButton) {
        if checkImage.image == imageEmpty {
            checkImage.image = imageChecked
        } else {
            checkImage.image = imageEmpty
        }
    }
    
    @IBAction func addButtonTapped(_ sender: UIButton) {
         if arrowButtonTapped != nil {
            arrowButtonTapped(sender)
        }
    }
     
    @IBAction func closeButtonTapped(_ sender: UIButton) {
        if arrowButtonTapped != nil {
            arrowButtonTapped(sender)
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
