//
//  HistoryListViewController.swift
//  Doctors
//
//  Created by Mandeep Singh on 17/06/22.
//

import UIKit

class HistoryListViewController: UIViewController, FiltersDelegate {
    @IBOutlet weak var btnClear: UIButton!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var btnFilter: UIButton!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var indicatorTblFooter: UIActivityIndicatorView!
    
    private var arrFilters = [Int]()
    private let objDoctorHistory = DoctorAppointmentsVIewModel()
    var viewModel = AppointmentsVM()
    var isLoading = false
    var refreshControl = UIRefreshControl()
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.delegate = self
        tblView.dataSource = self
        self.txtSearch.delegate = self
        refreshControl.addTarget(self, action: #selector(refreshData(_:)), for: .valueChanged)
        tblView.refreshControl = refreshControl
        self.GetHistory(search: nil, status: [])
    }
    
    internal func selectedFilters(arr:[Int]){
        for uid in arr{
            if !self.arrFilters.contains(uid){
                self.arrFilters.append(uid)
            }
        }
    }
    @objc private func refreshData(_ sender: Any) {
        // Perform your data fetching here
        objDoctorHistory.currentPage = 1
        objDoctorHistory.arrHistory.removeAll()
        GetHistory(search: txtSearch.text, status: [])
        endRefreshing()
    }
    func endRefreshing() {
        DispatchQueue.main.async { [weak self] in
            self?.refreshControl.endRefreshing()
        }
    }
    
    func didApplyFilters(arr: [Int]) {
            selectedFilters(arr: arr)
        self.arrFilters.removeAll()
        self.arrFilters = arr
        objDoctorHistory.arrHistory.removeAll()
        GetHistory(search: nil, status: arr) // Call API here
        }
    
    @IBAction func filterAction(_ sender: Any) {
        self.view.endEditing(true)
        let vc = FiltersVC.instantiateMain()
        vc.isFromAppointment = false
        vc.arrSelectedFilters = arrFilters
        vc.delegate = self // Set delegate
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }

    @IBAction func clearAction(_ sender: Any) {
        
        self.btnClear.isHidden = true
        self.txtSearch.text = nil
        objDoctorHistory.arrHistory.removeAll()
        self.GetHistory(search: "", status: [])

    }
}

extension HistoryListViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField.text!.count >= 3 {
            // Call your API
            self.btnClear.isHidden = false
            objDoctorHistory.arrHistory.removeAll()
            GetHistory(search: textField.text!, status: [])
        } else {
            self.btnClear.isHidden = true
        }
        self.btnClear.isHidden = false
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        self.btnClear.isHidden = false
       }
}


extension HistoryListViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        objDoctorHistory.countHistory()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tblView.dequeueReusableCell(withIdentifier: "cellid") as? DoctorAppointmentsTblCell else {
            return UITableViewCell()
        }
        if let urlImg = URL(string: objDoctorHistory.getPicHistory(index: indexPath.row)){
            cell.imgUser.kf.setImage(with: urlImg, placeholder: Constants.PatiantPlaceholderImage, options: nil, completionHandler: nil)
        }
        cell.acceptAction = { [weak self] in
            // Retrieve the appointment ID associated with the cell's index path
            
        }
        
        cell.declineAction = { [weak self] in
            // Retrieve the appointment ID associated with the cell's index path
            
        }
        cell.lblName.text = objDoctorHistory.getTitleHistory(index: indexPath.row)
        cell.lblDate.text = objDoctorHistory.getAppointmentDateHistory(index: indexPath.row)
        cell.lblStatus.text = objDoctorHistory.getAppointmentStatusHistory(index: indexPath.row)
        cell.lblStatus.textColor = objDoctorHistory.getAppointmentStatusColorHistory(index: indexPath.row)
        cell.lblSymptoms.text = objDoctorHistory.getSymtomsHistory(index: indexPath.row)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let appointmentID = self.objDoctorHistory.arrHistory[indexPath.row].id {
            self.getAppointmentDetails(id: appointmentID)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        188.0
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
            if indexPath.row == self.objDoctorHistory.arrHistory.count - 1, self.objDoctorHistory.currentPage < self.objDoctorHistory.totalPages {
                print("index",indexPath.row)
                print("count",self.objDoctorHistory.arrAppointments.count)
                self.objDoctorHistory.currentPage += 1
                self.GetHistory(search: nil, status: [])
                }
        }
}

// MARK: - Details of Appointment API Call
extension HistoryListViewController {
    
    private func GetHistory(search:String?, status:[Int]) {
        objDoctorHistory.GetAppointmentsOrHistory(isAppointment: false, search: search, status: status){ [weak self] status, msg in
            //   self?.hideSpinner()
            self?.indicatorTblFooter.isHidden = true
            if msg == Constants.defaultPaginationMessage {
                self?.indicatorTblFooter.stopAnimating()
                return
            }
            if status {
                self?.tblView.reloadData()
            } else {
                self?.showToast(message: msg)
            }
        }
    }
    func getAppointmentDetails(id: Int) {
        self.viewModel.getAppointmentDetails(id: id) { _ in
            guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "DocAppointmentsDetailsVC") as? DocAppointmentsDetailsVC else { return }
            vc.viewModel = self.viewModel
            self.navigationController?.pushViewController(vc, animated: true)
        } failure: { error in
            ErrorHandler.shared.currentViewController = self
            ErrorHandler.shared.handleError(error: error)
            
        }
    }
}
