//
//  SideMenuViewController.swift
//  Doctors
//
//  Created by Mandeep Singh on 10/06/22.
//

import UIKit
import Kingfisher
class SideMenuViewController: UIViewController {
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var mainViewWidth: NSLayoutConstraint!
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblTItle: UILabel!
    @IBOutlet weak var lblSubtitle: UILabel!
    @IBOutlet weak var tableView: UITableView!{
        didSet{
            tableView.delegate = self
            tableView.dataSource = self
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
        if let imgUrl = URL(string: Api.imageUrl(endpoint: DefaultsClass.shared.profilePic)){
            self.imgUser.kf.setImage(with: imgUrl, placeholder: nil, options: nil, completionHandler: nil)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblTItle.text = DefaultsClass.shared.name
        if DefaultsClass.shared.role == "2" {
            lblSubtitle.text = "Doctor"
        } else {
            lblSubtitle.text = "Patient"
        }
       
        if let imgUrl = URL(string: Api.imageUrl(endpoint: DefaultsClass.shared.profilePic)){
            self.imgUser.kf.setImage(with: imgUrl, placeholder: nil, options: nil, completionHandler: nil)
        }
    }
    
    override func viewDidLayoutSubviews() {
        self.mainViewWidth.constant = Constants.screenWidth / 1.5
        self.tableView.reloadData()
    }
}

extension SideMenuViewController:UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if DefaultsClass.shared.role == "2" {
            return Constants.DoctorMenu.count
        } else {
            return Constants.PatientMenu.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tableView.dequeueReusableCell(withIdentifier: "cellid", for: indexPath) as! SideMenuCell
        
        // Reset cell background color
        cell.viewMain.backgroundColor = .clear
        
        if DefaultsClass.shared.role == "2" {
            cell.menuTitle.text = Constants.DoctorMenu[indexPath.row].name
            cell.menuIcon.image = Constants.DoctorMenu[indexPath.row].value
            cell.viewMain.roundCorners(corners: [.topRight,.bottomRight], radius: 27.0)
            
            if Constants.selectedDoctorMenu.uid == Constants.DoctorMenu[indexPath.row].uid {
                // Set selected cell background color to blue
                cell.viewMain.backgroundColor = Constants.MainColorSkyBlue
                cell.menuTitle.textColor = .white
                cell.menuIcon.image = cell.menuIcon.image?.imageWithColor(color: UIColor.white)
            } else {
                if traitCollection.userInterfaceStyle == .dark {
                    // Use the color named "YourDarkColor" from the asset catalog for dark mode
                    cell.menuTitle.textColor = .white
                    cell.menuIcon.image = cell.menuIcon.image?.imageWithColor(color: Constants.MainColorSkyBlue)
                } else {
                    // Use the color named "YourLightColor" from the asset catalog for light mode
                    cell.menuTitle.textColor = .black
                    cell.menuIcon.image = cell.menuIcon.image?.imageWithColor(color: Constants.MainColorSkyBlue)
                }
            }
        } else {
            cell.menuTitle.text = Constants.PatientMenu[indexPath.row].name
            cell.menuIcon.image = Constants.PatientMenu[indexPath.row].value
            cell.viewMain.roundCorners(corners: [.topRight,.bottomRight], radius: 27.0)
            
            if Constants.selectedPatientMenu.uid == Constants.PatientMenu[indexPath.row].uid {
                // Set selected cell background color to blue
                cell.viewMain.backgroundColor = Constants.MainColorSkyBlue
                cell.menuTitle.textColor = .white
                cell.menuIcon.image = cell.menuIcon.image?.imageWithColor(color: UIColor.white)
            } else {
                if traitCollection.userInterfaceStyle == .dark {
                    // Use the color named "YourDarkColor" from the asset catalog for dark mode
                    cell.menuTitle.textColor = .white
                    cell.menuIcon.image = cell.menuIcon.image?.imageWithColor(color: Constants.MainColorSkyBlue)
                } else {
                    cell.menuTitle.textColor = .black
                    cell.menuIcon.image = cell.menuIcon.image?.imageWithColor(color: Constants.MainColorSkyBlue)
                }
            }
        }
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if DefaultsClass.shared.role == "2" {
            Constants.selectedDoctorMenu = Constants.DoctorMenu[indexPath.row]
        } else {
            Constants.selectedPatientMenu = Constants.PatientMenu[indexPath.row] // Fix: Use Constants.selectedPatientMenu for patient role
        }
        var vc: UIViewController?
        if DefaultsClass.shared.role == "2" {
            switch Constants.DoctorMenu[indexPath.row].name {
            case "Appointments":
                if DefaultsClass.shared.role == "2" {
                    vc = DocAppointmentsVC.instantiateMain()
                } else {
                    vc = PatientsHomeVC.instantiatePatient()
                }
            case "Patient List":
                vc = PatientListViewController.instantiateMain()
            case "History":
                vc = HistoryListViewController.instantiateMain()
            case "Notifications":
                vc = NotificationViewController.instantiateMain()
            case "Profile":
                vc = DoctorRegistrationViewController.instantiateMain()
            case "Contact Us":
                vc = ContactUsViewController.instantiateMain()
            case "Logout":
                let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
                DefaultsClass.shared.isAlreadyIn = false
                sceneDelegate.setRootViewController(viewController: SelectRoleViewController.instantiateMain())
            default:
                break
            }
        } else {
            switch Constants.PatientMenu[indexPath.row].name {
            case "Home":
                vc = PatientsHomeVC.instantiatePatient()
            case "History":
                vc = PatientHistoryVC.instantiatePatient()
            case "Appointments":
                vc = PatientAppointmentsVC.instantiatePatient()
            case "Reports":
            vc = PatientsReportsVC.instantiatePatient()
            (vc as? PatientsReportsVC)?.isReport = true
            case "Prescription":
                vc = PatientsReportsVC.instantiatePatient()
            case "Notifications":
                vc = PatientsNotificationsVC.instantiatePatient()
            case "Profile":
                vc = PatientsProfileVC.instantiatePatient()
            case "Contact Us":
                vc = PatientsContactUsVC.instantiatePatient()
            case "Logout":
                let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
                DefaultsClass.shared.isAlreadyIn = false
                sceneDelegate.setRootViewController(viewController: SelectRoleViewController.instantiateMain())
            default:
                break
            }
        }
        guard let viewController = vc else { return }
        self.navigationController?.navigationBar.isHidden = true
        self.navigationController?.pushViewController(viewController, animated: false)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55.0
    }
}

class SideMenuCell: UITableViewCell {
    
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var menuIcon: UIImageView!
    @IBOutlet weak var menuTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}

