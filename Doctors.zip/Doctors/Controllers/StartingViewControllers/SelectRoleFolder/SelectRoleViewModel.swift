//
//  SelectRoleViewModel.swift
//  Doctors
//
//  Created by Mandeep Singh on 06/06/22.
//


import Foundation

struct SelectRoleModel: Codable {
    let message, response: String?
}

class SelectRoleViewModel {
    internal func loginUser(param: [String:Any], completion: @escaping(Bool,String)->()) {
        HitApi.shared.sendRequest(endPoint: Api.login, parameters: param) { (result:Result<SelectRoleModel,Error>) in
            switch result {
            case .success(let model):
                if model.message == "Success"{
                    completion(true, model.message ?? Constants.defaultServerMessage)
                }else{
                    completion(false, model.message ?? Constants.defaultServerMessage)
                }
                break
                
            case.failure(let error):
                completion(false,  error.localizedDescription)
                break
            }
        }
    }
}
