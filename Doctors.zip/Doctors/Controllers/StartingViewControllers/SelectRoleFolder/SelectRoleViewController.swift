//
//  SelectRoleViewController.swift
//  Doctors
//
//  Created by Mandeep Singh on 06/06/22.
//

import UIKit

class SelectRoleViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var docButton: UIButton!
    @IBOutlet weak var patientButton: UIButton!
    @IBOutlet weak var txtPhone: UITextField!{
        didSet{
            txtPhone.addTarget(self, action: #selector(SelectRoleViewController.textFieldDidChange(_:)), for: .editingChanged)
        }
    }
    @IBOutlet weak var viewDoctor: UIView!{
        didSet{
            viewDoctor.layer.cornerRadius = 15.0
            viewDoctor.clipsToBounds = true
        }
    }
    @IBOutlet weak var viewPatient: UIView!{
        didSet{
            viewPatient.layer.cornerRadius = 15.0
            viewPatient.clipsToBounds = true
        }
    }
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var imgPhone: UIImageView!
    
    //MARK: Varriables
    
    private let objSelectRole = SelectRoleViewModel()
    private var role: Int = 2 {
        didSet{
            if role == 2 {
                viewDoctor.backgroundColor = UIColor(named: "lightSkyBlue")
                viewDoctor.layer.borderColor = UIColor(named: "MainColorSkyBlue")!.cgColor
                viewDoctor.layer.borderWidth = 2
                viewPatient.layer.borderWidth = 0
                viewPatient.backgroundColor = UIColor(named: "lightGray")
            } else {
                viewPatient.backgroundColor = UIColor(named: "lightSkyBlue")
                viewPatient.layer.borderColor = UIColor(named: "MainColorSkyBlue")!.cgColor
                viewPatient.layer.borderWidth = 2
                viewDoctor.layer.borderWidth = 0
                viewDoctor.backgroundColor = UIColor(named: "lightGray")
            }
        }
    }
    
    //MARK: view did load
  override func viewDidLoad() {
        super.viewDidLoad()
       role = 2
//      self.txtPhone.text = "9876543210"
      self.txtPhone.text = "9906110207"
      self.txtPhone.delegate = self
    }
    
    @IBAction func docImgTapped(_ sender: UIButton) { role = 2 }
    @IBAction func pateintImgTapped(_ sender: UIButton) { role = 1 }
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        if textField.text!.count != 10{
            self.imgPhone.image = self.imgPhone.image!.imageWithColor(color: UIColor(named: "darkGray")!)
        }else{
            self.imgPhone.image = self.imgPhone.image!.imageWithColor(color: UIColor(named: "MainColorSkyBlue")!)
        }
    }
    
    @IBAction func loginRequest(_ sender: UIButton) {
        guard txtPhone.text! != "" else{
            self.showToast(message: "Phone Number Field Can't be Empty!", font: UIFont.systemFont(ofSize: 12))
            return
        }
        guard txtPhone.text!.count == 10 else{
            self.showToast(message: "Phone Number seems invalid!", font: UIFont.systemFont(ofSize: 12))
            return
        }
        
        /* If User has entered phone now call the API*/
        self.ApiLoginRegisterUser()
      }
    
    @IBAction func btnChangeAppEnvirement(_ sender: Any) {
        self.showActionSheet(control: ["development","statging"]) { str in
            if str == "development"{
                DefaultsClass.shared.appEnvironment = .development
            }else{
                DefaultsClass.shared.appEnvironment = .staging
            }
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = textField.text else { return true }
        let newLength = text.count + string.count - range.length
        return newLength <= 10
    }
   }

//MARK: APi Work in View controller
extension SelectRoleViewController{
   
   private func ApiLoginRegisterUser(){
       let param : [String: Any] = ["phone": self.txtPhone.text!, "role": role, "deviceToken": DefaultsClass.shared.APNS_Token]
       print(param)
       
          self.showSpinner()
       objSelectRole.loginUser(param: param) {[weak self] (status,msg) in
           self?.hideSpinner()
           if status{
               let vc = OTPViewController.instantiateMain()
               vc.numberText = self?.txtPhone.text ?? ""
               DefaultsClass.shared.phoneNumber = self?.txtPhone.text! ?? ""
               DefaultsClass.shared.role  = self?.role.getString() ?? ""
               self?.navigationController?.push(viewController: vc)
           }else{
               self?.showToast(message: msg, font: UIFont.systemFont(ofSize: 12))
           }
       }
   }

}
