//
//  SplashViewController.swift
//  Doctors
//
//  Created by Mandeep Singh on 07/06/22.
//


import UIKit
class SplashViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        DispatchQueue.main.asyncAfter(deadline: .now()+1.0) {
            self.SetEntryPoint()
        }
    }
    
    private func SetEntryPoint(){
            let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
             if DefaultsClass.shared.isAlreadyIn {
                 sceneDelegate.setRootViewController(viewController: PatientsHomeVC.instantiatePatient())
             } else {
                 sceneDelegate.setRootViewController(viewController: SelectRoleViewController.instantiateMain())
              }
         }

    
}
