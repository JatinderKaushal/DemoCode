//
//  OTPVIewModel.swift
//  Doctors
//
//  Created by Mandeep Singh on 06/06/22.
//

import Foundation

// MARK: - Welcome
struct OTPValidateModel: Codable {
    let message: String?
    let response: OtpResponseModel?
}

// MARK: - Response
struct OtpResponseModel: Codable {
    let jsonToken: String?
    let alreadyRegistered: Bool?
    let id: Int?
    let name: String?
    let image: String?
    let status: Int?
}
struct UpdateProfileModel: Codable {
    let message: String?
    let data: UpdateProfileData?
}

// MARK: - Response
struct UpdateProfileData: Codable {
    let jsonToken: String?
    let alreadyRegistered: Bool?
    let id: Int?
    let name: String?
    let image: String?
    let status: Int?
}

class OTPViewModel {
    internal func VerifyOtp(param:[String:Any],completion:@escaping(Bool,Bool,String)->()) {
        HitApi.shared.sendRequest(endPoint: Api.verifyOtp, parameters: param) { (result:Result<OTPValidateModel,Error>) in
            switch result {
            case .success(let model):
                if model.message == "OTP validated successfully" {
                    DefaultsClass.shared.accessToken = model.response?.jsonToken
                    if model.response?.alreadyRegistered ?? false {
                        DefaultsClass.shared.id = (model.response?.id)!
                        DefaultsClass.shared.name = model.response?.name ?? ""
                        DefaultsClass.shared.profilePic = model.response?.image ?? ""
                    }
                    completion(true,model.response?.alreadyRegistered ?? false ,model.message ?? Constants.defaultServerMessage)
                } else {
                    completion(false,false ,model.message ?? Constants.defaultServerMessage)
                }
                break;
                
            case.failure(let error):
                completion(false,false ,error.localizedDescription)
                break;
            }
        }
    }
}


