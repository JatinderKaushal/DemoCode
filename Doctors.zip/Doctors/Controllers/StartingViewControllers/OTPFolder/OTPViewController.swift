//
//  OTPViewController.swift
//  Doctors
//
//  Created by Mandeep Singh on 06/06/22.
//


import UIKit
import SwiftUI
import AVFoundation
import OTPFieldView

class OTPViewController: UIViewController, UITextFieldDelegate, OTPFieldViewDelegate {
    
    @IBOutlet weak var otpTextField: OTPFieldView!
    @IBOutlet weak var lblNumber: UILabel!
    @IBOutlet weak var textDescription: UILabel!
    @IBOutlet weak var countDownLabel: UILabel!
    @IBOutlet weak var resendBtn: UIButton!
    
    private var userOtp: String = ""
    private let objSelectRole = SelectRoleViewModel()
    private let objVerifyOtp = OTPViewModel()
    private var secondsRemaining = 59
    var numberText : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.countDownLabel.text = "00:\(secondsRemaining)"
        self.resendBtn.isEnabled = false
        self.textDescription.text = "Please enter the verfication code sent to"
        self.lblNumber.text = self.numberText
        self.setupOtpView()
        self.startTimer()
    }
    
    func setupOtpView() {
        self.otpTextField.fieldsCount = 6
        self.otpTextField.fieldBorderWidth = 1.5
        let myColor = UIColor(named: "Commonwhiteandblack")
        self.otpTextField.defaultBackgroundColor = myColor ?? .gray
        self.otpTextField.defaultBorderColor = UIColor.clear
        self.otpTextField.filledBackgroundColor = myColor ?? .gray
        self.otpTextField.filledBorderColor = AppColors.appThemeColor
        self.otpTextField.cursorColor = AppColors.appThemeColor
        self.otpTextField.displayType = .circular
        self.otpTextField.fieldSize = 50
        self.otpTextField.separatorSpace = 10
        self.otpTextField.fieldFont =  UIFont.init(name: "Montserrat-Regular", size: 16.0) ?? .systemFont(ofSize: 16)
        self.otpTextField.shouldAllowIntermediateEditing = false
        self.otpTextField.delegate = self
        self.otpTextField.initializeUI()
    }
    
    
    func enteredOTP(otp: String) {
        self.userOtp = otp
    }
    
    func hasEnteredAllOTP(hasEnteredAll: Bool) -> Bool {
        true
    }
    
    func shouldBecomeFirstResponderForOTP(otpTextFieldIndex index: Int) -> Bool {
        true
    }
    
    func didUserFinishEnter(the code: String) {
        print(code)
    }
    
    private func startTimer() {
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { (Timer) in
            if self.secondsRemaining > 9 {
                self.countDownLabel.text = "00:\(self.secondsRemaining)"
                self.secondsRemaining -= 1
            } else if self.secondsRemaining >= 0{
                self.countDownLabel.text = "00:0\(self.secondsRemaining)"
                self.secondsRemaining -= 1
            } else {
                self.resendBtn.isEnabled = true
            }}
    }
    
    @IBAction func arrowBtnTapped(_ sender: UIButton) {
        self.apiVerifyOtp()
    }
    
    @IBAction func resendBtnTapped(_ sender: UIButton) {
        /* Resend code Api*/
        self.apiLoginRegisterUser()
    }
}

//MARK: - API Calls in View controller
extension OTPViewController {
    
    private func apiLoginRegisterUser(){
        let param : [String: Any] = ["phone": DefaultsClass.shared.phoneNumber, "role": DefaultsClass.shared.role, "deviceToken": DefaultsClass.shared.APNS_Token]
        print(param)
        
        self.showSpinner()
        self.objSelectRole.loginUser(param: param) {[weak self] (status,msg) in
            self?.hideSpinner()
            if status{
                self?.showToast(message: msg)
            } else {
                self?.showToast(message: msg)
            }
        }
    }
    
    private func apiVerifyOtp() {
        let param: [String: Any] = ["phone": DefaultsClass.shared.phoneNumber,
                                    "role": DefaultsClass.shared.role,
                                    "otp": "\(userOtp)"]
        self.showSpinner()
        self.objVerifyOtp.VerifyOtp(param: param) {[weak self] Status, alreadyRegistered, msg in
            self?.hideSpinner()
            if Status {
                DefaultsClass.shared.isAlreadyIn = true
                if  DefaultsClass.shared.role == "2" {
                    if alreadyRegistered {
                         Constants.currentDoctorFillInfoType = .editPofile
                        let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
                        sceneDelegate.setRootViewController(viewController: DocAppointmentsVC.instantiateMain())
                        
                    } else {
                        Constants.currentDoctorFillInfoType = .registration
                        let vc = DoctorRegistrationViewController.instantiateMain()
                        self?.navigationController?.pushViewController(vc, animated: true)
                    }
                    return
                } else {
                    if alreadyRegistered {
                        let sceneDelegate = UIApplication.shared.connectedScenes.first?.delegate as! SceneDelegate
                        sceneDelegate.setRootViewController(viewController: PatientsHomeVC.instantiatePatient())
                    } else {
                        let vc = PatientSignUpVC.instantiatePatient()
                        self?.navigationController?.pushViewController(vc, animated: true)
                    }
                    return
                }
            }
            /* Show Error if occured*/
            self?.showToast(message: msg)
        }
    }
}
