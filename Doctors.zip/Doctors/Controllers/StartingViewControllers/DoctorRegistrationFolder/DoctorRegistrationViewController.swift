//
//  DoctorRegistrationViewController.swift
//  Doctors
//
//  Created by Mandeep Singh on 08/06/22.
//


import UIKit
import CoreLocation
import GoogleMaps
import DropDown
import GameController

class DoctorRegistrationViewController: UIViewController,UITextFieldDelegate {
    var mainDict = [[String: Any]]()
    
    @IBOutlet weak var viewTime: UIView!
    @IBOutlet weak var btnSideMenu: UIButton!
    @IBOutlet var imgDummies: [UIImageView]!{
        didSet{
            for img in imgDummies{
                img.image = img.image?.imageWithColor(color: UIColor(named: "MainColorSkyBlue")!)
            }
        }
    }
    
    @IBOutlet var viewsTxtField: [UIView]!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet var mapView: GMSMapView!{ didSet { mapView.delegate = self } }
    @IBOutlet weak var workingHrsStartTimeLabel: UILabel!
    @IBOutlet weak var workingHrsEndTimeLabel: UILabel!
    @IBOutlet weak var workingHrsStartTimeBtn: UIButton!
    @IBOutlet weak var workingHrsEndTimeBtn: UIButton!
    @IBOutlet weak var textViewGender: UIView!
    
    @IBOutlet weak var imgViewDoctor: UIImageView!
    @IBOutlet weak var txtFieldName: UITextField!
    @IBOutlet weak var txtFielsPhone: UITextField!
    @IBOutlet weak var txtFieldDocSpecialization: UITextField!{ didSet { txtFieldDocSpecialization.delegate = self } }
    @IBOutlet weak var txtFieldGender: UITextField!{ didSet { txtFieldGender.delegate = self } }
    @IBOutlet weak var txtFieldSelectDays: UITextField!{ didSet { txtFieldSelectDays.delegate = self } }
    @IBOutlet weak var txtViewAddress: UITextView! //{
//        didSet {
//            txtViewAddress.delegate = self
//        }
//    }
    @IBOutlet weak var txtViewPersonalInfo: UITextView! //{
//        didSet {
//            txtViewPersonalInfo.delegate = self
//        }
  //  }
    private var callerTimeLabelTag: Int = 0
    private let locationManager = CLLocationManager()
    private var centerMapCoordinate:CLLocationCoordinate2D!
    private var centeredMarker:GMSMarker!
    private let dropDown = DropDown()
    private let imagePicker = UIImagePickerController()
    private var selectedGender = Int() {
        didSet {
            let strGender = (Constants.GenderList.filter({$0.value == selectedGender})).first?.name
            self.txtFieldGender.text = strGender ?? ""
        }
    }
    private var arrSpecialization = [Int]() {
        didSet {
            self.txtFieldDocSpecialization.text = self.arrSpecialization.count != 0 ? "Specialization Selected" :  "Select atleast one Specialization"
        }
    }
    private var arrWorkingDays = [Int]() {
        didSet {
            self.txtFieldSelectDays.text = self.arrWorkingDays.count != 0 ? "Working days Selected" :  "Select atleast one Working day"
        }
    }
    
    private var startTimeStamp = Date() {
        didSet {
            self.workingHrsStartTimeLabel.text = Constants.convert_hh_mm_a(date:startTimeStamp)
        }
    }
    private var endTimeStamp = Date() {
        didSet {
            self.workingHrsEndTimeLabel.text = Constants.convert_hh_mm_a(date:endTimeStamp)
        }
    }
    private var selectedLocation : CLLocationCoordinate2D?
    private let objDoctorRegister = DoctorRegisterationViewModel()
    
    
    private func SetControllerContantMode() {
        if self.navigationController?.viewControllers.count ?? 0 > 2, let _ = self.navigationController?.viewControllers[((self.navigationController?.viewControllers.count)!-2)] as? OTPViewController{
            Constants.currentDoctorFillInfoType = .registration
        } else {
            Constants.currentDoctorFillInfoType = .editPofile
            self.SetUpForEditProfile()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if Constants.currentDoctorFillInfoType == .registration {
            self.viewTime.isHidden = false
            self.btnSideMenu.isHidden = true
        } else {
            self.btnSideMenu.isHidden = false
            self.viewTime.isHidden = true
            self.SetControllerContantMode()
        }
    }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // self.SetControllerContantMode() // cheking root so we can know user is registring or editing profile
            
        self.navigationItem.setHidesBackButton(true, animated: true)
        // Ask for Authorisation from the User.
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
        locationManager.startUpdatingLocation()
        
        mapView.isMyLocationEnabled = true
        mapView.settings.myLocationButton = true
        
        workingHrsStartTimeBtn.tag = 1
        workingHrsEndTimeBtn.tag = 2
        
        dropDown.anchorView = textViewGender
        dropDown.dataSource = Constants.GenderList.map { $0.name }
        dropDown.bottomOffset = CGPoint(x: 0, y:(dropDown.anchorView?.plainView.bounds.height)!)
        
        self.txtFielsPhone.text = DefaultsClass.shared.phoneNumber
        
    }
    
    private func SetUpForEditProfile() {
        let myColor = UIColor(named: "Commonwhiteandblack")
        for V in viewsTxtField {
            V.backgroundColor = myColor ?? .gray
        }
        textViewGender.backgroundColor = myColor ?? .gray
        btnSubmit.setTitle("Update", for: .normal)
        
        objDoctorRegister.GetDoctorDetail {[weak self] status, msg in
            if status{
                guard let self = self else {return}
                self.imgViewDoctor.kf.setImage(with: URL(string: self.objDoctorRegister.getPic()), placeholder: Constants.DoctorPlaceholderImage, options: nil, completionHandler: nil)
                
                self.txtFieldName.text! = self.objDoctorRegister.getName()
                self.txtFielsPhone.text = self.objDoctorRegister.getPhone()

                self.txtViewAddress.text! = self.objDoctorRegister.getAddress()
                self.txtViewPersonalInfo.text! = self.objDoctorRegister.getPersonalInfo()
                self.arrWorkingDays = self.objDoctorRegister.getWorkingDays()
                if let start = self.objDoctorRegister.getWorkingStartTime(){
                    self.startTimeStamp = start
                }
                if let end = self.objDoctorRegister.getWorkingEndTime(){
                    self.endTimeStamp = end
                }

                self.selectedGender = self.objDoctorRegister.getGender()
                self.arrSpecialization = self.objDoctorRegister.getSpecs()
                
//                if self.txtViewAddress.text! != "" || self.txtViewAddress.text! != "Address"{
//                    self.txtViewAddress.textColor = UIColor.black
//                }
//                if self.txtViewPersonalInfo.text! != "" || self.txtViewPersonalInfo.text! != "Personal Information"{
//                    self.txtViewPersonalInfo.textColor = UIColor.black
//                }
            }else{
                self?.showToast(message: msg)
            }
        }
    }
    //*************
    
    @IBAction func btnTapImage(_ sender: Any) {
        self.showActionSheet(control: ["Camera","Gallery"]) { title in
            if title == "Camera"{
                guard UIImagePickerController.isSourceTypeAvailable(.camera) else {return}
                self.imagePicker.sourceType = .camera
            }else{
                self.imagePicker.sourceType = .photoLibrary
            }
            self.imagePicker.delegate = self
            self.imagePicker.isEditing = true
            self.imagePicker.allowsEditing = true
            self.present(self.imagePicker, animated: true, completion: nil)
        }
    }
    
    @IBAction func didTapSpecialization(_ sender: UITextField) {
        self.view.endEditing(true)
        let vc = DoctorSpecilization.instantiateMain()
        vc.arrSelectedIds = arrSpecialization
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
        self.txtFieldDocSpecialization.resignFirstResponder()
    }
    
    @IBAction func didTapSelectDays(_ sender: Any) {
        self.view.endEditing(true)
// for profile update
        if self.navigationController?.viewControllers.count ?? 0 > 2, let _ = self.navigationController?.viewControllers[((self.navigationController?.viewControllers.count)!-2)] as? OTPViewController{
            let vc = WorkingDays.instantiateMain()
              vc.arrSelectedDays = arrWorkingDays
              vc.modalPresentationStyle = .overFullScreen
              self.present(vc, animated: true)
        } else {
            // for registration
            let vc = WorkingHoursViewController.instantiateMain()
            vc.updateRepsClosure = { [weak self] value in
                print(value)
                self?.mainDict.append(contentsOf: value)
            }
            vc.workingDetails = self.objDoctorRegister
            self.present(vc, animated: true)
                 
        }
    }
    
    @IBAction func timeSelection(_ sender: UIButton) {
        self.view.endEditing(true)
        let vc = TimePicker.instantiateMain()
        callerTimeLabelTag = sender.tag
        vc.modalPresentationStyle = .overFullScreen
        self.present(vc, animated: true)
    }
    
    @IBAction func didTapSelectGender(_ sender: UITextField) {
        self.view.endEditing(true)
        dropDown.show(onTopOf: nil, beforeTransform: nil, anchorPoint: nil)
        dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
           // sender.text = "\(item)"
            selectedGender = index + 1
            print(selectedGender)
        }
    }

    @IBAction func btnSubmit(_ sender: Any) {
       // guard self.validateAll() else {return}
        self.registerOrUpdateDoctor()
    }
    
}

//MARK: Data received from presented view controllers
extension DoctorRegistrationViewController{
    internal func selectedSpecialization(arr:[Int]){
        for uid in arr{
            if !self.arrSpecialization.contains(uid){
                self.arrSpecialization.append(uid)
            }
        }
    }
    internal func selectedWorkingDays(arr:[Int]){
        for uid in arr{
            if !self.arrWorkingDays.contains(uid){
                self.arrWorkingDays.append(uid)
            }
        }
    }
    internal func selectedTime(time:Date){
        if callerTimeLabelTag == 1 {
            self.startTimeStamp = time
        }else {
            self.endTimeStamp = time
        }
    }
    
    func convertJsonToJsonString(tempDict: [[String: Any]]) -> String {
            do {
                // Convert JSON object to JSON data
                let jsonData = try JSONSerialization.data(withJSONObject: tempDict, options: [])

                // Convert JSON data to JSON string
                return String(data: jsonData, encoding: .utf8) ?? ""
               
            } catch {
                print("Error: \(error)")
                return ""
            }
        }
}

extension DoctorRegistrationViewController{

    private func registerOrUpdateDoctor(){
        let stringArraySpec = arrSpecialization.map { String($0) }
        let stringSpec = stringArraySpec.joined(separator: ",")
        if Constants.currentDoctorFillInfoType == .registration {
            let param = ["name"           :txtFieldName.text!,
                         "specialization" :stringSpec,
                         "address"        :txtViewAddress.text!,
                         "lat"            :String(selectedLocation?.latitude ?? 0.0),
                         "lng"            :String(selectedLocation?.longitude ?? 0.0),
                         "personalInfo"   :txtViewPersonalInfo.text!,
                         "deviceToken"    :DefaultsClass.shared.APNS_Token,
                         "workingDays"    :arrWorkingDays,
                         "startTime"      :Constants.getTimeStamp(date: startTimeStamp).getInt().getString() ,
                         "endTime"        :Constants.getTimeStamp(date: endTimeStamp).getInt().getString() ,
                         "gender"         :String(selectedGender)] as [String : Any]
            
            print(param)
            
            self.showSpinner()
            objDoctorRegister.RegisterOrUpdateDoctor(param: param,image: ["image":self.imgViewDoctor.image!]){[weak self] Status, msg in
                self?.hideSpinner()
                if Status{
                    if Constants.currentDoctorFillInfoType == .registration{
                        Constants.currentDoctorFillInfoType = .editPofile
                        let vc = DocAppointmentsVC.instantiateMain()
                        self?.navigationController?.pushViewController(vc, animated: true)
                    } else {
                        self?.showToast(message: "")
                    }
                } else {
                    self?.showToast(message: msg)
                }
            }
        } else {
            
            let param: [String: Any] = [
                "name": txtFieldName.text!,
                "specialization": stringSpec,
                "address": txtViewAddress.text!,
                "lat": String(selectedLocation?.latitude ?? 0.0),
                "lng": String(selectedLocation?.longitude ?? 0.0),
                "personalInfo": txtViewPersonalInfo.text!,
                "deviceToken": DefaultsClass.shared.APNS_Token,
                "workingDays": convertJsonToJsonString(tempDict: mainDict),
                "gender": String(selectedGender)
            ]
            print(param)
            self.showSpinner()
            objDoctorRegister.RegisterOrUpdateDoctor(param: param, image: ["image": self.imgViewDoctor.image!]) { [weak self] Status, msg in
                self?.hideSpinner()
                if Status {
                        self?.showToast(message: "")
                    
                } else {
                    self?.showToast(message: msg)
                }
            }
        }
    }
}

// MARK: - CLLocationManagerDelegate
extension DoctorRegistrationViewController:CLLocationManagerDelegate,GMSMapViewDelegate{
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .notDetermined:
            print("wait for user's action")
        case .restricted:
            UIApplication.shared.open(URL(string:UIApplication.openSettingsURLString)!)
        case .denied:
            UIApplication.shared.open(URL(string:UIApplication.openSettingsURLString)!)
        case .authorizedAlways:
            locationManager.startUpdatingLocation()
        case .authorizedWhenInUse:
            locationManager.startUpdatingLocation()
        case .authorized:
            locationManager.startUpdatingLocation()
        @unknown default:
            fatalError()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else {
            return
        }
        self.selectedLocation = location.coordinate
        
        mapView.camera = GMSCameraPosition(target: location.coordinate, zoom: 20, bearing: 0, viewingAngle: 0)
        
        locationManager.stopUpdatingLocation()
    }
    
    func mapView(_ mapView: GMSMapView, didChange position: GMSCameraPosition) {
        let latitude = mapView.camera.target.latitude
        let longitude = mapView.camera.target.longitude
        centerMapCoordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        self.placeMarkerOnCenter(centerMapCoordinate:centerMapCoordinate)
    }
    
    func placeMarkerOnCenter(centerMapCoordinate:CLLocationCoordinate2D) {
        if centeredMarker == nil {
            centeredMarker = GMSMarker()
        }
        self.selectedLocation = centerMapCoordinate
        centeredMarker.position = centerMapCoordinate
        centeredMarker.map = self.mapView
    }
}

extension DoctorRegistrationViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.editedImage] as? UIImage else{
            return
        }
        self.imgViewDoctor.image = image
        self.dismiss(animated: true, completion: nil)
    }
}

//extension DoctorRegistrationViewController: UITextViewDelegate {
//    func textViewDidBeginEditing(_ textView: UITextView) {
//        if textView.textColor == UIColor.lightGray {
//               textView.text = nil
//               textView.textColor = UIColor.black
//           }
//    }
//    
//    func textViewDidEndEditing(_ textView: UITextView) {
//        if textView == txtViewAddress{
//            if textView.text.isEmpty {
//                textView.text = "Address"
//                textView.textColor = UIColor.lightGray
//            }
//        }else{
//            if textView.text.isEmpty {
//                textView.text = "Personal Information"
//                textView.textColor = UIColor.lightGray
//            }
//        }
//    }
//}

extension DoctorRegistrationViewController{
    func validateAll()->Bool{
        guard txtFieldName.text! != "" else{
            self.showToast(message: "Please enter name")
            return false
        }
        guard arrSpecialization.count != 0 else{
            self.showToast(message: "Please add specialization")
            return false
        }
        guard txtFieldGender.text! != "" else{
            self.showToast(message: "Please select your gender")
            return false
        }
        
        guard workingHrsStartTimeLabel.text! != "00:00 am" else{
            self.showToast(message: "Please select start time")
            return false
        }
        guard workingHrsEndTimeLabel.text! != "00:00 am" else{
            self.showToast(message: "Please select end time")
            return false
        }
        guard arrWorkingDays.count != 0 else{
            self.showToast(message: "Please select working days")
            return false
        }
        guard txtViewAddress.text! != "Address" else{
            self.showToast(message: "Please add address")
            return false
        }
        guard  txtViewAddress.text! != "" else{
            self.showToast(message: "Please add address")
            return false
        }
//        guard txtViewPersonalInfo.text! != "" else{
//            self.showToast(message: "msg")
//            return
//        }
        guard selectedLocation != nil else{
            self.showToast(message: "Please select your location on map")
            return false
        }
        
        return true
    }
}
