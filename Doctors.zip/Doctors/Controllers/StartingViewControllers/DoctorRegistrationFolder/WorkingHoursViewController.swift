//
//  WorkingHoursViewController.swift
//  Salon - merchant app
//
//  Created by mac on 07/09/20.
//  Copyright © 2020 Qualhon. All rights reserved.
//

import UIKit
import TTGSnackbar

protocol WorkingHoursProtocol {
    func setWorkingHoursList(parameters: [String: Any])
}

class WorkingHoursViewController: UIViewController {
    
    @IBOutlet weak var workingHoursTblView: UITableView!
    @IBOutlet weak var timePickerDialogView: UIView!
    @IBOutlet weak var startTimePicker: UIDatePicker!
    @IBOutlet weak var endTimePicker: UIDatePicker!
    
    var updateRepsClosure: (([[String: Any]]) -> Void)?
    var originalWorkingHours : [String] = ["10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM"]
    var originalBreakingHours : [String] = ["","","","","","",""]
    var originalIsDaySelected:[Bool] = [false, false, false, false, false, false, false]
    var selectedIndexpath: IndexPath?
    var selectedRowIndex = -1
    var selectedItem = 0
    var workingDetails : DoctorRegisterationViewModel?
    var showDefaultView = true
    var weekDaysFinal = [0, 0, 0, 0, 0, 0, 0]
    var breaks = [false,false,false,false,false,false,false]
    var isDaySelected:[Bool] = [false, false, false, false, false, false, false]
    var morningHours:[String] = ["10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM"]
    var morningHoursFinal:[String] = ["10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM"]
    var breakHours:[String] = ["2:00 PM - 3:00 PM","2:00 PM - 3:00 PM","2:00 PM - 3:00 PM","2:00 PM - 3:00 PM","2:00 PM - 3:00 PM","2:00 PM - 3:00 PM","2:00 PM - 3:00 PM"]
    var breakingHours:[String] = ["","","","","","",""]
    var expandedIndexPath = IndexPath()
    var tag = 0
    var selectedDate: Date = Date()
    var dateInMilliseconds : Int64 = 0
    let dateFormatter = DateFormatter()
    var morningLabelClick = false
    var mainDict = [[String: Any]]()
    var delegate: WorkingHoursProtocol?
    let blackColor = UIColor(named: "Commonwhiteandblack")
    let whiteColor = UIColor(named: "LabelColor")
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.workingHoursTblView.register(UINib(nibName: "RegistrationStep5TableCell2", bundle: nil), forCellReuseIdentifier: "RegistrationStep5TableCell2")
        self.dateFormatter.timeZone = .current
        let DefaultStatusBarHeight : CGFloat = UIApplication.shared.statusBarFrame.size.height
        self.dateFormatter.dateFormat = "h:mm a"
        self.expandedIndexPath = IndexPath(row: 1, section: 2)
        
        //self.startTimePicker.setValue(blackColor, forKeyPath: "textColor")
        //self.startTimePicker.backgroundColor = whiteColor
       // self.endTimePicker.backgroundColor = whiteColor
       // self.endTimePicker.setValue(blackColor, forKeyPath: "textColor")
        self.workingHoursTblView.reloadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setWorkingHoursData()
    }
    
    @objc  func click_selectCheckButton(_ sender: UIButton) {
        let indexPath = IndexPath(row: sender.tag, section: 0)
        let sectionCell = self.workingHoursTblView.cellForRow(at: indexPath) as! RegistrationStep5TableCell2
        
        if (sectionCell.checkButton.isSelected == true){
            sectionCell.checkButton.isSelected = false
            self.isDaySelected[sender.tag] = false
            self.breaks[sender.tag] = false
            self.morningHoursFinal[sender.tag] = ""
            self.breakingHours[sender.tag] = ""
        }
        else {
            sectionCell.checkButton.isSelected = true
            self.isDaySelected[sender.tag] = true
            self.morningHoursFinal[sender.tag] = "10:00 AM - 7:00 PM"
            self.breakingHours[sender.tag] = ""
        }
        self.workingHoursTblView.reloadData()
    }
    
    @IBAction func saveSelectedTimeAction(_ sender: Any) {
        self.view.endEditing(true)
        if(self.startTimePicker.date == self.endTimePicker.date){
            showSnackbar(message: "Minimum Time Difference should be 15 minuutes", isErrorMessage: true)
        } else if(self.startTimePicker.date > self.endTimePicker.date) {
            showSnackbar(message: "Start Time should be greater than end time", isErrorMessage: true)
        } else {
            self.timePickerDialogView.isHidden = true
            if(self.morningLabelClick == false) {
                let startDate = (self.breakHours[tag].strstr(needle: "-", beforeNeedle: true) ?? "").dropLast()
                self.endTimePicker.minimumDate = self.dateFormatter.date(from: String(startDate))
            }
            let startDateString = dateFormatter.string(from: self.startTimePicker.date)
            let endDateString = dateFormatter.string(from: self.endTimePicker.date)
            if self.morningLabelClick{
                self.morningHours[tag] = startDateString + " - " + endDateString
                self.morningHoursFinal[tag] = startDateString + " - " + endDateString
            } else {
                self.breakHours[tag] = startDateString + " - " + endDateString
                self.breakingHours[tag] = startDateString + " - " + endDateString
            }
            self.workingHoursTblView.reloadData()
        }
    }
    
    @IBAction func cancelSelectedTimeAction(_ sender: Any) {
        self.timePickerDialogView.isHidden = true
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveButtonTapped(_ sender: Any) {
        self.view.endEditing(true)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        
        if self.showDefaultView == true {
            for i in 0...6 {
                if self.isDaySelected[i] {
                    let startTimeString = (self.morningHoursFinal[i].strstr(needle: "-", beforeNeedle: true) ?? "").dropLast()
                    let endTimeString = (self.morningHoursFinal[i].strstr(needle: "-", beforeNeedle: false) ?? "").dropFirst()
                    let breakStartTimeString = (self.breakingHours[i].strstr(needle: "-", beforeNeedle: true) ?? "").dropLast()
                    let breakEndTimeString = (self.breakingHours[i].strstr(needle: "-", beforeNeedle: false) ?? "").dropFirst()
                    
                    guard let startTime = dateFormatter.date(from: String(startTimeString)),
                          let endTime = dateFormatter.date(from: String(endTimeString)),
                          let breakStartTime = dateFormatter.date(from: String(breakStartTimeString)),
                          let breakEndTime = dateFormatter.date(from: String(breakEndTimeString)) else {
                        // Handle date parsing error
                        return
                    }
                    
                    if self.breaks[i] && (breakStartTime > endTime || breakEndTime > endTime) {
                        showSnackbar(message: "Please select valid break time", isErrorMessage: true)
                        return
                    } else {
                        let shortDayName = Constants.EnumDays(rawValue: i+1)
                        let dict: [String: Any] = [
                            "day": Constants.EnumDays(rawValue: i+1)?.rawValue ?? 0,
                            "isOpen": 1,
                            "startTime": Int(startTime.timeIntervalSince1970) * 1000,
                            "endTime": Int(endTime.timeIntervalSince1970) * 1000,
                            "breakStartTime": Int(breakStartTime.timeIntervalSince1970) * 1000,
                            "breakEndTime": Int(breakEndTime.timeIntervalSince1970) * 1000,
                            "dayName":  Constants.EnumDays(rawValue: i+1)?.str ?? "",
                            "dayShortName": shortDayName?.str.prefix(3) ?? ""
                        ]
                        self.mainDict.append(dict)
                    }
                }
            }
        }
        
        // Call the closure with mainDict and dismiss
        self.updateRepsClosure?(mainDict)
        self.dismiss(animated: true)
    }
    
    @objc  func click_AddButton(_ sender: UIButton) {
        let indexPath = IndexPath(row: sender.tag, section: 0)
        self.expandedIndexPath = indexPath
        self.breaks[sender.tag] = true
        self.breakingHours[sender.tag] = "2:00 PM - 3:00 PM"
        self.breakHours[sender.tag] = "2:00 PM - 3:00 PM"
        self.workingHoursTblView.reloadRows(at: [indexPath], with: .none)
    }
    
    @objc  func click_CrossButton(_ sender: UIButton) {
        let indexPath = IndexPath(row: sender.tag, section: 0)
        self.expandedIndexPath = IndexPath()
        self.breaks[sender.tag] = false
        self.breakingHours[sender.tag] = ""
        self.workingHoursTblView.reloadRows(at: [indexPath], with: .none)
    }
    
    @IBAction func startTimeValueChanged(_ sender: Any) {
        self.endTimePicker.minimumDate = startTimePicker.date.addingTimeInterval(900)
    }
    
    @IBAction func endTimeValueChanged(_ sender: Any) {
        
    }
    func setWorkingHoursData() {
        
        self.breaks = [false,false,false,false,false,false,false]
        self.isDaySelected = [false, false, false, false, false, false, false]
        self.originalIsDaySelected = [false, false, false, false, false, false, false]
        self.morningHours = ["10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM"]
        self.morningHoursFinal = ["10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM"]
        self.originalWorkingHours = ["10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM","10:00 AM - 7:00 PM"]
        self.breakHours = ["2:00 PM - 3:00 PM","2:00 PM - 3:00 PM","2:00 PM - 3:00 PM","2:00 PM - 3:00 PM","2:00 PM - 3:00 PM","2:00 PM - 3:00 PM","2:00 PM - 3:00 PM"]
        self.weekDaysFinal = [0, 0, 0, 0, 0, 0, 0]
        self.breakingHours = ["","","","","","",""]
        self.originalBreakingHours = ["","","","","","",""]
        if let obj = self.workingDetails?.doctorDetail?.workingHours, obj.count >= 1 {
            for i in 0...obj.count - 1 {
                if self.showDefaultView == true {
                    for j in 0...self.isDaySelected.count - 1 {
                        if j+1 == obj[i].day && (obj[i].isOpen != 0) {
                            self.isDaySelected[j] = true
                            
                            self.originalIsDaySelected[j] = true
                            let morningTime = Double(obj[i].startTime ?? 0 / 1000).getDateStringFromUTC(format: "h:mm a")
                            let eveningTime = Double(obj[i].endTime ?? 0 / 1000).getDateStringFromUTC(format: "h:mm a")
                            let breakStart = Double(obj[i].breakStartTime ?? 0 / 1000).getDateStringFromUTC(format: "h:mm a")
                            let breakEnd = Double(obj[i].breakEndTime ?? 0 / 1000).getDateStringFromUTC(format: "h:mm a")
                            
                            if obj[i].breakEndTime == 0 {
                                self.breakHours[j] = "N/A"
                                self.breaks[j] = false
                                self.breakingHours[j] = ""
                                self.originalBreakingHours[j] = ""
                            } else {
                                self.breaks[j] = true
                                self.breakHours[j] = breakStart + " - " + breakEnd
                                self.breakingHours[j] = breakStart + " - " + breakEnd
                                self.originalBreakingHours[j] = breakStart + " - " + breakEnd
                            }
                            self.morningHours[j] = morningTime + " - " + eveningTime
                            self.morningHoursFinal[j] = morningTime + " - " + eveningTime
                            self.originalWorkingHours[j] = morningTime + " - " + eveningTime
                        }
                    }
                } else {
                    self.weekDaysFinal[i] = obj[i].day ?? 1
                    
                    if obj[i].isOpen == 1 {
                        self.isDaySelected[i] = true
                        self.originalIsDaySelected[i] = true
                    } else {
                        self.isDaySelected[i] = false
                        self.originalIsDaySelected[i] = false
                    }
                    
                    let morningTime = Double(obj[i].startTime ?? 0 / 1000).getDateStringFromUTC(format: "h:mm a")
                    let eveningTime = Double(obj[i].endTime ?? 0 / 1000).getDateStringFromUTC(format: "h:mm a")
                    let breakStart = Double(obj[i].breakStartTime ?? 0 / 1000).getDateStringFromUTC(format: "h:mm a")
                    let breakEnd = Double(obj[i].breakEndTime ?? 0 / 1000).getDateStringFromUTC(format: "h:mm a")
                    
                    if obj[i].breakEndTime == 0 {
                        self.breakHours[i] = "N/A"
                        self.breaks[i] = false
                        self.breakingHours[i] = ""
                        self.originalBreakingHours[i] = ""
                    } else {
                        self.breaks[i] = true
                        self.breakHours[i] = breakStart + " - " + breakEnd
                        self.breakingHours[i] = breakStart + " - " + breakEnd
                        self.originalBreakingHours[i] = breakStart + " - " + breakEnd
                    }
                    if obj[i].startTime! > 0 {
                        self.morningHours[i] = morningTime + " - " + eveningTime
                        self.morningHoursFinal[i] = morningTime + " - " + eveningTime
                        self.originalWorkingHours[i] = morningTime + " - " + eveningTime
                    } else {
                        self.morningHours[i] = "10:00 AM - 7:00 PM"
                        self.morningHoursFinal[i] = "10:00 AM - 7:00 PM"
                        self.originalWorkingHours[i] = "10:00 AM - 7:00 PM"
                    }
                    
                }
                
            }
        }
        self.workingHoursTblView.reloadData()
    }
    
    @objc  func morningTimeButton(_ sender: UIButton) {
        self.view.endEditing(true)
        self.startTimePicker.minimumDate = nil
        self.startTimePicker.maximumDate = nil
        self.tag = sender.tag
        self.morningLabelClick = true
        let startDate = (morningHours[tag].strstr(needle: "-", beforeNeedle: true) ?? "").dropLast()
        self.startTimePicker.date = dateFormatter.date(from: String(startDate)) ?? Date()
        self.endTimePicker.minimumDate = startTimePicker.date.addingTimeInterval(900)
        let endDate = (morningHours[tag].strstr(needle: "-", beforeNeedle: false) ?? "").dropFirst()
        self.endTimePicker.date = dateFormatter.date(from: String(endDate)) ?? Date()
        self.timePickerDialogView.isHidden = false
        self.startTimePicker.reloadInputViews()
        self.endTimePicker.reloadInputViews()
    }
    
    @objc  func eveningTimeButton(_ sender: UIButton) {
        self.view.endEditing(true)
        self.morningLabelClick = false
        self.tag = sender.tag
        let startDate = (breakHours[tag].strstr(needle: "-", beforeNeedle: true) ?? "").dropLast()
        let min = (morningHours[tag].strstr(needle: "-", beforeNeedle: true) ?? "").dropLast()
        self.startTimePicker.minimumDate = dateFormatter.date(from: String(min))?.addingTimeInterval(900)
        let max = (morningHours[tag].strstr(needle: "-", beforeNeedle: false) ?? "").dropFirst()
        self.endTimePicker.maximumDate = dateFormatter.date(from: String(max))?.addingTimeInterval(-900)
        let endDate = (breakHours[tag].strstr(needle: "-", beforeNeedle: false) ?? "").dropFirst()
        self.startTimePicker.maximumDate = dateFormatter.date(from: String(max))?.addingTimeInterval(-900)
        self.endTimePicker.minimumDate = dateFormatter.date(from: String(min))?.addingTimeInterval(900) ?? Date()
        self.endTimePicker.date = dateFormatter.date(from: String(endDate)) ?? Date()
        self.startTimePicker.date = dateFormatter.date(from: String(startDate)) ?? Date()
        self.timePickerDialogView.isHidden = false
        self.startTimePicker.reloadInputViews()
        self.endTimePicker.reloadInputViews()
    }
    
}

extension WorkingHoursViewController:UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "RegistrationStep5TableCell2", for: indexPath) as? RegistrationStep5TableCell2 else {
            return UITableViewCell()
        }
        if self.showDefaultView == true {
            cell.weekDayLabel.text = Constants.EnumDays(rawValue: indexPath.row+1)?.str
        } else {
            cell.weekDayLabel.text = Double(weekDaysFinal[indexPath.row] / 1000).getDateStringFromUTC(format: "EEE, dd MMM, YYYY")
        }
        cell.addButton.tag = indexPath.row
        cell.morningTimeLabel.text = morningHours[indexPath.row]
        cell.eveningTimeLabel.text = breakHours[indexPath.row]
        cell.addButton.addTarget(self, action: #selector(click_AddButton(_:)), for: .touchUpInside)
        cell.crossButton.tag = indexPath.row
        cell.checkBox2.tag = indexPath.row
        cell.crossButton.addTarget(self, action: #selector(click_CrossButton(_:)), for: .touchUpInside)
        cell.morningTimeButton.tag = indexPath.row
        cell.eveningTimeButton.tag = indexPath.row
        cell.eveningTimeButton.addTarget(self, action: #selector(eveningTimeButton(_:)), for: .touchUpInside)
        cell.morningTimeButton.addTarget(self, action: #selector(morningTimeButton(_:)), for: .touchUpInside)
        cell.checkBox2.tag = indexPath.row
        cell.checkBox2.addTarget(self, action: #selector(click_selectCheckButton(_:)), for: .touchUpInside)
        
        if self.breaks[indexPath.row] == true {
            cell.breakView.isHidden = false
            cell.addButton.isHidden = true
        }else {
            cell.addButton.isHidden = false
            cell.breakView.isHidden = true
        }
        
        if self.isDaySelected[indexPath.row] {
            cell.checkButton.setImage( #imageLiteral(resourceName: "check_purple"), for: .normal)
           // cell.morningTimeLabel.textColor = blackColor
           // cell.weekDayLabel.textColor = blackColor
            cell.addButton.isUserInteractionEnabled = true
        }else{
            cell.checkButton.setImage( #imageLiteral(resourceName: "checkbox"), for: .normal)
            //cell.morningTimeLabel.textColor = blackColor
           // cell.weekDayLabel.textColor = blackColor
            cell.addButton.isUserInteractionEnabled = false
        }
        
        return cell
    }
}
