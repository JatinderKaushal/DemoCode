//
//  RegistrationStep5TableCell2.swift
//  Salon - merchant app
//
//  Created by mac on 09/12/20.
//  Copyright © 2020 Qualhon. All rights reserved.
//

import UIKit

class RegistrationStep5TableCell2: UITableViewCell {

    @IBOutlet weak var checkButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var crossButton: UIButton!
    @IBOutlet weak var eveningTimeLabel: UILabel!
    @IBOutlet weak var weekDayLabel: UILabel!
    @IBOutlet weak var morningTimeLabel: UILabel!
    @IBOutlet weak var morningTimeButton: UIButton!
    @IBOutlet weak var eveningTimeButton: UIButton!
    @IBOutlet weak var checkBox2: UIButton!
    @IBOutlet weak var breakView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
