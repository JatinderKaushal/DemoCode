//
//  DoctorSpecilization.swift
//  Doctors
//
//  Created by Mandeep Singh on 08/06/22.
//

import UIKit

class DoctorSpecilization: UIViewController {
    
    @IBOutlet weak var clcSpecilization: UICollectionView!
    private let objDocSpec = DoctorSpecilizationViewModel()
    internal var arrSelectedIds = [Int]()
    
    override func viewDidLoad() {
        self.clcSpecilization.delegate = self
        self.clcSpecilization.dataSource = self
        self.hitApiGetSpec()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidLoad()
        self.view.presentOpacityAnimation()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.view.backgroundColor = .clear
    }
    
    @IBAction func btnCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnSave(_ sender: Any) {
        print("Save button clicked")
        if let vc = (self.presentingViewController as? UINavigationController)?.viewControllers.last as? DoctorRegistrationViewController{
            vc.selectedSpecialization(arr: arrSelectedIds)
        } else if let vc = ((self.presentingViewController as? UINavigationController)?.viewControllers.last?.children.last as? UINavigationController)?.viewControllers.last as? DoctorRegistrationViewController{
            vc.selectedSpecialization(arr: arrSelectedIds)
        } else {
            print("================hiraricy problem ====================")
        }
        self.dismiss(animated: true, completion: nil)
    }
}

// MARK: - Hit Api for Doctor Specialization
extension DoctorSpecilization {
    
    private func hitApiGetSpec() {
        self.showSpinner()
        self.objDocSpec.GetSpecilization {[weak self] (status, msg) in
            self?.hideSpinner()
            if status {
                self?.clcSpecilization.reloadData()
            } else {
                self?.showToast(message: msg)
            }
        }
    }
}

//MARK: - CollectionView Delegate, CollectionView DataSource
extension DoctorSpecilization:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.objDocSpec.count()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.clcSpecilization.dequeueReusableCell(withReuseIdentifier: "cellid", for: indexPath) as! SpecializaationClcCell
        if self.arrSelectedIds.contains(self.objDocSpec.getId(index: indexPath.item)){
            cell.imgSelect.image = UIImage(named: "blank-check-box2")
        } else {
            cell.imgSelect.image = UIImage(named: "blank-check-box")
        }
        let strCap = self.objDocSpec.getTitle(index: indexPath.item).capitalized
        cell.lblTitle.text = strCap
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let id = self.objDocSpec.getId(index: indexPath.item)
        if let index = self.arrSelectedIds.firstIndex(of:id ){
            self.arrSelectedIds.remove(at: index)
        } else {
            self.arrSelectedIds.append(id)
        }
        self.clcSpecilization.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.clcSpecilization.frame.width/2, height: self.clcSpecilization.frame.height/7.0)
    }
}

class SpecializaationClcCell:UICollectionViewCell {
    @IBOutlet weak var imgSelect: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
}
