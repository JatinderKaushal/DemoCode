//
//  DoctorRegisterationViewModel.swift
//  Doctors
//
//  Created by Mandeep Singh on 07/06/22.
//

import Foundation
import DropDown
import SwiftUI

// MARK: - DoctorSpecialization
struct DoctorRegisterModel: Codable {
    let message: String?
}

class DoctorRegisterationViewModel {
    internal func RegisterOrUpdateDoctor(param: [String:Any],image:[String:UIImage], completion:@escaping(Bool,String)->()) {
        let endpoint = Constants.currentDoctorFillInfoType == .registration ? Api.doctorRegister : Api.doctorProfileUpdate
        var method: String?
        if Constants.currentDoctorFillInfoType == .registration {
            method = "POST"
            HitApi.shared.uploadImages(api: endpoint, parameters: param, images: image, method: method ?? "POST") { (result:Result<OTPValidateModel,Error>) in
                switch result{
                case .success(let model):
                    if let data = model.message {
                        if data == "Success" {
                            DefaultsClass.shared.name = model.response?.name ?? ""
                            DefaultsClass.shared.profilePic = model.response?.image ?? ""
                            DefaultsClass.shared.id = (model.response?.id!)!
                            completion(true, model.message ?? Constants.defaultServerMessage)
                        }else{
                            completion(false, model.message ?? Constants.defaultServerMessage)
                        }
                    }
                    break
                    
                case.failure(let error):
                    completion(false ,error.localizedDescription)
                    break;
                }
            }
        } else {
            method = "PUT"
            HitApi.shared.uploadImages(api: endpoint, parameters: param, images: image, method: method ?? "POST") { (result:Result<UpdateProfileModel,Error>) in
                switch result{
                case .success(let model):
                    if let data = model.message {
                        if data == "Success" {
                            DefaultsClass.shared.name = model.data?.name ?? ""
                            DefaultsClass.shared.profilePic = model.data?.image ?? ""
                            DefaultsClass.shared.id = (model.data?.id!)!
                            completion(true, model.message ?? Constants.defaultServerMessage)
                        }else{
                            completion(false, model.message ?? Constants.defaultServerMessage)
                        }
                    }
                    break
                    
                case.failure(let error):
                    completion(false ,error.localizedDescription)
                    break;
                }
            }
        }
        
    }
    
    var doctorDetail : DocResponse?
    
    internal func GetDoctorDetail(completion:@escaping(Bool,String)->()){
        
        HitApi.shared.sendRequest(endPoint: Api.getDoctorProfile) { (result:Result<DocDetailModel,Error>) in
            switch result{
            case .success(let model):
                if model.message == "Success"{
                    self.doctorDetail = model.response
                    completion(true ,model.message ?? Constants.defaultServerMessage)
                }else{
                    completion(false ,model.message ?? Constants.defaultServerMessage)
                }
                break;
                
            case.failure(let error):
                completion(false ,error.localizedDescription)
                break;
            }
        }
    }
    internal func getPic()->String{
        return Api.imageUrl(endpoint: doctorDetail?.image ?? "")
    }
    internal func getName()->String{
        return doctorDetail?.name ?? ""
    }
    internal func getPhone()->String{
        return doctorDetail?.phone ?? ""
    }
    internal func getAddress()->String{
        return doctorDetail?.address ?? ""
    }
    internal func getPersonalInfo()->String{
        return doctorDetail?.personalInfo ?? ""
    }
    internal func getGender()->Int{
        return doctorDetail?.gender ?? 0
    }
    internal func getSpecs()->[Int]{
        var arr = [Int]()
        for model in doctorDetail?.specialization ?? []{
            if let id = model.id{
                arr.append(id)
            }
        }
        return arr
    }
    internal func getWorkingDays()->[Int]{
        var arr = [Int]()
        for model in doctorDetail?.workingHours ?? []{
            if (model.isOpen ?? 0) == 1{
                if let day = model.day{
                    arr.append(day)
                }
            }
        }
        return arr
    }
    
    internal func getWorkingStartTime()->Date?{
        if let timeStamp = doctorDetail?.workingHours?.first?.startTime{
            return timeStamp.convertToDate(format: .hh_mm_a)
        }
        return nil
    }
    internal func getWorkingEndTime()->Date?{
        if let timeStamp = doctorDetail?.workingHours?.first?.endTime{
            return timeStamp.convertToDate(format: .hh_mm_a)
        }
        return nil
    }
}


// MARK: - Welcome
struct DocDetailModel: Codable {
    let message: String?
    let response: DocResponse?
}

// MARK: - Response
struct DocResponse: Codable {
    let id, gender: Int?
    let name, image: String?
    let status: Int
    let email: String?
    let personalInfo, phone, address: String?
    let lat, lng: Double?
    let distance: Double?
    let specialization: [DocSpecialization]?
    let workingHours: [DocWorkingHour]?
}

// MARK: - Specialization
struct DocSpecialization: Codable {
    let dsID, id: Int?
    let category, image: String?
}

// MARK: - WorkingHour
struct DocWorkingHour: Codable {
    let day, isOpen, startTime, endTime: Int?
    let breakStartTime, breakEndTime: Int?
    let dayName, dayShortName: String?
}


// MARK: - DoctorSpecialization
struct DoctorSpecialization: Codable {
    let message: String?
    let response: [DoctorSpecializationResponse]
}

// MARK: - DoctorSpecializationResponse
struct DoctorSpecializationResponse: Codable {
    let id: Int?
    let category: String?
    let image: String?
}

class DoctorSpecilizationViewModel {
    private var arrSpec : [DoctorSpecializationResponse]?
    
    internal func GetSpecilization(completion:@escaping(Bool,String)->()){
        HitApi.shared.sendRequest(endPoint: Api.doctorSpecialization) { (result:Result<DoctorSpecialization,Error>) in
            switch result{
            case .success(let model):
                if model.message == "Success"{
                    self.arrSpec = model.response
                    completion(true ,model.message ?? Constants.defaultServerMessage)
                }else{
                    completion(false ,model.message ?? Constants.defaultServerMessage)
                }
                break;
                
            case.failure(let error):
                completion(false ,error.localizedDescription)
                break;
            }
        }
    }
    
    internal func count()->Int{
        return arrSpec?.count ?? 0
    }
    
    internal func getTitle(index:Int)->String{
        return arrSpec?[index].category ?? ""
    }
    
    internal func getId(index:Int)->Int{
        return arrSpec?[index].id ?? 0
    }
}
