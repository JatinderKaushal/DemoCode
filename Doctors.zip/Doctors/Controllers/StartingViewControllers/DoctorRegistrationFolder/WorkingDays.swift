//
//  WorkingDays.swift
//  Doctors
//
//  Created by iOS on 26/05/22.
//

import UIKit

class WorkingDays: UIViewController {

    @IBOutlet weak var clcWorkingDays: UICollectionView!
    internal var arrSelectedDays = [Int]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.clcWorkingDays.delegate = self
        self.clcWorkingDays.dataSource = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.view.backgroundColor = .clear
    }
    
    @IBAction func btnCancel(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    @IBAction func btnSave(_ sender: Any) {
        
        if let vc = (self.presentingViewController as? UINavigationController)?.viewControllers.last as? DoctorRegistrationViewController{
            vc.selectedWorkingDays(arr:arrSelectedDays)
        } else if let vc = ((self.presentingViewController as? UINavigationController)?.viewControllers.last?.children.last as? UINavigationController)?.viewControllers.last as? DoctorRegistrationViewController{
            vc.selectedWorkingDays(arr:arrSelectedDays)
        } else {
            print("================hiraricy problem ====================")
        }
        self.dismiss(animated: true, completion: nil)
    }
}

extension WorkingDays: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return Constants.DaysList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = clcWorkingDays.dequeueReusableCell(withReuseIdentifier: "cellid", for: indexPath) as? SpecializaationClcCell else {
            return UICollectionViewCell()
        }
        cell.lblTitle.text = Constants.DaysList[indexPath.item].name
        
        if arrSelectedDays.contains(Constants.DaysList[indexPath.item].value) {
            cell.imgSelect.image = UIImage(named: "blank-check-box2")
        } else {
            cell.imgSelect.image = UIImage(named: "blank-check-box")
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let day = Constants.DaysList[indexPath.item].value
        if let index = self.arrSelectedDays.firstIndex(of:day ){
            self.arrSelectedDays.remove(at: index)
        }else{
            self.arrSelectedDays.append(day)
        }
        self.clcWorkingDays.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: clcWorkingDays.frame.width, height: self.clcWorkingDays.frame.height/7.0)
    }
}
