//
//  TimePicker.swift
//  Doctors
//
//  Created by iOS on 17/05/22.
//

import UIKit

class TimePicker: UIViewController {
    
    @IBOutlet weak var timePicker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.view.backgroundColor = .clear
    }
    
    @IBAction func btnCancel(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnSave(_ sender: Any) {
        if let vc = (self.presentingViewController as? UINavigationController)?.viewControllers.last as? DoctorRegistrationViewController{
            vc.selectedTime(time: timePicker.date)
        }else if let vc = ((self.presentingViewController as? UINavigationController)?.viewControllers.last?.children.last as? UINavigationController)?.viewControllers.last as? DoctorRegistrationViewController{
            vc.selectedTime(time: timePicker.date)
        } else {
            print("================hiraricy problem ====================")
        }
        self.dismiss(animated: true, completion: nil)
    }
}

