//
//  Extensions.swift
//  Doctors
//
//  Created by Mandeep Singh on 06/06/22.
//

import Foundation
import UIKit
import Photos


import Moya

extension UITextField {
    func setRightEyesIcon() {
        let rightView = UIView(frame: CGRect(x: 0, y: 0, width: self.frame.height, height: self.frame.height))
        
        let btnEye = UIButton(frame: rightView.bounds)
        btnEye.setImage(UIImage(systemName: "eye"), for: .normal)
        btnEye.setImage(UIImage(systemName: "eye.slash"), for: .selected)
        
        btnEye.tintColor = AppColors.appThemeColor
        btnEye.addTarget(self, action: #selector(toggleEye), for: .touchUpInside)
        
        rightView.addSubview(btnEye)
        
        self.rightView = rightView
        self.isSecureTextEntry = true
        self.rightViewMode = .always
    }
    
    @objc private func toggleEye(sender: UIButton) {
        if sender.isSelected {
            self.isSecureTextEntry = true
            sender.isSelected = false
        } else {
            self.isSecureTextEntry = false
            sender.isSelected = true
        }
    }
    
    func setLeftViewIcon(icon: UIImage, height: Double = 10.0) {
        let leftView = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: self.frame.height))
        
        // Icon
        let imageView = UIImageView(image: icon)
        imageView.frame = CGRect(x: 2.5, y: 0, width: 35, height: leftView.frame.height)
        imageView.contentMode = .center
        leftView.addSubview(imageView)
        
        // Line Separator
        let separatorHeight = leftView.frame.height - 8 // 2px top and bottom space
        let lineView = UIView(frame: CGRect(x: (imageView.frame.width + 2), y: 4, width: 1, height: separatorHeight))
        lineView.backgroundColor = UIColor.gray // Change color as needed
        leftView.addSubview(lineView)
        self.leftView = leftView
        self.leftViewMode = .always
        self.layer.cornerRadius = 22
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.gray.cgColor
    }

    func setRightViewIcon(icon: UIImage, height: Double = 10.0) {
//        self.layer.borderWidth = 1
//        self.layer.borderColor = UIColor.gray.cgColor
        self.layer.cornerRadius = 18
        let leftView = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: self.frame.height))
        
        // Icon
        let imageView = UIImageView(image: icon)
        imageView.frame = CGRect(x: 0, y: 0, width: 35, height: leftView.frame.height)
        imageView.contentMode = .right
        leftView.addSubview(imageView)
        self.rightView = leftView
        self.rightViewMode = .always
//        self.layer.cornerRadius = 22
       // self.layer.borderWidth = 1
    }
    
    func setLeftView(height: Double = 10.0, color: UIColor) {
        
        let leftView = UIView(frame: CGRect(x: 0, y: 0, width: 35, height: self.frame.height))
        let width: CGFloat = 20
        let y: CGFloat = CGFloat(leftView.frame.height/2 - (width - 5)/2)
        let viewPriority = UIView(frame: CGRect(x: 10, y: y, width: width-5, height: width-5))
        viewPriority.contentMode = .center
        viewPriority.layer.cornerRadius = 7.5
        viewPriority.backgroundColor = color
        leftView.addSubview(viewPriority)
        self.leftView = leftView
        self.leftViewMode = .always
    }
    
    func styleTextField() {
    
        self.layer.cornerRadius = 8

        // Create a view with the desired right padding
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: self.frame.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }

    
}
enum RightIcons {
    
    case email
    case password
    case secureKey
    var image: UIImage? {
        switch self {
        case .email:
            return UIImage(named: "email")
        case .password:
            return UIImage(named: "password")
        case .secureKey:
            return UIImage(named: "email")
        }
    }
}

extension String {
    public init(deviceToken: Data) {
        self = deviceToken.map { String(format: "%.2hhx", $0) }.joined()
    }
    //phone validation
    func myMobileNumberValidate() -> Bool {
        let numberRegEx = "[0-9]{10}"
        let numberTest = NSPredicate(format: "SELF MATCHES %@", numberRegEx)
        if numberTest.evaluate(with: self) == true {
            return true
        }
        else {
            return false
        }
    }
    
    var isBackspace: Bool {
      let char = self.cString(using: String.Encoding.utf8)!
      return strcmp(char, "\\b") == -92
    }
        
    func capitalizingFirstLetter() -> String {
         return prefix(1).uppercased() + self.lowercased().dropFirst()
       }
       mutating func capFirst() {
         self = self.capitalizingFirstLetter()
       }
    
}
extension UIView{
    func presentOpacityAnimation(duration: TimeInterval = 0.2, opacity: CGFloat = 0.5) {
        self.backgroundColor = .clear
          DispatchQueue.main.async {
              UIView.animate(withDuration: duration, delay: 0.0, options: [UIView.AnimationOptions.curveEaseIn], animations: {
                  self.backgroundColor = UIColor.black.withAlphaComponent(opacity)
              }) { (finished) in
               }
          }
       }
    
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
            let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
            let mask = CAShapeLayer()
            mask.path = path.cgPath
            layer.mask = mask
        }
}


extension UIViewController {
    class func instantiatePatient() -> Self{
        return patientStoryBoard()
    }
    
    class func patientStoryBoard<T>() -> T {
        return UIStoryboard(name: "PatientsModule", bundle: nil).instantiateViewController(withIdentifier: String(describing: T.self)) as! T
    }
    class func instantiateMain() -> Self{
        return storyBoarded()
    }
    
    class func storyBoarded<T>() -> T {
        return UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: String(describing: T.self)) as! T
    }
    
    func showAlert( title: String = "", message: String="", control:[String] = ["Ok"], completion:@escaping (String)->()) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        for str in control{
            let alertAction = UIAlertAction(title: str, style: .default, handler: { (action) in
                completion(str)
            })
            alert.addAction(alertAction)
        }
        self.present(alert, animated: true, completion: nil)
    }
    
    func showActionSheet( title: String = "", message: String="", control:[String], completion:@escaping (String)->()) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        for str in control{
            let alertAction = UIAlertAction(title: str, style: .default, handler: { (action) in
                completion(str)
            })
            alert.addAction(alertAction)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { (action) in })
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func showToast(message : String, font: UIFont = UIFont.systemFont(ofSize: 12)) {
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 115, y: self.view.frame.size.height-55, width: 250, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.font = font
        toastLabel.textAlignment = .center;
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 1.0, delay: 1.5, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }
    
    func present(_ viewControllerToPresent: UIViewController) {
        let transition = CATransition()
        transition.duration = 0.5
        transition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromLeft
        self.view.window!.layer.add(transition, forKey: nil)
        present(viewControllerToPresent, animated: false)
     }

     func dismiss() {
         let transition = CATransition()
         transition.duration = 0.5
         transition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
         transition.type = CATransitionType.push
         transition.subtype = CATransitionSubtype.fromRight
         self.view.window!.layer.add(transition, forKey: nil)
         self.dismiss(animated: false, completion: nil)
     }
}

extension UIApplication {
   
    class func topViewController(controller: UIViewController? = UIApplication.shared.windows.first?.rootViewController) -> UIViewController? {
       
        if let navigationController = controller as? UINavigationController {
            return topViewController(controller: navigationController.visibleViewController)
        }
        if let tabController = controller as? UITabBarController {
            if let selected = tabController.selectedViewController {
                return topViewController(controller: selected)
            }
        }
        if let presented = controller?.presentedViewController {
            return topViewController(controller: presented)
        }
        return controller
    
    }
}

public extension UINavigationController {

    func push(viewController vc: UIViewController, transitionType type: CATransitionType = .push, duration: CFTimeInterval = 0.6) {
        self.addTransition(transitionType: type, subType: .fromRight, duration: duration)
        self.pushViewController(vc, animated: false)
    }
    func pop(transitionType type: CATransitionType = .push, duration: CFTimeInterval = 0.6) {
        self.addTransition(transitionType: type, subType: .fromLeft, duration: duration)
        self.popViewController(animated: false)
    }
    func popToRoot(transitionType type: CATransitionType = .moveIn, duration: CFTimeInterval = 0.6) {
        self.addTransition(transitionType: type, subType: .fromLeft, duration: duration)
        self.popToRootViewController(animated: false)
    }
    private func addTransition(transitionType type: CATransitionType,subType: CATransitionSubtype, duration: CFTimeInterval) {
        let transition = CATransition()
        transition.duration = duration
        transition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.default)
        transition.type = type
        transition.subtype = subType
        self.view.layer.add(transition, forKey: nil)
    }
}

extension UIImage {
    func imageWithColor(color: UIColor) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)
        color.setFill()

        let context = UIGraphicsGetCurrentContext()
        context?.translateBy(x: 0, y: self.size.height)
        context?.scaleBy(x: 1.0, y: -1.0)
        context?.setBlendMode(CGBlendMode.normal)

        let rect = CGRect(origin: .zero, size: CGSize(width: self.size.width, height: self.size.height))
        context?.clip(to: rect, mask: self.cgImage!)
        context?.fill(rect)

        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage!
    }
}

extension Double{
    func getString()->String{
        return String(self)
    }
    func getInt()->Int{
        return Int(self)
    }
}

extension Int{
    func getString()->String{
        return String(self)
    }
    func getDouble()->Double{
        return Double(self)
    }
}
extension String{
    func getString()->String{
        return String(self)
    }
    func getDoubles()->Double{
        return Double(self) ?? 0
    }
}
