//
//  ApiHandler.swift
//  Doctors
//
//  Created by Mandeep Singh on 06/06/22.
//


import Foundation
import UIKit
import SystemConfiguration

class HitApi {
   
   private init() {}
   static let shared = HitApi()
   
   func sendRequest<T: Decodable>(endPoint: String,withBase: Bool=true, parameters: [String: Any]? = nil,outputBlock: @escaping (Result<T, Error>) -> ()) {
       if !isConnectedToNetwork() {
           outputBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.internetProblem.Message])))
           return
       }
       var strUrl = ""
       if withBase{
           strUrl = Api.BaseUrl + endPoint
       }else{
           strUrl = endPoint
       }
       guard let url = URL(string: (strUrl).replacingOccurrences(of: " ", with: "%20")) else {
            outputBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.badUrl.Message])))
           return
       }
       
       var request = URLRequest(url: url)
       
       if let token = DefaultsClass.shared.accessToken {
           request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
       }
     
       request.setValue("application/json", forHTTPHeaderField: "Accept")
   
       if let parameters = parameters {
           print("parameters are :", parameters)
           request.httpMethod = "POST"
           var output = ""
           for (key,value) in parameters {
               output += "\(key)=\(value)&"
           }
           output.removeLast()
           request.httpBody = output.data(using: .utf8)
       }
       
       self.sessionHitWith(request: request, url: url.absoluteString) { (result: Result<T, Error>) in
           outputBlock(result)
       }
   }
   

   
    func uploadImages<T: Decodable>(api: String, parameters:[String: Any]? = nil, images: [String: UIImage]? = nil, method: String, outBlock: @escaping (Result<T, Error>) -> Void) {
       if !isConnectedToNetwork() {
           outBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.internetProblem.Message])))
           return
       }
       guard let url = URL(string: (Api.BaseUrl + api).replacingOccurrences(of: " ", with: "%20")) else {
           outBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.badUrl.Message])))
           return
       }
     
       var request = URLRequest(url: url)
       request.httpMethod = method
       let boundary = "Boundary-\(UUID().uuidString)"
       if let token = DefaultsClass.shared.accessToken {
           request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
       }
       request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
       request.setValue("application/json", forHTTPHeaderField: "Accept")
       let lineBreak = "\r\n"
       var body = Data()
       
       if let parameters = parameters {
           for (key, value) in parameters {
               body.append("--\(boundary + lineBreak)")
               body.append("Content-Disposition: form-data; name=\"\(key)\"\(lineBreak + lineBreak)")
               body.append("\(value)" + lineBreak)
           }
       }
       if let images = images{
           for (key, value) in images {
               if var imageData = value.pngData() {
                   let size = Double(imageData.count)/1024
                   if size > 500 {
                       imageData = compressImage(image: value, fileSizeKb: Int(size)) ?? imageData
                   }
                   body.append("--\(boundary + lineBreak)")
                   body.append("Content-Disposition: form-data; name=\"\(key)\"; filename=\"\(key).jpg\"\(lineBreak)")
                   body.append("Content-Type: \("image/jpeg" + lineBreak + lineBreak)")
                   body.append(imageData)
                   body.append(lineBreak)
                   body.append("--\(boundary)--\(lineBreak)")
               }
           }
       }
    
       request.httpBody = body
       self.sessionHitWith(request: request, url: url.absoluteString) { (result: Result<T, Error>) in
           outBlock(result)
       }
   }
   
   func uploadVideo<T: Decodable>(api: String, parameters: [String: Any]? = nil, video: [String: Data], outBlock: @escaping (Result<T, Error>) -> Void) {
       if !isConnectedToNetwork() {
           outBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.internetProblem.Message])))
           return
       }
       guard let url = URL(string: (Api.BaseUrl + api).replacingOccurrences(of: " ", with: "%20")) else {
           outBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.badUrl.Message])))
           return
       }

       var request = URLRequest(url: url)
       request.httpMethod = "POST"
       let boundary = "Boundary-\(UUID().uuidString)"
       request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
       request.setValue("application/json", forHTTPHeaderField: "Accept")
       let lineBreak = "\r\n"
       var body = Data()
       
       if let parameters = parameters {
           for (key, value) in parameters {
               body.append("--\(boundary + lineBreak)")
               body.append("Content-Disposition: form-data; name=\"\(key)\"\(lineBreak + lineBreak)")
               body.append("\(value)" + lineBreak)
           }
       }
       
       for (name, videoData) in video {
               body.append("--\(boundary + lineBreak)")
               body.append("Content-Disposition: form-data; name=\"\(name)\"; filename=\"\(name).mov\"\(lineBreak)")
               body.append("Content-Type: \("application/octet-stream" + lineBreak + lineBreak)")
               body.append(videoData)
               body.append(lineBreak)
               body.append("--\(boundary)--\(lineBreak)")
       }
       request.httpBody = body
       self.sessionHitWith(request: request, url: url.absoluteString) { (result: Result<T, Error>) in
           outBlock(result)
       }
   }
   
   func sendRequestWithBody<T: Decodable>(api: String, body: Data?, outputBlock: @escaping (Result<T, Error>) -> ()) {
       print("hitting:" , api)
       if !isConnectedToNetwork(){
            outputBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.internetProblem.Message])))
           return
       }
       
       guard let url = URL(string: api) else {
            outputBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.badUrl.Message])))
           return
       }
       var request = URLRequest(url: url)
  
       if let data = body {
           request.httpMethod = "POST"
           request.setValue("application/json", forHTTPHeaderField: "Content-Type")
           request.httpBody = data
       }
       self.sessionHitWith(request: request, url: url.absoluteString) { (obj: Result<T, Error>) in
           outputBlock(obj)
       }
   }
    func putRequestWithAuthentication<T: Decodable>(api: String, body: Data?, outputBlock: @escaping (Result<T, Error>) -> ()) {
        print("hitting:", api)
        if !isConnectedToNetwork() {
            outputBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.internetProblem.Message])))
            return
        }
        
        guard let url = URL(string: api) else {
            outputBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.badUrl.Message])))
            return
        }
        var request = URLRequest(url: url)
        if let token = DefaultsClass.shared.accessToken {
            request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        }
        request.httpMethod = "PUT"
        if let data = body {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = data
        }
        
        self.sessionHitWith(request: request, url: url.absoluteString) { (obj: Result<T, Error>) in
            outputBlock(obj)
        }
    }


    func uploadPrecriptionImages<T: Decodable>(api: String, appointmentId: Int, images: [UIImage]?, outBlock: @escaping (Result<T, Error>) -> Void) {
        if !isConnectedToNetwork() {
            outBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.internetProblem.Message])))
            return
        }
        
        guard let url = URL(string: (Api.BaseUrl + api).replacingOccurrences(of: " ", with: "%20")) else {
            outBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.badUrl.Message])))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let boundary = "Boundary-\(UUID().uuidString)"
        if let token = DefaultsClass.shared.accessToken {
            request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization")
        }
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let lineBreak = "\r\n"
        var body = Data()
        
        // Add appointmentId to parameters
        body.append("--\(boundary + lineBreak)")
        body.append("Content-Disposition: form-data; name=\"appointmentId\"\(lineBreak + lineBreak)")
        body.append("\(appointmentId)" + lineBreak)
        
        if let images = images {
            for image in images {
                if let imageData = image.pngData() {
                    body.append("--\(boundary + lineBreak)")
                    body.append("Content-Disposition: form-data; name=\"precription\"; filename=\"precription.jpg\"\(lineBreak)")
                    body.append("Content-Type: \("image/jpeg" + lineBreak + lineBreak)")
                    body.append(imageData)
                    body.append(lineBreak)
                }
            }
        }
        
        body.append("--\(boundary)--\(lineBreak)")
        request.httpBody = body
        
        self.sessionHitWith(request: request, url: url.absoluteString) { (result: Result<T, Error>) in
            outBlock(result)
        }
    }


    
    
   private func sessionHitWith<T: Decodable>(request: URLRequest,url:String ,outputBlock: @escaping (Result<T, Error>) -> ()) {
       URLSession.shared.dataTask(with: request) { (data, response, error) in
           DispatchQueue.main.async {
              
      
               guard let data = data else {
                    outputBlock(.failure(NSError(domain: "", code: 1, userInfo: [NSLocalizedDescriptionKey: Constants.EnumAlert.noApiData.Message])))
                   return
               }
               
               print("======================================================================================================\nSERVICE URL :- \(url)")
               print("RESPONCE :- \n",String(decoding: data, as: UTF8.self),"\n=============================================================================================================================")
          
               do {
                   let decoder = JSONDecoder()
                   let formatter = DateFormatter()
                   formatter.dateFormat = "yyyy-MM-dd"
                   decoder.dateDecodingStrategy = .formatted(formatter)
                   let obj = try decoder.decode(T.self, from: data)
                   print(obj)
                   outputBlock(.success(obj))
               } catch let jsonErr {
                   outputBlock(.failure(jsonErr))
                   print(jsonErr)
               }
           }
       }.resume()
   }
   
   //MARK: - Check Internet
   private func isConnectedToNetwork() -> Bool {
       var zeroAddress = sockaddr_in()
       zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
       zeroAddress.sin_family = sa_family_t(AF_INET)
       let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
           $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
               SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
           }
       }
       if(defaultRouteReachability == nil){
           return false
       }
       var flags : SCNetworkReachabilityFlags = []
       if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
           return false
       }
       
       let isReachable = flags.contains(.reachable)
       let needsConnection = flags.contains(.connectionRequired)
       
       return (isReachable && !needsConnection)
   }
   
   private func compressImage(image:UIImage, fileSizeKb:Int) -> Data? {
       
       if fileSizeKb < 2000 {
           return image.jpegData(compressionQuality: 0.7)
       } else if fileSizeKb < 3000 {
           return image.jpegData(compressionQuality: 0.6)
       } else if fileSizeKb < 4000 {
           return image.jpegData(compressionQuality: 0.5)
       } else if fileSizeKb < 5000 {
           return image.jpegData(compressionQuality: 0.4)
       } else if fileSizeKb < 6000 {
           return image.jpegData(compressionQuality: 0.3)
       } else if fileSizeKb < 10000 {
           return image.jpegData(compressionQuality: 0.25)
       } else if fileSizeKb < 20000 {
           return image.jpegData(compressionQuality: 0.2)
       } else {
           return image.jpegData(compressionQuality: 0.15)
       }
   }


}

extension Data {
   mutating func append(_ string: String, using encoding: String.Encoding = .utf8) {
       if let data = string.data(using: encoding) {
           append(data)
       }
   }
}
//MARK: - Image downloading imageView
let imageCache = NSCache<NSString, UIImage>()
class UrlImageView: UIImageView {
   var string: String?
   func setImageView(with urlStr: String, placeholderImage: UIImage? = nil) {
       let urlStr = urlStr.replacingOccurrences(of: " ", with: "%20")
       self.string = urlStr
       if let placeholder = placeholderImage {
           self.image = placeholder
       }
       if let image = imageCache.object(forKey: urlStr as NSString) {
           self.image = image
           return
       }
       guard let url = URL(string: self.string ?? "") else {return}
       URLSession.shared.dataTask(with: url) { (data, resp, error) in
           DispatchQueue.main.async {
               if let err = error {
                   print(err.localizedDescription)
                   return
               }
               if self.string == url.absoluteString {
                   guard let data = data else {return}
                   guard let image = UIImage(data: data) else {return}
                   self.image = image
                   imageCache.setObject(image, forKey: url.absoluteString as NSString)
               }
           }
           }.resume()
   }
}

/*
// MARK:- Register Model // login Model
struct RegisterModel:Codable {
   let status    : Bool?
   let message    : String?
   let data    : RegisterData?
   let  access_token : String?
   let  token_type : String?
}

// MARK: Login View Model
class LoginViewModel {
   func loginUser(param:[String:Any],completion:@escaping(Bool,String)->()){
       HitApi.shared.sendRequest(endPoint: Api.login, parameters: param) { (result:Result<RegisterModel,Error>) in
           switch result{
           case .success(let model):
               if model.message == "Successfully Logged In!"{
                   HugoDefaults.shared.tokenType = model.token_type
                   HugoDefaults.shared.accessToken = model.access_token
            
                   completion(true, "")
               }else{
                   completion(false, model.message ?? "Server Error!")
               }
               break;
               
           case.failure(let error):
               completion(false,  error.localizedDescription)
               break;
           }
       }
   }
}

//MARK:- APi Work in View controller
extension LoginViewController{
   
   private func ApiLoginUser(){
       let param = [
                    "email":txtEmail.text!,
                    "password":txtPassword.text!]
       print(param)
       self.IndicatorSignUpBtn.Start()
       objLogin.loginUser(param: param) { (status,msg) in
           self.IndicatorSignUpBtn.Stop()
           if status{
               SceneDelegate.shared?.SetEntryPoint()
           }else{
               self.showAlert(title: msg, control: ["Ok"]) { (_) in}
           }
       }
   }
   
   
}
*/
