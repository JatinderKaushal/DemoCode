//
//  Constant.swift
//  Doctors
//
//  Created by Mandeep Singh on 06/06/22.
//

import Foundation
import UIKit
import SwiftUI

class Constants {

   static let shared = Constants()
   private init(){}
    
    static let MainColorSkyBlue = UIColor(named: "MainColorSkyBlue")!
    static let MainColorLightGray = UIColor(named: "lightGray")!
    
    static let PatiantPlaceholderImage = UIImage(named: "patient")!
    static let DoctorPlaceholderImage = UIImage(named: "doc")!
    
    static let defaultServerMessage = "No error message!!"
    static let defaultPaginationMessage = "This was last page!!"
    
    static let screenWidth = UIScreen.main.bounds.width
    static let screenHeight = UIScreen.main.bounds.height
    static let currentAppEnvironment:AppEnvironment = .development
    
    static var currentAppUserType:AppUserType = .doctor
    static var currentDoctorFillInfoType:DoctorFillInfoType = .editPofile
    static var selectedDoctorMenu :StringAndImage = DoctorMenu.first!
    static var selectedPatientMenu :StringAndImage = PatientMenu.first!
   
    typealias StringAndValue = (name: String, value: Int)
    typealias StringAndImage = (uid:Int,name: String, value: UIImage )
    
    
    enum AppEnvironment:String {
        case staging = "staging"
        case development = "development"
   }
    enum AppUserType:String{
      case patient = "Patient"
      case doctor = "Doctor"
    }
    enum DoctorFillInfoType{
        case registration
        case editPofile
    }
    
    public enum EnumAlert {
          case internetProblem
          case badUrl
          case noApiData
      
          var Message : String{
              switch self{
              case .internetProblem:  return "No Internet Connection"
              case .badUrl:           return "Bad Url"
              case .noApiData:        return "Could not get the data"
              }
          }
      }
    public enum EnumDays:Int {
        
        case monday = 1
        case tuesday = 2
        case wednesday = 3
        case thursday = 4
        case friday = 5
        case saturday = 6
        case sunday = 7
        var str : String{
            switch self{
            case .monday :   return "Monday"
            case .tuesday :  return "Tuesday"
            case .wednesday :  return "Wednesday"
            case .thursday : return "Thursday"
            case .friday :   return "Friday"
            case .saturday : return "Saturday"
            case .sunday :   return "Sunday"
            }
        }
    }
    public enum EnumAppointmentStatus:Int {
        case pending = 0
        case accepted = 1
        case declined = 2
        case cancelled = 3
        case deleted = 4
        case completed = 5
        case overdue = 6
      
          var str : String{
              switch self{
              case .pending :   return "Pending"
              case .accepted :  return "Accepted"
              case .declined :  return "Declined"
              case .cancelled : return "Cancelled"
              case .deleted :   return "Deleted"
              case .completed : return "Completed"
              case .overdue :   return "Overdue"
              }
          }
        var clr : UIColor{
            switch self{
            case .pending :   return UIColor.systemRed
            case .accepted :  return UIColor.systemGreen
            case .declined :  return UIColor.systemRed
            case .cancelled : return UIColor.systemRed
            case .deleted :   return UIColor.systemRed
            case .completed : return UIColor.systemGreen
            case .overdue :   return UIColor.systemRed
           }
        }
    }
    static let Filters:[StringAndValue] = [
     (name: "Pending",   value: 0),
     (name: "Accepted",  value: 1),
     (name: "Declined", value: 2),
     (name: "Cancelled", value: 3),
     (name: "Completed", value: 5),
     (name: "Overdue", value: 6)]
    
    static let HistoryFilters:[StringAndValue] = [
     (name: "Accepted",  value: 1),
     (name: "Declined", value: 2),
     (name: "Cancelled", value: 3),
     (name: "Completed", value: 5),
     (name: "Overdue", value: 6)]
    
    /* MARK: Doctor Working Dyas and Gender List *******************/
    static let DaysList:[StringAndValue] = [
     (name: "Monday",   value: 1),
     (name: "Tuesday",  value: 2),
     (name: "Wednesday",value: 3),
     (name: "Thursday", value: 4),
     (name: "Friday",   value: 5),
     (name: "Saturday", value: 6),
     (name: "Sunday",   value: 7)]
    
    static let GenderList:[StringAndValue] = [
         (name: "Male",   value: 1),
         (name: "Female", value: 2),
         (name: "Other",  value: 3)]
    /* ***** */
    
    /* MARK: Doctor Side Menu ****************** */
    static let DoctorMenu:[StringAndImage] = [
        (uid: 0,  name: "Appointments", value: UIImage(named: "recent_booking_blue")!),
        (uid: 1,  name: "Patient List", value: UIImage(named: "patient_list")!),
        (uid: 2,  name: "History",      value: UIImage(named: "upcoming_booking_blue")!),
        (uid: 3  ,name: "Notifications",value: UIImage(named: "notification_blue")!),
        (uid: 4,  name: "Profile",      value: UIImage(named: "profile_blue")!),
        (uid: 5,  name: "Contact Us",   value: UIImage(named: "profile_blue")!),
        (uid: 6,  name: "Logout",       value: UIImage(named: "logout_blue")!)]
    /* ***** */
    
    static let PatientMenu:[StringAndImage] = [
        (uid: 0,  name: "Home", value: UIImage(named: "recent_booking_blue")!),
        (uid: 1,  name: "History",      value: UIImage(named: "upcoming_booking_blue")!),
        (uid: 2,  name: "Appointments", value: UIImage(named: "patient_list")!),
        (uid: 3,  name: "Reports", value: UIImage(named: "patient_list")!),
        (uid: 4,  name: "Prescription", value: UIImage(named: "patient_list")!),
        (uid: 5  ,name: "Notifications",value: UIImage(named: "notification_blue")!),
        (uid: 6,  name: "Profile",      value: UIImage(named: "profile_blue")!),
        (uid: 7,  name: "Contact Us",   value: UIImage(named: "profile_blue")!),
        (uid: 8,  name: "Logout",       value: UIImage(named: "logout_blue")!)]
    
    static func convert_hh_mm_a(date:Date)->String?{
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "hh:mm a"
        return dateFormatter.string(from:date)
    }
    
    static func getTimeStamp(date:Date)->Double{
        return date.timeIntervalSince1970
    }
    
    enum DateFormats:String{
        case hh_mm_a = "hh:mm a"
        case dd_MMM_yyyy_hh_mm_a = "dd MMM yyyy, hh:mm a"
        case dd_MMM_yyyy_EEEE = "dd MMM yyyy, EEEE"
        case dd_MMM_yyyy = "dd-MM-yyyy"
        case eeee = "EEEE"
        
    }
}
extension String {
    func convertToDateStrings(format:Constants.DateFormats)->String?{
        print(self)
        let date = Date(timeIntervalSince1970: self.getDoubles()/1000.0)
        print(self.getDoubles())
        print(date)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format.rawValue
        dateFormatter.timeZone = .current
        return dateFormatter.string(from: date)
    }
}
extension Int{
    func convertToDateString(format:Constants.DateFormats)->String?{
        print(self)
        let date = Date(timeIntervalSince1970: self.getDouble()/1000.0)
        print(self.getDouble())
        print(date)
            let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format.rawValue
                dateFormatter.timeZone = .current
            return dateFormatter.string(from: date)
    }
    
     func convertToDate(format:Constants.DateFormats)->Date?{
         print(self)
        let date = Date(timeIntervalSince1970: self.getDouble()/1000.0)
         print(self.getDouble())
        print(date)
        let dateFormatter = DateFormatter()
        let strDate = dateFormatter.string(from: date)
            dateFormatter.dateFormat = format.rawValue
            dateFormatter.timeZone = .current
        return dateFormatter.date(from: strDate)
    }
}

struct AppColors {
    
    static let appThemeColor = #colorLiteral(red: 0.1385265589, green: 0.75404948, blue: 0.8817569613, alpha: 1)
    static let selectedButton = #colorLiteral(red: 0.2163321674, green: 0.3806051314, blue: 0.8036037087, alpha: 1)
    static let buttonColor =  #colorLiteral(red: 0.9607843757, green: 0.9607843757, blue: 0.9607843757, alpha: 1)
}
