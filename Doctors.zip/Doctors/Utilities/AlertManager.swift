//
//  AlertManager.swift
//  GymMate
//
//  Created by aksa nazir on 28/11/23.
//

import Foundation
import UIKit

typealias AlertCompletion = (Int, String?) -> ()

class AlertManager: NSObject {
    
    static let shared = AlertManager()
    
    func showAlert(title: String? = "Doctor's Availability", message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "ok", style: .cancel, handler: nil))
        AppManager.getTopViewController.present(alert, animated: true, completion: nil)
    }
    
    // Show Delete Alert
    static func showCancelJobAlert(title: String, message: String, actionTitles: [String?]?, completion: AlertCompletion?) {
        DispatchQueue.main.async {
            let alertController = UIAlertController(title: title,
                                                    message: message,
                                                    preferredStyle: .alert)
            
            if let actionTitles = actionTitles {
                for (index, title) in actionTitles.enumerated().reversed() {
                    let style: UIAlertAction.Style = (index == 0) ? .destructive : .default
                    let action = UIAlertAction(title: title!, style: style, handler: { (action) in
                        if let completion = completion {
                            completion(index, title)
                        }
                    })
                    alertController.addAction(action)
                }
            }
            AppManager.getTopViewController.present(alertController, animated: true, completion: nil)
        }
    }
    func dismissAlert() {
            DispatchQueue.main.async {
                guard let topViewController = AppManager.getTopViewController.presentedViewController else {
                    return
                }
                if topViewController is UIAlertController {
                    topViewController.dismiss(animated: true, completion: nil)
                }
            }
        }
    
    // MARK: -  Show AlertView With completion
    
    func showAlert(title: String? = "Doctor's Availability", message: String, actionTitles: [String?]?, completion: AlertCompletion?) {
        DispatchQueue.main.async {
            let alertController = UIAlertController(title: title,
                                                    message: message,
                                                    preferredStyle: .alert)
            if let actionTitles = actionTitles {
                for (index, title) in actionTitles.enumerated().reversed() {
                    let action = UIAlertAction(title: title!, style: .default, handler: { (action) in
                        if (completion != nil) {
                            completion!(index, title)
                        }
                    })
                    alertController.addAction(action)
                }
            }
            AppManager.getTopViewController.present(alertController, animated: true, completion: nil)
        }
    }
    func showInputAlert(title: String?, placeholder: String?, saveActionTitle: String, saveAction: @escaping (String?) -> Void, cancelAction: (() -> Void)?) {
            DispatchQueue.main.async {
                let alertController = UIAlertController(title: title, message: nil, preferredStyle: .alert)
                
                alertController.addTextField { textField in
                    textField.placeholder = placeholder
                }
                
                let saveAction = UIAlertAction(title: saveActionTitle, style: .default) { _ in
                    let inputText = alertController.textFields?.first?.text
                    saveAction(inputText)
                }
                alertController.addAction(saveAction)
                
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
                    cancelAction?()
                }
                alertController.addAction(cancelAction)
                
                AppManager.getTopViewController.present(alertController, animated: true, completion: nil)
            }
        }
    }



class AppManager {
    
    // Get The Top View Controller From View Hierarchy
    static var getTopViewController : UIViewController {
        
        var rootVC: UIViewController? = nil
        if #available(iOS 13.0, *) {
            for scene in UIApplication.shared.connectedScenes {
                if scene.activationState == .foregroundActive {
                    rootVC = ((scene as? UIWindowScene)!.delegate as! UIWindowSceneDelegate).window??.rootViewController
                    while rootVC?.presentedViewController != nil {
                        rootVC = rootVC?.presentedViewController
                    }
                }
            }
        } else {
            rootVC = UIApplication.shared.windows.first?.rootViewController
            while rootVC?.presentedViewController != nil {
                rootVC = rootVC?.presentedViewController
            }
        }
        return rootVC ?? UIViewController()
    }
   
    }
