//
//  DefaultClass.swift
//  Doctors
//
//  Created by Mandeep Singh on 06/06/22.
//


import Foundation
class DefaultsClass{

   static let shared = DefaultsClass()
   private init(){}

   var accessToken: String? {
       get {return UserDefaults.standard.string(forKey: "access_token")}
       set {UserDefaults.standard.setValue(newValue, forKey: "access_token")}
   }
    var isAlreadyIn: Bool {
        get {return UserDefaults.standard.bool(forKey: "isAlreadyIn")}
        set {UserDefaults.standard.setValue(newValue, forKey: "isAlreadyIn")}
    }
    var APNS_Token: String {
        get {return UserDefaults.standard.string(forKey: "APNS_Token") ?? "asassnodjwodijwdmwdlksldkj"}
        set {UserDefaults.standard.setValue(newValue, forKey: "APNS_Token")}
    }
    
    var phoneNumber: String {
        get {return UserDefaults.standard.string(forKey: "phoneNumber") ?? ""}
        set {UserDefaults.standard.setValue(newValue, forKey: "phoneNumber")}
    }
    
    var id: Int {
        get {return UserDefaults.standard.integer(forKey: "id")}
        set {UserDefaults.standard.setValue(newValue, forKey: "id")}
    }
    
    var role: String {
        get {return UserDefaults.standard.string(forKey: "role") ?? ""}
        set {UserDefaults.standard.setValue(newValue, forKey: "role")}
    }
    
    var currentUserType : Constants.AppUserType{
         get {
             let str = UserDefaults.standard.string(forKey: "currentUserType") ?? "doctor"
             return str == "doctor" ? .doctor : .patient
         }set {
             UserDefaults.standard.setValue(newValue == .doctor ? "doctor" : "patient", forKey: "currentUserType")
         }
     }
    
    var name: String {
          get {return UserDefaults.standard.string(forKey: "name") ?? ""}
          set {UserDefaults.standard.setValue(newValue, forKey: "name")}
      }
    
    var profilePic: String {
          get {return UserDefaults.standard.string(forKey: "profilePic") ?? ""}
          set {UserDefaults.standard.setValue(newValue, forKey: "profilePic")}
      }
    
    
    var appEnvironment: Constants.AppEnvironment {
          get {
              let str = UserDefaults.standard.string(forKey: "appEnvironment") ?? Constants.AppEnvironment.development.rawValue
              return str == Constants.AppEnvironment.staging.rawValue ? Constants.AppEnvironment.staging : Constants.AppEnvironment.development
          }
          set {
              UserDefaults.standard.setValue(newValue == Constants.AppEnvironment.staging ? Constants.AppEnvironment.staging.rawValue : Constants.AppEnvironment.development.rawValue, forKey: "appEnvironment")
          }
      }
  /*
    
    var doctorLoginData : DoctorRegisterModel?{
        get {
            if let data = UserDefaults.standard.data(forKey: "doctorLoginData") {
                let decoder = JSONDecoder()
                if let object = try? decoder.decode(DoctorRegisterModel.self, from: data) {
                    return object
                }else {
                    print("Couldnt decode object")
                    return nil
                }
            }else {
                print("Couldnt find key")
                return nil
            }
        }set{
            if let data = newValue{
                let encoder = JSONEncoder()
                if let encoded = try? encoder.encode(data) {
                    UserDefaults.standard.set(encoded, forKey: "doctorLoginData")
                }
            }
        }
    }*/
    
    func removeAll(){
        UserDefaults.standard.removeObject(forKey: "access_token")
        UserDefaults.standard.removeObject(forKey: "isAlreadyIn")
        UserDefaults.standard.removeObject(forKey: "APNS_Token")
        UserDefaults.standard.removeObject(forKey: "phoneNumber")
        UserDefaults.standard.removeObject(forKey: "role")
        UserDefaults.standard.removeObject(forKey: "currentUserType")
        UserDefaults.standard.removeObject(forKey: "name")
        UserDefaults.standard.removeObject(forKey: "profilePic")
    }

}
