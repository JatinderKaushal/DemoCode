//
//  Extension TextField.swift
//  GymMate
//
//  Created by aksa nazir on 21/11/23.
//

import UIKit
import Foundation
import Moya

extension NSObject {
    
    func handleRepsonse<T: Codable>(type: T.Type, moyaResponse : Response, message: String? = nil) throws -> T? {
        do {
            debugPrint(moyaResponse.request as Any)
            if moyaResponse.data.count != 0 {
                debugPrint(try moyaResponse.mapJSON())
            }
            
            switch moyaResponse.statusCode {
            case 200, 201, 401:
                return try JSONDecoder().decode(type.self, from: moyaResponse.data)
            case 500:
                print("internal server error")
               return nil
            default:
                break
            }
            
            return nil
        }
        catch let error {
            debugPrint(error)
            throw error
        }
    }
   
}

extension URL {
    var queryParameters: [String: String]? {
        guard let components = URLComponents(url: self, resolvingAgainstBaseURL: true), let queryItems = components.queryItems else {
            return nil
        }

        var parameters = [String: String]()
        for item in queryItems {
            parameters[item.name] = item.value
        }
        return parameters
    }
}


extension Int {
    func toString() -> String {
        return "\(self)"
    }
}
extension Double {
    func toString() -> String {
        return "\(self)"
    }
}
extension UIImage {
    func imageResized(to size: CGSize) -> UIImage {
        return UIGraphicsImageRenderer(size: size).image { _ in
            draw(in: CGRect(origin: .zero, size: size))
        }
    }
}

extension UIViewController{
    func stringFromDate(date : Date, format : String) -> String{
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = format
        let now = dateformatter.string(from: date)
        return now
    }
    
    func presentfromBottomToTop(vc: UIViewController) {
            vc.modalPresentationStyle = .overCurrentContext
            vc.modalTransitionStyle = .crossDissolve
            let transition = CATransition()
            transition.duration = 0.5
            transition.type = CATransitionType.push
            transition.subtype = CATransitionSubtype.fromTop
            vc.view.layer.add(transition, forKey: kCATransition)
            self.present(vc, animated: false, completion: nil)
        }
}

extension Double {
    func getDateStringFromUTC(format:String) -> String {
        let date = Date(timeIntervalSince1970: self)
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = .current
        dateFormatter.dateFormat = format
        return dateFormatter.string(from: date)
    }
}

extension String {
    
    func strstr(needle: String, beforeNeedle: Bool = false) -> String? {
        guard let range = self.range(of: needle) else { return nil }
        
        if beforeNeedle {
            return self.substring(to: range.lowerBound)
        }
        
        return self.substring(from: range.upperBound)
    }
    
}
extension Date {
    func currentTimeMillis() -> Int64 {
        return Int64(self.timeIntervalSince1970 * 1000)
    }
}
