//
//  ApiConstant.swift
//  Doctors
//
//  Created by Mandeep Singh on 06/06/22.
//

import Foundation

class Api {
    //   static let BaseUrl = "http://qualhon.net:3800/api/"
    
    static func imageUrl(endpoint:String)->String{return MainUrl+endpoint}
    //    static let MainUrl = DefaultsClass.shared.appEnvironment == .development ? "http://10.10.0.20:3100/" : "http://qualhon.net:3000/"
    static let MainUrl = DefaultsClass.shared.appEnvironment == .development ? "http://qualhon.net:3033/" : "http://qualhon.net:3033/"
    static let BaseUrl = MainUrl+"api/v1/"
    
    static let login = "auth/login"
    static let verifyOtp = "auth/validate-otp"
    static let doctorSpecialization = "categories"
    
    static let acceptAppointment = ""
    static let contactUs = "contact"
    static let doctorRegister = "auth/doctor/register"
    static let doctorProfileUpdate = "auth/doctor/profile"
    static let getDoctorProfile = "doctors/\(DefaultsClass.shared.id)"
    static func doctorAppointments(page:Int, search: String?, status: [Int])->String{
        let statusString = status.map { String($0) }.joined(separator: ",")
        let searchString = search ?? ""
        return "appointments?perPage=20&page=\(page)&search=\(searchString)&status=\(statusString)"
    }
    static func getHistory(page: Int, search: String?, status: [Int]) -> String {
        let statusString = status.map { String($0) }.joined(separator: ",")
        let searchString = search ?? ""
        return "appointments?perPage=20&page=\(page)&search=\(searchString)&status=\(statusString)"
    }
}
