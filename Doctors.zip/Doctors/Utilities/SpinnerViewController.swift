//
//  SpinnerViewController.swift
//  Doctors
//
//  Created by Mandeep Singh on 10/06/22.
//


import Foundation
import UIKit

class spinnerInstance{
    static let vc = SpinnerViewController.instantiateMain()
    static var isAlreadyPresented = false
    static func topViewController(){
        
    }
}

class SpinnerViewController: UIViewController {
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidLoad()
        self.view.presentOpacityAnimation(duration: 0.05, opacity: 0.4)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.view.backgroundColor = .clear
    }
    
     func dismissMe(){
         spinnerInstance.isAlreadyPresented = false
        self.dismiss(animated: false, completion: nil)
    }
}

extension UIViewController{
    func showSpinner(){
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            guard spinnerInstance.isAlreadyPresented == false else {return}
            spinnerInstance.isAlreadyPresented = true
            let vc = spinnerInstance.vc
            vc.modalPresentationStyle = .overFullScreen
            self.present(vc, animated: false, completion: nil)
        }
    }
    
    func hideSpinner(){
        DispatchQueue.main.asyncAfter(deadline: .now()+0.9) {
          let vc = spinnerInstance.vc
           vc.dismissMe()
        }
    }
}
