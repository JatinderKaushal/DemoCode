//
//  LocationManager.swift
//  Doctors
//
//  Created by Mandeep Singh on 14/06/22.
//


import Foundation
import UIKit
import CoreLocation

protocol LocationServiceDelegate {
    func tracingLocation(currentLocation: CLLocation)
    func tracingLocationDidFailWithError(error: Error)
    func tracingAddress(address: String)
}

class LocationService: NSObject, CLLocationManagerDelegate {
    
    static var sharedInstance = LocationService()
    private override init(){}
    
    var locationManager: CLLocationManager?
    var currentLocation: CLLocation?
    var delegate: LocationServiceDelegate?
    var realTimeLocation = Bool()
    private func initManager(){
        if self.locationManager == nil{
            self.locationManager = CLLocationManager()
            
            self.locationManager?.delegate = self
            self.locationManager?.requestAlwaysAuthorization()
            self.locationManager?.desiredAccuracy = kCLLocationAccuracyBest
            // The accuracy of the location data
           //locationManager.distanceFilter = 50 // The minimum distance (measured in meters) a device must move horizontally before an update event is generated.
        }else{
            self.locationManager?.startUpdatingLocation()
        }
    }
    
    func startUpdatingLocation() {
        print("Starting Location Updates")
        self.initManager()
    }
    
    func stopUpdatingLocation() {
        print("Stop Location Updates")
        self.locationManager?.stopUpdatingLocation()
        self.locationManager = nil
    }

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .notDetermined:
            print("wait for user's action")
        case .restricted, .denied:
            DispatchQueue.main.async {
                self.locationPermissionPopup()
            }
        case .authorizedAlways:
            self.locationManager?.startUpdatingLocation()
            print("authorizedAlways")
        case .authorizedWhenInUse:
            self.locationManager?.startUpdatingLocation()
            print("authorizedWhenInUse")
        case .authorized:
            self.locationManager?.startUpdatingLocation()
            print("authorized")
        @unknown default:
            fatalError()
        }
    }
    
    func locationPermissionPopup() {
        self.presentAlertWithTitle(title:"Location Permission Required", message: "Please enable location permissions in settings.", options:  ["Settings","Cancel"]) { str in
            if str == "Settings" {
                //Redirect to Settings app
                UIApplication.shared.open(URL(string:UIApplication.openSettingsURLString)!)
            }
        }
    }
    
    func presentAlertWithTitle(title: String = "", message: String, options: [String], completion: @escaping (String) -> Void) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        for (index, option) in options.enumerated() {
            alertController.addAction(UIAlertAction.init(title: option, style: .default, handler: { (action) in
                completion(options[index])
            }))
        }
        guard let topVC = UIApplication.topViewController() else { return  }
        topVC.present(alertController, animated: true, completion: nil)
    }
    
    func reverseGeocoding(location:CLLocation) {
        CLGeocoder().reverseGeocodeLocation(location) { placemark, error in
            if let error = error as? CLError {
                print("CLError:", error)
                return
            } else if let placemark = placemark?.first {
                // you should always update your UI in the main thread
                DispatchQueue.main.async {
                    //  update UI here
                    guard let delegate = self.delegate else {return}
                    delegate.tracingAddress(address: "\(placemark.subAdministrativeArea ?? ""), \(placemark.administrativeArea ?? ""), \(placemark.country ?? "") ")
                    
                }
            }
        }
    }
    //MARK: - CLLocationManagerDelegate
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else {return}
        
        // singleton for get last(current) location
        self.currentLocation = location
        
        // use for real time update location
        updateLocation(currentLocation: location)
        
        if !realTimeLocation {
            self.stopUpdatingLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // do on error
        updateLocationDidFailWithError(error: error)
    }
    
    // Private function
    private func updateLocation(currentLocation: CLLocation){
        guard let delegate = self.delegate else {return}
        delegate.tracingLocation(currentLocation: currentLocation)
    }
    
    private func updateLocationDidFailWithError(error: Error) {
        guard let delegate = self.delegate else {return}
        delegate.tracingLocationDidFailWithError(error: error)
    }
}
